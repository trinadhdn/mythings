package com.adp.githooks;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.codehaus.plexus.util.ExceptionUtils;
import org.codehaus.plexus.util.FileUtils;

@Mojo(name = "setup")
public class GITHooks extends AbstractMojo {

	@Parameter(readonly = true, defaultValue = "${project.basedir}")
	private File projectBaseDir;

	@Parameter(defaultValue = "${project}")
	public MavenProject project;

	public void execute() throws MojoExecutionException {

		try {
			// Skip if not Windows OS
			if (!System.getProperty("os.name").toUpperCase().startsWith("WINDOWS"))
				return;
			
			if (project.getName().contains("Root_"))
				return;

			String[] hooks = { "pre-commit", "pre-push" };

			for (String hook : hooks) {
				// Setup the GIT hooks
				String hookPath = projectBaseDir.getAbsolutePath() + "/.git/hooks/" + hook;
				String latestPath = projectBaseDir.getAbsolutePath() + "/../Root_Framework/src/main/resources/GITHooks/" + hook;

				// Get the version of the hook
				String hookVersion = "0.0";
				if (FileUtils.fileExists(hookPath)) {
					if ((new File(hookPath)).length() != 0) {
						InputStream in = new FileInputStream(hookPath);
						String data = IOUtils.toString(in, "windows-1252");
						String[] lines = data.split("\\r?\\n");
						for (String line : lines) {
							if (line.toUpperCase().trim().contains("#VERSION")) {
								hookVersion = line.toUpperCase().trim().split("VERSION")[1].trim();
								break;
							}
						}
					}
				}

				// Get the latest hook version
				String latestVersion = "0.0";
				InputStream in = new FileInputStream(latestPath);
				String data = IOUtils.toString(in, "windows-1252");

				String[] lines = data.split("\\r?\\n");
				for (String line : lines) {
					if (line.toUpperCase().trim().contains("#VERSION")) {
						latestVersion = line.toUpperCase().trim().split("VERSION")[1].trim();
						break;
					}
				}

				// Copy the latest hook
				if (!hookVersion.equals(latestVersion)) {
					FileUtils.forceDelete(hookPath);
					FileUtils.copyFile(new File(latestPath), new File(hookPath));
				}
			}
			// Create build file
			if (FileUtils.fileExists(projectBaseDir.getAbsolutePath() + "/target")) {
				File file = new File(projectBaseDir.getAbsolutePath() + "/target/maven_build");
				FileUtils.forceDelete(file);
				file.createNewFile();
			}
			getLog().info("GIT Hooks setup succesfully !");
		} catch (Exception e) {
			throw new MojoExecutionException(ExceptionUtils.getStackTrace(e));
		} finally {
		}

	}

}
