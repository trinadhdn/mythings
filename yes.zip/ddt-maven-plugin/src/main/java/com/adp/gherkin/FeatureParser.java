package com.adp.gherkin;

import static cucumber.runtime.io.MultiLoader.packageName;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.maven.artifact.DependencyResolutionRequiredException;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.codehaus.plexus.util.ExceptionUtils;
import org.junit.runners.model.InitializationError;

import cucumber.runtime.ClassFinder;
import cucumber.runtime.CucumberException;
import cucumber.runtime.Utils;
import cucumber.runtime.io.MultiLoader;
import cucumber.runtime.io.Resource;
import cucumber.runtime.io.ResourceLoader;
import cucumber.runtime.io.ResourceLoaderClassFinder;
import cucumber.runtime.model.CucumberFeature;
import cucumber.runtime.model.FeatureBuilder;
import cucumber.util.Encoding;
import gherkin.AstBuilder;
import gherkin.Parser;
import gherkin.TokenMatcher;
import gherkin.ast.GherkinDocument;
import gherkin.ast.Tag;

@Mojo(name = "parse")
public class FeatureParser extends AbstractMojo {
	List<String> m_failedFeatures = new ArrayList<>();
	List<Resource> m_listFeatures = new ArrayList<>();

	List<ComponentType> m_listComponents = new ArrayList<ComponentType>();
	List<String> m_lstrFeatureTags = new ArrayList<String>();

	@Parameter(readonly = true, defaultValue = "${project.basedir}")
	private File projectBaseDir;

	@Parameter(readonly = true, defaultValue = "${project.build.directory}")
	private File projectBuildDirectory;

	@Parameter(defaultValue = "${project}")
	public MavenProject project;

	public void execute() throws MojoExecutionException {

		try {
			boolean isDDTBuild = project.getArtifactId().equalsIgnoreCase("WFN_DDT_Build") || project.getArtifactId().equalsIgnoreCase("LP_Build");

			List<String> featureFolders = new ArrayList<>();
			if (!isDDTBuild) {
				featureFolders.add(projectBaseDir.getAbsolutePath() + "/src/main/resources/Features");
			} else {
				// Get features path for all feature projects
				String [] featureFoldersArr = new File(projectBaseDir.getAbsolutePath() + "/../").list(new FilenameFilter() {

					@Override
					public boolean accept(File dir, String name) {
						// TODO Auto-generated method stub
						return name.startsWith("Feature_");
					}
				});
				for (String featureFolder: featureFoldersArr){
					featureFolders.add(projectBaseDir.getAbsolutePath() + "/../" + featureFolder + "/src/main/resources/Features");
				}
			}

			Boolean bFailure = false;
			String messageParseFeature = "", messageDupeComp = "", messageDupeFeature = "";
			getLog().info("************************** START DDT MAVEN PLUGIN PROCESS **************************");
			parseFeatures(featureFolders);

			if (m_failedFeatures.size() > 0) {
				messageParseFeature = String.join("\n", m_failedFeatures);
				bFailure = true;
			}
			getLog().info("Parsing complete");

			getLog().info("Find duplicate feature tags ...");

			// JE - added to catch duplicate feature tags
			// retrieveFeatureFileTags();
			List<String> dupeFeatureList = findDuplicateFeatureTags();

			if (dupeFeatureList.size() > 0) {
				messageDupeFeature = String.join("\n", dupeFeatureList);
				bFailure = true;
			}
			getLog().info("Duplicate feature tags process complete ...");

			if (!isDDTBuild) {
				// JE - added to catch duplicate component names
				List<String> dupeComponentList = listOfDuplicateComponents();
				if (dupeComponentList.size() > 0) {
					messageDupeComp = String.join("\n", dupeComponentList);
					bFailure = true;
				}
			}
			// getLog().info("COMPONENT COUNT: " + dupeComponentList.size());
			String message = String.join("\n", "DUPLICATE FEATURE TAGS", "********************", messageDupeFeature, "", "DUPLICATE COMPONENTS:", "********************", messageDupeComp, "", "FEATURE PARSE ERRORS", "********************", messageParseFeature, "");
			if (bFailure)
				throw new MojoExecutionException("\nDDT Maven Plugin Errors:" + "\n" + "________________________________________" + "\n" + message);
			else
				getLog().info("No issues found !");
		} catch (MojoExecutionException ex) {
			throw new MojoExecutionException(ex.getMessage());
		} catch (Exception e) {
			throw new MojoExecutionException(ExceptionUtils.getStackTrace(e));
		} finally {
			getLog().info("**************************END DDT MAVEN PLUGIN PROCESS**************************");
		}

	}

	public void parseFeatures(List<String> featureFolders) throws InitializationError, IOException {
		ClassLoader classLoader = getClass().getClassLoader();
		ResourceLoader resourceLoader = new MultiLoader(classLoader);

		final List<CucumberFeature> cucumberFeatures = new ArrayList<CucumberFeature>();
		final FeatureBuilder builder = new FeatureBuilder(cucumberFeatures);
		for (String featurePath : featureFolders) {
			if (new File(featurePath).isDirectory()) {
				getLog().info("Parsing features at: " + featurePath);
				loadFromFeaturePath(builder, resourceLoader, featurePath);
			}
		}
	}

	private void loadFromFeaturePath(FeatureBuilder builder, ResourceLoader resourceLoader, String featurePath) throws IOException {
		Iterable<Resource> resources = resourceLoader.resources(featurePath, ".feature");
		for (Resource resource : resources) {
			m_listFeatures.add(resource);
			boolean parseError = parse(builder, resource);
			if (parseError) {
				m_failedFeatures.add(resource.getPath());
			}
		}
	}

	public boolean parse(FeatureBuilder builder, Resource resource) throws IOException {
		String gherkin = read(resource);
		boolean parseError = false;

		Parser<GherkinDocument> parser = new Parser<GherkinDocument>(new AstBuilder());
		TokenMatcher matcher = new TokenMatcher();
		try {
			GherkinDocument gherkinDoc = parser.parse(gherkin, matcher);
			String tags = gherkinDoc.getFeature().getTags().stream().map(Tag::getName).collect(Collectors.joining(","));
			if (tags.trim().equalsIgnoreCase(""))
				tags = "No tag defined for the feature :" + resource.getAbsolutePath();
			m_lstrFeatureTags.add(tags);
		} catch (Exception e) {
			parseError = true;
		}

		return parseError;
	}

	public String read(Resource resource) {
		try {
			String source = Encoding.readFile(resource);
			return source;
		} catch (IOException e) {
			throw new CucumberException("Failed to read resource:" + resource.getPath(), e);
		}
	}

	private int countComponents(List<ComponentType> p_List, String p_Name) {
		int iCount = 0;
		for (ComponentType componentType : p_List) {
			if (componentType.getName().equals(p_Name))
				iCount++;
		}
		return iCount;
	}

	public List<String> listOfDuplicateComponents() throws DependencyResolutionRequiredException, ClassNotFoundException, IOException {
		List<String> listDupeComponents = new ArrayList<String>();
		listDupeComponents.clear();
		m_listComponents.clear();
		m_listComponents = retrieveComponentsFromEclipse();
		for (ComponentType strEclipse : m_listComponents) {
			if (countComponents(m_listComponents, strEclipse.getName()) > 1) {
				if (!listDupeComponents.contains(strEclipse.getName()))
					listDupeComponents.add(strEclipse.getName());
			}
		}
		return listDupeComponents;
	}

	private List<ComponentType> retrieveComponentsFromEclipse() throws DependencyResolutionRequiredException, ClassNotFoundException, IOException {

		File libsFolder = new File(projectBuildDirectory + "/libs");
		String[] compJars = libsFolder.list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".jar");
			}
		});

		List<URL> pathUrls = new ArrayList<>();
		List<String> jarPaths = new ArrayList<>();
		for (String compJarPath : compJars) {
			jarPaths.add(projectBuildDirectory + "/libs/" + compJarPath);
			pathUrls.add(new File(projectBuildDirectory + "/libs/" + compJarPath).toURI().toURL());
		}

		URL[] urlsForClassLoader = pathUrls.toArray(new URL[pathUrls.size()]);
		ClassLoader classLoader = new URLClassLoader(urlsForClassLoader);

		ResourceLoader resourceLoader = new MultiLoader(classLoader);
		ClassFinder classFinder = new ResourceLoaderClassFinder(resourceLoader, classLoader);
		Collection<Class<?>> componentClasses = classFinder.getDescendants(Object.class, packageName("com.adp.wfnddt.components"));

		List<ComponentType> lstrComponents = new ArrayList<ComponentType>();
		ComponentType compType = new ComponentType();

		// Find the components
		try {
			for (Class<?> componentClass : componentClasses) {
				while (componentClass != null && componentClass != Object.class && !Utils.isInstantiable(componentClass)) {
					componentClass = componentClass.getSuperclass();
				}

				if (componentClass != null) {
					for (Method method : componentClass.getMethods()) {
						String compName = getComponentName(method, method.getAnnotations());
						if (!compName.equalsIgnoreCase("")) {
							compType = new ComponentType();
							compType.setName(compName);
							lstrComponents.add(compType);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return lstrComponents;
	}

	private String getComponentName(Method method, Annotation[] arrAnnotations) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		String compName = "";
		for (Annotation annotation : arrAnnotations) {
			if (annotation.annotationType().getName().equalsIgnoreCase("com.adp.wfnddt.aspects.Component"))
				return annotation.annotationType().getMethod("Name").invoke(annotation).toString();
		}
		return compName;
	}

	public List<String> findDuplicateFeatureTags() throws MojoExecutionException {
		List<String> lstrReportedList = new ArrayList<String>();
		lstrReportedList.clear();
		try {
			if (m_lstrFeatureTags.size() < 1)
				getLog().info("Feature File Listing is blank");
			for (String strTag : m_lstrFeatureTags) {
				if (m_lstrFeatureTags.indexOf(strTag) != m_lstrFeatureTags.lastIndexOf(strTag) && lstrReportedList.indexOf(strTag) < 0) {
					lstrReportedList.add(strTag);
				} else if (strTag.startsWith("No tag defined")) {
					lstrReportedList.add(strTag);
				}
			}
		} catch (Exception e) {
			throw new MojoExecutionException(e.getMessage());
		}
		return lstrReportedList;
	}

}
