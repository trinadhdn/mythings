package com.adp.wfnddt.core;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;

import org.antlr.runtime.RecognitionException;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.excelcomparison.ExcelCompare;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

import edu.gatech.gtri.orafile.Orafile;
import edu.gatech.gtri.orafile.OrafileDict;
import edu.gatech.gtri.orafile.OrafileVal;
import oracle.jdbc.OracleDriver;

public class DBInteractions {
	private static Logger m_logger = DDTLoggerManager.getLogger(OracleScriptServicesProxy.class);
	DDTResultsReporter m_results = DDTController.getResultsReporter();

	public void runScriptExecutor(String p_SQLData, String p_VPDKey, String p_DBInstance, String p_Schema, String p_Password, String p_SkipVPD) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException, SQLException {

		String sqlstmt = p_SQLData;
		String m_JDBC_URL = "";
		String[] sqlstrArray;
		sqlstmt = General.replaceParameterKeyWords(sqlstmt);
		sqlstrArray = sqlstmt.split("--");

		m_JDBC_URL = getJDBCURL(p_DBInstance, p_Schema, p_Password);
		Connection DBConn;
		DriverManager.registerDriver(new OracleDriver());
		DBConn = DriverManager.getConnection(m_JDBC_URL);

		try {
			m_logger.info("Connecting to DB Instance : " + p_DBInstance);
			Statement statement = DBConn.createStatement();
			if (!p_VPDKey.contentEquals("")) {
				m_logger.info("Setting VPD Context");
				statement.execute("call sp_seT_vpd_Ctx('" + p_VPDKey + "','adp',spv_prod_locale=>'UN')");
				m_logger.info("Executed VPD Context call sp_seT_vpd_Ctx('" + p_VPDKey + "','adp',spv_prod_locale=>'UN')");
			}
			for (int i = 0; i < sqlstrArray.length; i++) {
				if (sqlstrArray[i].trim().endsWith(";") && !sqlstrArray[i].trim().toUpperCase().endsWith("END;"))
					sqlstrArray[i] = sqlstrArray[i].trim().replaceAll(".$", "");
				m_logger.info("SQL to be executed : " + sqlstrArray[i].trim());
				statement.execute(sqlstrArray[i].trim());
			}
			DBConn.commit();
			m_logger.info("Transaction Commit Completed");
		} catch (Exception ex) {
			DBConn.rollback();
			m_logger.info("Execption Occured while executing Query , Transaction rolled back Successfully");
			throw new DDTFrameworkException(DBInteractions.class, "Exception at Connecting to DB", ex);
		} finally {
			DBConn.close();
			m_logger.info("DB Connection Closed Successfully");
		}
		return;

	}

	public void runScriptVerifyData(String p_SQLData, String p_ResultsFile, String p_VPDKey, String p_DBInstance, String p_Schema, String p_Password, String p_SkipVPD) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException, SQLException {

		boolean isCompareSingleSheet = false;
		String strSheetName = "";
		String srtQuery = "";
		p_SQLData = General.replaceParameterKeyWords(p_SQLData);
		String[] sqlstrArray = p_SQLData.split(System.getProperty("line.separator"));

		// Creating Map for Query Sheet Name
		LinkedHashMap<String, String> sqlQueryMap = new LinkedHashMap<String, String>();
		if (!p_SQLData.contains("--")) {
			sqlQueryMap.put(p_SQLData, "Sheet1");
			isCompareSingleSheet = true;
		} else {
			for (int i = 0; i <= sqlstrArray.length - 1; i++) {
				if (!sqlstrArray[i].startsWith("--")) {
					if (srtQuery.length() == 0)
						srtQuery = sqlstrArray[i];
					else
						srtQuery = srtQuery + System.getProperty("line.separator") + sqlstrArray[i];
				} else {
					strSheetName = sqlstrArray[i].replaceAll("--", "").trim();
					if (srtQuery.trim().endsWith(";") && !srtQuery.trim().toUpperCase().endsWith("END;"))
						srtQuery = srtQuery.trim().replaceAll(".$", "");
					sqlQueryMap.put(srtQuery, strSheetName);
					srtQuery = "";
				}
			}
		}

		m_logger.info("Connecting to DB Instance : " + p_DBInstance);
		String m_JDBC_URL = getJDBCURL(p_DBInstance, p_Schema, p_Password);
		Connection DBConn;
		DriverManager.registerDriver(new OracleDriver());
		DBConn = DriverManager.getConnection(m_JDBC_URL);
		m_logger.info("Successfully Connected to DB Instance : " + p_DBInstance);

		try {

			Statement statement = DBConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			if (!p_VPDKey.contentEquals("")) {
				m_logger.info("Setting VPD Context");
				statement.execute("call sp_seT_vpd_Ctx('" + p_VPDKey + "','adp',spv_prod_locale=>'UN')");
				m_logger.info("Executed VPD Context call sp_seT_vpd_Ctx('" + p_VPDKey + "','adp',spv_prod_locale=>'UN')");
			}
			// Build Run Time Excel File from Query Data
			m_logger.info("Creating Excel Workbook for Comparison");
			HSSFWorkbook workbook = new HSSFWorkbook();
			Set<Map.Entry<String, String>> st = sqlQueryMap.entrySet();
			for (Map.Entry<String, String> me : st) {
				if (me.getValue().toString().contentEquals("")) {
					// Skip Verification and Execute Query
					m_logger.info("No Result Set Query is being executed : '" + me.getKey().toString().replaceAll("\n", "").replaceAll("\r", "") + "'");
					statement.execute(me.getKey().toString());
				} else {
					HSSFSheet sheet = workbook.createSheet(me.getValue().toString());
					HSSFRow rowhead = sheet.createRow((short) 0);
					m_logger.info("Result Set Query is being executed : '" + me.getKey().toString().replaceAll("\n", "").replaceAll("\r", "") + "'");
					ResultSet rs = statement.executeQuery(me.getKey().toString());
					ResultSetMetaData rsmd = rs.getMetaData();
					int colCount = rsmd.getColumnCount();
					m_logger.info("Creating Sheet named " + me.getValue().toString() + " for Query : '" + me.getKey().toString().replaceAll("\n", "").replaceAll("\r", "") + "'");
					for (int i = 1; i <= colCount; i++) {
						rowhead.createCell((short) i - 1).setCellValue(rsmd.getColumnName(i));
					}
					int j = 1;
					while (rs.next()) {
						HSSFRow row = sheet.createRow((short) j);
						// Adding rows to Excel File
						for (int i = 1; i <= colCount; i++) {
							row.createCell((short) i - 1).setCellValue(rs.getString(i));
						}
						j++;
					}
					rs.close();
				}
			}

			DBConn.commit();

			String tempXLFileLocation = "c:/temp/destination.xlsx";
			FileOutputStream fileOut = new FileOutputStream(tempXLFileLocation);
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();
			statement.close();

			m_logger.info("Excel File Creating Completed Successfully");
			m_logger.info("Excel File Comparison Started");
			if (isCompareSingleSheet)
				ExcelCompare.compareTwoSpreadSheets(p_ResultsFile, tempXLFileLocation, new String[] { "1" });
			else
				ExcelCompare.compareTwoSpreadSheets(p_ResultsFile, tempXLFileLocation, new String[] { "" });
			m_logger.info("Excel File Comparison Completed");
		} catch (Exception ex) {
			DBConn.rollback();
			m_logger.info("Execption Occured while executing Query , Transaction rolled back Successfully");
			throw new DDTFrameworkException(DBInteractions.class, "Exception at Connecting to DB", ex);
		} finally {
			DBConn.close();
			Files.deleteIfExists(Paths.get("c:/temp/SourceData.xlsx"));
			m_logger.info("DB Connection Closed Successfully");
		}
		return;

	}

	public void runScriptVerifySimpleData(String p_SQLData, String p_Results, String p_VPDKey, String p_DBInstance, String p_Schema, String p_Password, String p_SkipVPD) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException, SQLException {

		String sqlstmt = p_SQLData;
		String m_JDBC_URL = "";
		sqlstmt = General.replaceParameterKeyWords(sqlstmt);
		ResultSet rs;
		String columnValue = null;
		String p_ActualResults = "";

		if (sqlstmt.trim().endsWith(";") && !sqlstmt.trim().toUpperCase().endsWith("END;"))
			sqlstmt = sqlstmt.trim().replaceAll(".$", "");

		m_JDBC_URL = getJDBCURL(p_DBInstance, p_Schema, p_Password);
		Connection DBConn;
		DriverManager.registerDriver(new OracleDriver());
		DBConn = DriverManager.getConnection(m_JDBC_URL);

		try {
			m_logger.info("Connecting to DB Instance : " + p_DBInstance);
			Statement statement = DBConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			m_logger.info("Query being Executed: " + sqlstmt);
			if (!p_VPDKey.contentEquals("")) {
				m_logger.info("Setting VPD Context");
				statement.execute("call sp_seT_vpd_Ctx('" + p_VPDKey + "','adp',spv_prod_locale=>'UN')");
				m_logger.info("Executed VPD Context call sp_seT_vpd_Ctx('" + p_VPDKey + "','adp',spv_prod_locale=>'UN')");
			}
			rs = statement.executeQuery(sqlstmt);
			ResultSetMetaData rsmd = rs.getMetaData();
			int colCount = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= colCount; i++) {
					columnValue = rs.getString(i);
					if (i > 1)
						p_ActualResults = p_ActualResults + "[+]" + columnValue;
					else
						p_ActualResults = p_ActualResults + columnValue;
				}
				if (!rs.isLast())
					p_ActualResults = p_ActualResults + "\n";
			}
			if (p_ActualResults.contentEquals(""))
				p_ActualResults = "[NO ROWS FOUND]";
			m_results.addTestStep("VERIFY DB DATA");
			m_results.startVerificationLogStep();
			if (p_ActualResults.equalsIgnoreCase(p_Results)) {
				m_results.addEntryToVerificationLog("Verification of DB Data", StatusType.PASSED, p_ActualResults, p_Results);
				m_results.endVerificationLogStep(StatusType.PASSED);
				m_results.endTestStep(StatusType.PASSED);
			} else {
				m_results.addEntryToVerificationLog("Verification of DB Data", StatusType.FAILED, p_ActualResults, p_Results);
				m_results.endVerificationLogStep(StatusType.FAILED);
				m_results.endTestStep(StatusType.FAILED);
			}
			m_logger.info("Query Execution Completed");
		} catch (Exception ex) {
			DBConn.rollback();
			m_logger.info("Execption Occured while executing Query , Transaction rolled back Successfully");
			throw new DDTFrameworkException(DBInteractions.class, "Exception at Connecting to DB", ex);
		} finally {
			DBConn.close();
			m_logger.info("DB Connection Closed Successfully");
		}
		return;

	}

	public String getJDBCURL(String p_DBInstance, String p_UserName, String p_Password) throws IOException {

		InputStream tnsNames = DBInteractions.class.getResourceAsStream("/tnsnames.ora");
		String strtnsNames = inputStreamToString(tnsNames, "UTF-8");

		OrafileDict tns = null;
		try {
			tns = Orafile.parse(strtnsNames.toString());
		} catch (RecognitionException e) {
			e.printStackTrace();
		}

		OrafileVal theapplication = tns.get(p_DBInstance).get(0);
		List<Map<String, String>> values = theapplication.findParamAttrs("address", Arrays.asList("host", "port"));
		String strhost = values.get(0).get("host");
		String strPortNumber = values.get(0).get("port");

		return "jdbc:oracle:thin:" + p_UserName + "/" + p_Password + "@//" + strhost + ":" + strPortNumber + "/" + p_DBInstance;
	}

	public String inputStreamToString(InputStream inputStream, String charset) throws IOException {

		StringBuilder stringBuilder = new StringBuilder();
		String line = null;

		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, charset))) {
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
			}
		}

		return stringBuilder.toString();
	}

}