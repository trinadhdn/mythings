package com.adp.wfnddt.objectmanager.mobile;

import org.openqa.selenium.WebElement;

import com.adp.wfnddt.objectmanager.WebButton;

public class AppButton extends WebButton {

	public AppButton(String p_selector) {
		super(p_selector);
	}
	
	public AppButton(WebElement p_object) {
		super(p_object);
	}

}
