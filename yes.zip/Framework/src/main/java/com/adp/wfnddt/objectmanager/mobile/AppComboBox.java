package com.adp.wfnddt.objectmanager.mobile;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.objectmanager.WebComboBox;

import io.appium.java_client.AppiumDriver;

public class AppComboBox extends WebComboBox {

	private AppiumDriver<WebElement> m_AppDriver = DDTController.getMobileDriver();

	public AppComboBox(String p_selector) {
		super(p_selector);
	}

	public AppComboBox(WebElement p_object) {
		super(p_object);
	}

	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void select(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;
		findObject();
		waitForVisibility();

		// Click on the listbox
		getObject().click();
		General.sleep(2);

		// Wait for the options to appear or retry
		if (getObject().findElements(By.xpath("XPATH.//android.widget.ListView")).size() == 0) {
			getObject().click();
		}

		if (getObject().findElements(By.xpath(".//android.widget.EditText[@text='Select box']")).size() > 0) {
			getObject().findElement(By.xpath(".//android.widget.EditText[@text='Select box']")).sendKeys(p_value);
			General.sleep(2);
			m_AppDriver.hideKeyboard();
		}

		getObject().findElement(By.xpath(".//android.widget.ListView//android.view.View[@text='" + p_value + "']")).click();
	}
}
