package com.adp.wfnddt.objectmanager.extendedobjects;

import com.adp.wfnddt.objectmanager.WebLink;

public class DeleteIcon extends WebLink {
	public DeleteIcon() {
		super("CSS:span.fa.fa-trash-o");
	}
}
