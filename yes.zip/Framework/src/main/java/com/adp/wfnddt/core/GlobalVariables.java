 package com.adp.wfnddt.core;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class GlobalVariables {
	private static String m_loadFiles_Server;
	private final static String m_automationUNCDrive = "\\\\cdlisilon01-cifs.cdl.rose.us.adp\\wfn\\automation";
	private static String m_dbEnvID;
	private static String m_sellingRegion;
	private static String m_clientIDPrefix;
	private static String m_url;
	private static String m_clientID;
	private static String m_langPref = "US";
	private static String m_systemDB = "";
	private static String m_clientDB = "";
	private static String m_dbSchema = "";
	private static String m_vPDKey = "";
	private static String m_buildNumber = "";
	private static String m_splunkIndex = "";
	private static String m_splunkWebURL = "https://splunkcdl.es.ad.adp.com/en-US/app/search/search";
	// private static String m_splunkAPIURL="cdlsplnksh02.es.ad.adp.com";
	private static String m_splunkAPIURL = "splunkcdlapi.es.oneadp.com";
	private static byte m_resultCode = 0;
	private static Integer m_splunkAPIPort = 443;

	private static HashMap<String, String> globalMap = new LinkedHashMap<>();
	private static HashMap<String, List<String>> globalListMap = new LinkedHashMap<>();
	private static ScrollType m_scrollType = ScrollType.Default;
	private static ClearTextType m_ClearTextType = ClearTextType.Default;
	private static String m_xPixels = "";
	private static String m_yPixels = "";

	public enum ScrollType {
		SkipScroll, ScrollIntoView, ScrollBy, Default, ScrollDown, ScrollTop ,ScrollByElement
	}

	public enum ClearTextType {
		Default, SkipClear, Clear, ClearRTE, ClearKeys, JSClear
	}

	public enum CharSet {
		UTF8, ISO_8859_1
	}

	// m_ClientType: US;NAPR;AUTOPAY_US;AUTOPAY_XB;AUTOPAY_NAPR
	public static void initialize(String clientType) {

		if (clientType == null) {
			clientType = "US";
		}

		switch (DDTController.getWfnEnvironment()) {
		case "DIT1":
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\wfndit1\\wfn";
			m_url = "https://wfn-dit1.nj.adp.com";
			m_splunkIndex = "wfn_dit1*";
			break;
		case "DIT2":
			m_systemDB = "WFNSYS1D_SVC1";
			m_clientDB = "wfc32d_svc1";
			m_dbSchema = "WFN10SCH00032";
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\wfndit2\\wfn";
			m_sellingRegion = "0055";
			m_url = "https://wfn-dit.nj.adp.com";
			m_splunkIndex = "wfn_dit2*";
			if (clientType.equals("NAPR")) {
				m_langPref = "CA";
				m_dbEnvID = "wfn_dit2_ddt_nap";
				m_clientIDPrefix = "AUTOND2";
			} else {
				m_dbEnvID = "wfn_dit2_ddt";
				m_clientIDPrefix = "AUTOUD2";
			}
			break;
		case "FIT1":
			m_systemDB = "WFNSYS1Q_SVC1";
			m_clientDB = "wfc33q_svc1";
			m_dbSchema = "WFN14AUTOFIT1";
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\wfnfit1\\wfn";
			m_sellingRegion = "0051";
			m_url = "https://wfn-fit.nj.adp.com";
			m_splunkIndex = "wfn_fit1*";
			if (clientType.equals("NAPR")) {
				m_langPref = "CA";
				m_dbEnvID = "wfn_fit1_ddt_nap";
				m_clientIDPrefix = "AUTCF";
			} else {
				m_dbEnvID = "wfn_fit1_ddt";
				m_clientIDPrefix = "AUTUF";
			}
			break;
		case "FIT2":
			m_loadFiles_Server = "\\\\cdlisilon01-fs4.es.oneadp.com\\wfnfit2\\wfn";
			m_url = "https://wfn-fit-n.nj.adp.com";
			m_splunkIndex = "wfn_fit2*";
			break;
		case "AUTO1":
			m_systemDB = "WFNSYS3Y_SVC1";
			m_clientDB = "wfc28y_svc1";
			m_dbSchema = "WFN10SCH00028";
			m_loadFiles_Server = "\\\\cdlenc1inasv8.es.oneadp.com\\auto1_wfnloadfiles\\wfn";
			m_sellingRegion = "AUT1";
			// m_url ="https://online-ipe.nj.adp.com/wfnauto1/login.html";
			m_url = "https://wfn-auto1.nj.adp.com";
			m_clientIDPrefix = "AUT1";
			m_splunkIndex = "wfn_auto1_main";
			if (clientType.equals("NAPR")) {
				m_langPref = "CA";
				m_dbEnvID = "wfn_aut1_nap";
			} else if (clientType.startsWith("AUTOPAY")) {
				if (clientType.equals("AUTOPAY_US")) {
					m_dbEnvID = "wfn_aut1_ap";
					m_sellingRegion = "0029";
					m_clientIDPrefix = "AUTP1U";
				}

				if (clientType.equals("AUTOPAY_XB")) {
					m_dbEnvID = "wfn_aut1_ap";
					m_sellingRegion = "0029";
					m_clientIDPrefix = "AUTP1X";
				}
				if (clientType.equals("AUTOPAY_NAPR")) {
					m_dbEnvID = "wfn_aut1_ap_nap";
					m_langPref = "CA";
					m_sellingRegion = "0082";
					m_clientIDPrefix = "AUTP1C";
				}

			} else {
				m_dbEnvID = "wfn_aut1";
			}
			break;
		case "AUTO2":
			m_systemDB = "WFNSYS5Y_SVC1";
			m_clientDB = "WFC30Y_SVC1";
			m_dbSchema = "WFN13SCH01715";
			m_loadFiles_Server = "\\\\cdlisilon01-fs4.es.oneadp.com\\auto2_wfnloadfiles\\wfn";
			m_sellingRegion = "AUT2";
			// m_url ="https://online-ipe.nj.adp.com/wfnauto2/login.html";
			m_url = "https://wfn-auto2.nj.adp.com";
			m_clientIDPrefix = "AUT2";
			m_splunkIndex = "wfn_auto1_main";
			if (clientType.equals("NAPR")) {
				m_langPref = "CA";
				m_dbEnvID = "wfn_aut2_nap";
			} else if (clientType.startsWith("AUTOPAY")) {
				m_dbEnvID = "wfn_aut2_ap";
				if (clientType.equals("AUTOPAY_US")) {
					m_sellingRegion = "0029";
					m_clientIDPrefix = "AUTP2U";
				}

				if (clientType.equals("AUTOPAY_XB")) {
					m_sellingRegion = "0029";
					m_clientIDPrefix = "AUTP2X";
				}
				if (clientType.equals("AUTOPAY_NAPR")) {
					m_langPref = "CA";
					m_sellingRegion = "0086";
					m_clientIDPrefix = "AUTP2C";
				}

			} else {
				m_dbEnvID = "wfn_aut2";
			}
			break;
		case "IPEFULL":
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\wfnipe1\\wfn";
			m_sellingRegion = "0048";
			m_url = "https://wfn-ipe.nj.adp.com";
			m_clientIDPrefix = "WFNAUTO";
			m_dbEnvID = "wfn41_ipe";
			m_splunkIndex = "wfn_ipe1_main";
			break;
		case "IPESLIM":
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\wfnipe1\\wfn";
			m_sellingRegion = "0038";
			m_url = "https://wfn-ipe.nj.adp.com";
			m_clientIDPrefix = "AUTOWFN";
			m_dbEnvID = "wfn_ipe_slim";
			m_splunkIndex = "wfn_ipe1_main";
			break;
		case "AWS_FIT1":
			m_systemDB = "WPS01Q_SVC1";
			m_clientDB = "wpc01q_svc1";
			m_dbSchema = "WFNPISCH00001";
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\auto1_wfnloadfiles\\wfn"; //Unknown right now
			m_sellingRegion = "00PR";
			// m_url ="https://online-ipe.nj.adp.com/wfnauto1/login.html";
			m_url = "https://wfncloud-fit.nj.adp.com";
			m_clientIDPrefix = " AWSAF";
			m_splunkIndex = "wfn_fit1_aws_main";
			m_dbEnvID = "wfn_fit1_aws";
			break;
		case "AWS_PREDIT":
			m_systemDB = "WPS01D_SVC1";
			m_clientDB = "awfc04d_svc1";
			m_dbSchema = "WFN17SCH000121";
			m_loadFiles_Server = "\\\\cdlisilon01-fs1.es.oneadp.com\\auto1_wfnloadfiles\\wfn"; //Unknown right now
			m_sellingRegion = "0054";
			m_url = "https://wfncloud-predit.nj.adp.com";
			m_clientIDPrefix = " AWSAD";
			m_splunkIndex = "wfn_dit1_aws_main";
			m_dbEnvID = "wfn_dit_aws";
			break;
		default: // Default to AUTO1
			m_langPref = "US";
			m_loadFiles_Server = "\\\\cdlenc1inasv8.es.oneadp.com\\auto1_wfnloadfiles\\wfn";
			m_sellingRegion = "AUT1";
			m_dbEnvID = "wfn_aut1";
			m_url = "https://wfn-auto1.nj.adp.com";
			m_clientIDPrefix = "AUT1";
			m_splunkIndex = "wfn_auto1_main";
			break;
		}
		return;
	}

	public static String getAutomationUNCDrive() {
		return m_automationUNCDrive;
	}

	public static String getLoadFileUNCDrive() {
		return m_loadFiles_Server;
	}

	public static String getSellingRegion() {
		return m_sellingRegion;
	}

	public static String getDBEnvID() {
		return m_dbEnvID;
	}

	public static String getRuntimeClientID() {
		return m_clientID;
	}

	public static String getClientPrefix() {
		return m_clientIDPrefix;
	}

	public static String getRuntimeURL() {
		return m_url;
	}

	public static String getLanguagePreference() {
		return m_langPref;
	}

	public static String getRuntimeSystemDB() {
		return m_systemDB;
	}

	public static String getRuntimeClientDB() {
		return m_clientDB;
	}

	public static String getRuntimeDBSchema() {
		return m_dbSchema;
	}

	public static String getRuntimeVPDKey() {
		return m_vPDKey;
	}

	public static String getRuntimeBuildNumber() {
		return m_buildNumber;
	}

	public static void setRuntimeClientID(String clientID) {
		GlobalVariables.m_clientID = clientID;
	}

	public static void setRuntimeURL(String runtimeURL) {
		GlobalVariables.m_url = runtimeURL;
	}

	public static void setRuntimeSellingRegion(String runtimeRegion) {
		GlobalVariables.m_sellingRegion = runtimeRegion;
	}

	public static void setRuntimeSystemDB(String runtimeSystemDB) {
		GlobalVariables.m_systemDB = runtimeSystemDB;
	}

	public static void setRuntimeClientSchema(String runtimeClientSchema) {
		GlobalVariables.m_clientDB = runtimeClientSchema;
	}

	public static void setRuntimeVPDSchema(String runtimeVPDSchema) {
		GlobalVariables.m_dbSchema = runtimeVPDSchema;
	}

	public static void setRuntimeVPDKey(String runtimeVPDKey) {
		GlobalVariables.m_vPDKey = runtimeVPDKey;
	}

	public static void setBuildNumber(String wfnBuildNumber) {
		GlobalVariables.m_buildNumber = wfnBuildNumber;
	}

	public static String getVariable(String m_paramName) {
		if (globalMap.containsKey(m_paramName)) {
			return globalMap.get(m_paramName);
		} else {
			return "";
		}
	}

	public static void setVariable(String m_paramName, String m_paramValue) {
		globalMap.put(m_paramName, m_paramValue);
	}

	// Support Run/Save Report in group iteration by storing list of string
	public static List<String> getVariableListValue(String m_paramName) {
		if (globalListMap.containsKey(m_paramName)) {
			return globalListMap.get(m_paramName);
		} else {
			return null;
		}
	}

	public static void setVariableListValue(String m_paramName, List<String> m_paramListValue) {
		globalListMap.put(m_paramName, m_paramListValue);
	}

	public static String getSplunkIndex() {
		return m_splunkIndex;
	}

	public static String getSplunkWebURL() {
		return m_splunkWebURL;
	}

	public static String getSplunkAPIURL() {
		return m_splunkAPIURL;
	}

	public static Integer getSplunkAPIPort() {
		return m_splunkAPIPort;
	}

	public static byte getResultCode() {
		return m_resultCode;
	}

	public static void setResultCode(int p_resultCode) {
		if (p_resultCode > m_resultCode || m_resultCode == 109)
			m_resultCode = (byte) p_resultCode;
	}

	public static ScrollType getScrollType() {
		return m_scrollType;
	}

	public static void setScrollType(ScrollType p_ScrollType) {
		m_scrollType = p_ScrollType;
	}
	public static void setScrollXPixels(String p_xPixels) {
		m_xPixels = p_xPixels;
	}
	
	public static void setScrollYPixels(String p_yPixels) {
		m_yPixels = p_yPixels;
	}
	
	public static String getScrollYPixels() {
		return m_yPixels;
	}
	
	public static String getScrollXPixels() {
		return m_xPixels;
	}
	
	public static ClearTextType getClearTextType() {
		return m_ClearTextType;
	}

	public static void setClearTextType(ClearTextType p_ClearTextType) {
		m_ClearTextType = p_ClearTextType;
	}
}