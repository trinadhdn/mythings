package com.adp.wfnddt.objectmanager.extendedobjects;

import com.adp.wfnddt.objectmanager.WebLink;

public class EditIcon extends WebLink {
	public EditIcon() {
		super("CSS:span.fa.fa-pencil, i.fa.fa-pencil");
	}
}
