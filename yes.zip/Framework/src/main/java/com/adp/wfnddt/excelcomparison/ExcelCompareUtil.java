
package com.adp.wfnddt.excelcomparison;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellAddress;

import com.adp.wfnddt.core.DDTLoggerManager;
import com.google.common.primitives.Ints;

public class ExcelCompareUtil {

	private boolean						m_breakOnFirstMismatch;
	private boolean						m_trimCellValues;
	private SimpleDateFormat			m_dateTimeFormat;
	private String[]					m_excludeCellValues;
	private int[]						m_excludeColumnIndexes;
	private CellAddress[]				m_excludeCellAddresses;
	private int[]				        m_excludeRowIndexes;
	private List<ExcelCompareResult>	m_fileCompareResultList;
	private int[]						m_sheetIndexes				= { 1 };
	private static Logger				m_logger					= DDTLoggerManager.getLogger(ExcelCompareUtil.class);
	private static int					m_sheet_number;

	// These parmeter are to validate the differences
	private int[]						m_ColumnAddressesForChangeInPercentage;
	private Float						m_expectedChangePercentage	= null;
	private String						m_logPercentageChangeDetails;

	public ExcelCompareUtil() {

		this.m_breakOnFirstMismatch = false;
		this.m_trimCellValues = false;
		m_excludeCellValues = new String[] {};
		m_excludeColumnIndexes = new int[] {};
		m_excludeCellAddresses = new CellAddress[] {};
		m_excludeRowIndexes = new int[] {};
		m_dateTimeFormat = new SimpleDateFormat("MM/dd/yyyy");
		m_fileCompareResultList = new ArrayList<ExcelCompareResult>();

		m_logger.setLevel(Level.OFF);

	}

	public void enableLog() {
		m_logger.setLevel(Level.INFO);
	}

	public void enableLog(Level logLevel) {
		m_logger.setLevel(logLevel);
	}

	public void trimCellValues(boolean flag) {
		this.m_trimCellValues = flag;
	}

	public void dateTimeFormat(SimpleDateFormat format) {
		this.m_dateTimeFormat = format;
	}

	public void breakOnFirstMismatch(boolean flag) {
		this.m_breakOnFirstMismatch = flag;
	}

	public List<ExcelCompareResult> getFileCompareResultList() {
		return m_fileCompareResultList;
	}

	public void setFileCompareResultList(List<ExcelCompareResult> fileCompareResultList) {
		this.m_fileCompareResultList = fileCompareResultList;
	}

	public void excludeCellAddresses(CellAddress... cellAddress) {
		this.m_excludeCellAddresses = cellAddress;
	}

	public void excludeColumns(int... columnIndexes) {
		this.m_excludeColumnIndexes = columnIndexes;
	}
	public void excludeRows(int... rowIndexes) {
		this.m_excludeRowIndexes = rowIndexes;
	}
	public void excludeColumns(Integer... columnIndexes) {
		// Converting Integer[] to int[]
		List<Integer> listInteger = Arrays.asList(columnIndexes);
		// Below line works with Java 8 only
		int[] intArray = listInteger.stream().mapToInt(i -> i).toArray();

		this.m_excludeColumnIndexes = intArray;
	}
	public void excludeRows(Integer... rowIndexes) {
		// Converting Integer[] to int[]
		List<Integer> listInteger = Arrays.asList(rowIndexes);
		// Below line works with Java 8 only
		int[] intArray = listInteger.stream().mapToInt(i -> i).toArray();

		this.m_excludeRowIndexes = intArray;
	}
	public void excludeContent(String... regexs) {
		this.m_excludeCellValues = regexs;
	}

	public boolean compareExcelFileContents(File p_xslxFile1, File p_xslxFile2) throws Exception {
		boolean bResult = false;
		FileInputStream excellFile1 = null;
		FileInputStream excellFile2 = null;
		Workbook workbook1 = null;
		Workbook workbook2 = null;
		try {

			m_logger.debug("File 1 : " + p_xslxFile1);
			m_logger.debug("File 2 : " + p_xslxFile2);

			excellFile1 = new FileInputStream(p_xslxFile1);
			excellFile2 = new FileInputStream(p_xslxFile2);

			// Create Workbook instance holding reference to .xlsx file
			workbook1 = WorkbookFactory.create(excellFile1);
			workbook2 = WorkbookFactory.create(excellFile2);

			List<Integer> sheetList = Ints.asList(m_sheetIndexes);
			int iSheetCount = workbook1.getNumberOfSheets();

			for (int index = 0; index < iSheetCount; index++) {
				m_sheet_number = index + 1;
				if (sheetList.contains(m_sheet_number) || sheetList.contains(-1)) {
					// -1 meant for ALL sheets
					// Get first/desired sheet from the workbook
					Sheet sheet1 = workbook1.getSheetAt(index);
					Sheet sheet2 = workbook2.getSheetAt(index);
					// Compare sheets
					bResult = compareTwoSheets(sheet1, sheet2);

					if (bResult) {
						m_logger.info("Sheet " + m_sheet_number + " : content matches with base file");
					} else {
						m_logger.warn("Sheet " + m_sheet_number + " : content does NOT match with base file");
					}
				}
			}

		} catch (Exception e) {
			throw e;
		} finally {
			// close files
			workbook1.close();
			workbook2.close();

			// close input streams
			excellFile1.close();
			excellFile2.close();
		
		}
		return bResult;

	}

	// Compare Two Sheets
	public boolean compareTwoSheets(Sheet p_sheet1, Sheet p_sheet2) {
		int deltaRow = 0;
		int firstRow1 = p_sheet1.getFirstRowNum();
		int lastRow1 = p_sheet1.getLastRowNum();
		int lastRow2 = p_sheet2.getLastRowNum();
		int lastRow = lastRow1;
		
		if (lastRow1 != lastRow2){
			
			if (lastRow1 < lastRow2){
				lastRow = lastRow1;
				deltaRow = lastRow2 - lastRow1;
				for (int iloop =lastRow+1;iloop<=lastRow+deltaRow;iloop++){
					ExcelCompareResult currentRowResult = new ExcelCompareResult();
					currentRowResult.setLocationOfText(String.valueOf("Sheet: " + p_sheet1.getSheetName())) ;
					currentRowResult.setExpectedText("Expected File Missing Row #: "+String.valueOf(iloop));
					currentRowResult.setActualText("Actual File Sheet: "+p_sheet1.getSheetName()+" has extra Row #: "+String.valueOf(iloop));
					currentRowResult.setCompareStatus(false);
					m_fileCompareResultList.add(currentRowResult);
				}
			}
			else {
				lastRow = lastRow2;
				deltaRow = lastRow1 - lastRow2;
				for (int iloop =lastRow+1;iloop<=lastRow+deltaRow;iloop++){
					ExcelCompareResult currentRowResult = new ExcelCompareResult();
					currentRowResult.setLocationOfText(String.valueOf("Sheet: " + p_sheet1.getSheetName())) ;
					currentRowResult.setExpectedText("Expected File Sheet: "+p_sheet1.getSheetName()+" has extra Row #: "+String.valueOf(iloop));
					currentRowResult.setActualText("Actual File Missing Row #: "+String.valueOf(iloop));
					currentRowResult.setCompareStatus(false);
					m_fileCompareResultList.add(currentRowResult);
				}
			}
			
		}
		
		
		boolean equalSheets = true;

		for (int i = firstRow1; i <= lastRow; i++) {

			Row row1 = p_sheet1.getRow(i);
			Row row2 = p_sheet2.getRow(i);

			if (!compareTwoRows(row1, row2)) {
				equalSheets = false;
				m_logger.debug("Row " + i + " - NOT Equal");
				if (m_breakOnFirstMismatch)
					break;
			} else {
				m_logger.debug("Row " + i + " - Equal");
			}

		}
		return equalSheets;
	}

	// Compare Two Rows
	public boolean compareTwoRows(Row p_row1, Row p_row2) {
		
		if ((p_row1 == null) && (p_row2 == null)) {
			return true;
		} else if ((p_row1 == null) || (p_row2 == null)) {
			return false;
		} else if(contains(m_excludeRowIndexes, (p_row1.getRowNum()+1))) {
		return true;		
		}
		int firstCell1 = p_row1.getFirstCellNum();
		int lastCell1 = p_row1.getLastCellNum();
		int lastCell2 = p_row2.getLastCellNum();
		int lastCell = lastCell1;
		boolean equalRows = true;
		if (lastCell1!=lastCell2) {
			m_logger.info("Row: " + p_row1.getRowNum()+1 + " column count does not match");
			ExcelCompareResult currentRowResult = new ExcelCompareResult();
			currentRowResult.setLocationOfText(String.valueOf("Row: " + p_row1.getRowNum()+1) + " column count does not match" ) ;
			currentRowResult.setExpectedText(String.valueOf(lastCell1));
			currentRowResult.setActualText(String.valueOf(lastCell2));
			currentRowResult.setCompareStatus(false);
			m_fileCompareResultList.add(currentRowResult);
			if (lastCell1 > lastCell2){
				lastCell = lastCell2;
	
			}
			return false;
			
		}
		// Compare all cells in a row
		for (int i = firstCell1; i < lastCell; i++) {
			
			
			Cell cell1 = p_row1.getCell(i);
			Cell cell2 = p_row2.getCell(i);

			m_logPercentageChangeDetails = "";
			boolean bCellCompare = true;

//			if (m_compareCellType)
//				bCellCompare = compareTwoCells(cell1, cell2);
//			else
				bCellCompare = compareTwoCellsAsStringValues(cell1, cell2);

			if (!(cell1 == null)) {

				// Start of Reporting code

				String cellValue1 = getCellValueAsString(cell1);
				String cellValue2 = getCellValueAsString(cell2);
				String cellLocation = cell1.getAddress().toString();
				String sheetName = cell1.getSheet().getSheetName();

				String logCellLocation = sheetName + " - Cell : " + cellLocation + "," + m_logPercentageChangeDetails;

				ExcelCompareResult currentRowResult = new ExcelCompareResult();
				currentRowResult.setLocationOfText(logCellLocation);
				currentRowResult.setExpectedText(cellValue1);
				currentRowResult.setActualText(cellValue2);
				currentRowResult.setCompareStatus(bCellCompare);
				m_fileCompareResultList.add(currentRowResult);

				if (!bCellCompare) {
					equalRows = false;

					m_logger.error("[ " + sheetName + " : " + cellLocation + " ] -- NOT matched --");
					m_logger.error("Expected Value [" + cellValue1 + "]");
					m_logger.error("Actual Value   [" + cellValue2 + "]");

					if (i != lastCell1) {
						if (m_breakOnFirstMismatch)
							break;
					}
				} else {
					// if (i != lastCell1)
					// m_logger.debug("\t\tCell " +
					// cell1.getAddress().toString() + " - Equal");
				}
				// End of Reporting code

			}
		}
		return equalRows;
	}

	public boolean compareTwoCellsAsStringValues(Cell p_cell1, Cell p_cell2) {
		if ((p_cell1 == null) && (p_cell2 == null)) {
			return true;
		} else if ((p_cell1 == null) || (p_cell2 == null)) {
			return false;
		}
		m_logger.debug("Verifying " + p_cell1.getAddress());
		String cellValue1 = getCellValueAsString(p_cell1);
		String cellValue2 = getCellValueAsString(p_cell2);
		boolean ignoreCell = true;
		if (contains(m_excludeColumnIndexes, p_cell1.getColumnIndex()))
			return ignoreCell;
		if (contains(m_excludeCellAddresses, p_cell1.getAddress()))
			return ignoreCell;
		if (contains(new String[] { "[IGNORE]" }, cellValue1))
			return ignoreCell;
		if (regExmatch(m_excludeCellValues, cellValue1))
			return ignoreCell;
		if (null != this.m_ColumnAddressesForChangeInPercentage && this.m_ColumnAddressesForChangeInPercentage.length > 0) {
			if (contains(m_ColumnAddressesForChangeInPercentage, p_cell1.getColumnIndex())) {
				// if Number, compare % change
				if (isNumber(cellValue1) )
					return compareChangeInPercentage(cellValue1, cellValue2);
			}
		}
		boolean equalCells = false;
		if (cellValue1.equals(cellValue2)) {
			equalCells = true;
		}
		return equalCells;
	}

	public String getCellValueAsString(Cell p_cell) {
		String cellValue = null;
		if (p_cell ==null){
			return "";
		}
		switch (p_cell.getCellType()) {
		case FORMULA:
			cellValue = p_cell.getCellFormula();
			break;
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(p_cell)) {
				Date date = p_cell.getDateCellValue();
				cellValue = m_dateTimeFormat.format(date);
				m_logger.debug("Cell " + p_cell.getAddress() + " Date Value:" + cellValue);
			} else
				cellValue = String.valueOf(p_cell.getNumericCellValue());
			break;
		case STRING:
			cellValue = p_cell.getStringCellValue();
			break;
		case BLANK:
			cellValue = ""; // null or "" ?
			break;
		case BOOLEAN:
			cellValue = String.valueOf(p_cell.getBooleanCellValue());
			break;
		case ERROR:
			cellValue = String.valueOf(p_cell.getErrorCellValue());
			break;
		default:
			cellValue = p_cell.getStringCellValue();
			break;
		}

		if (m_trimCellValues)
			return cellValue.trim();
		else
			return cellValue;

	}

	private static boolean contains(Object[] p_array, Object p_value) {
		boolean flag = false;
		for (Object obj : p_array) {
			if (obj.equals(p_value)) {
				flag = true;
				return flag;
			}
		}
		return flag;
	}

	private static boolean regExmatch(String[] p_array, String p_value) {
		boolean flag = false;
		for (String objRegEx : p_array) {
			if (p_value.matches(objRegEx)) {
				flag = true;
				return flag;
			}
		}
		return flag;
	}

	private static boolean contains(int[] p_iArray, int p_value) {
		boolean flag = false;
		for (int i : p_iArray) {
			if (i == p_value) {
				flag = true;
				return flag;
			}
		}
		return flag;
	}

	public void setSheetIndexes(int... pSheetIndexes) {
		this.m_sheetIndexes = pSheetIndexes;
	}
	
	// -- This below methods are to support for verification of percentage
	// change in cell value ------ //
	public int[] getColumnIndexesForChangeInPercentage() {
		return m_ColumnAddressesForChangeInPercentage;
	}
	public void setRowIndexes(int... pRowIndexes) {
		this.m_sheetIndexes = pRowIndexes;
	}
	public void setColumnIndexesForChangeInPercentage(int... m_ColumnIndexesForChangePercentageValidations) {
		this.m_ColumnAddressesForChangeInPercentage = m_ColumnIndexesForChangePercentageValidations;
	}

	public float getExpectedChangePercentage() {
		return m_expectedChangePercentage;
	}

	public void setExpectedChangePercentage(float m_expectedChangePercentage) {
		this.m_expectedChangePercentage = m_expectedChangePercentage;
	}

	public boolean compareChangeInPercentage(String cellValue1, String cellValue2) {
		boolean bCellValueWithinRange = false;

		Float m_actualValue;
		Float m_obtainedValue;

		try {
			m_actualValue = Float.parseFloat(cellValue1.replaceAll(",", ""));
			m_obtainedValue = Float.parseFloat(cellValue2.replaceAll(",", ""));

			float percentage = (float) ((m_obtainedValue * 100) / m_actualValue);
			float m_actualChangePercentage = percentage - 100;
			m_actualChangePercentage = (float) (Math.round(m_actualChangePercentage * 100.0) / 100.0);
			int result = Float.compare( m_expectedChangePercentage,m_actualChangePercentage);
			bCellValueWithinRange = result >= 0 ;
			m_logPercentageChangeDetails = "Expected % " + m_expectedChangePercentage + ", Actual   % " + m_actualChangePercentage;
			if (!bCellValueWithinRange) {
				m_logger.error(m_logPercentageChangeDetails);
			}

		} catch (java.lang.NumberFormatException e) {
			m_logger.error("Cell content is NOT a number");
		}
		
		return bCellValueWithinRange;
	}

	public boolean isNumber(String string) {
		if(string.trim().equals("")) return false;
		// assuming integer is in decimal number system
		for (int i = 0; i < string.length(); i++) {
			if (i == 0 && string.charAt(i) == '-')
				continue;
			else if (i > 0 && string.charAt(i) == '.')
				continue;
			else if (i > 0 && string.charAt(i) == ',')
				continue;
			if (!Character.isDigit(string.charAt(i)))
				return false;
		}
		return true;
	}

	// -------------------------------------------------------------------------------------------

}
