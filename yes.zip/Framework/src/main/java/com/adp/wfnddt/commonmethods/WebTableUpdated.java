package com.adp.wfnddt.commonmethods;

import static com.adp.wfnddt.commonmethods.General.sleep;
import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.WebObject;
import com.adp.wfnddt.parammanager.ParamManager;

public class WebTableUpdated {

	private TableType webTableType = null;

	private boolean isEdge() {
		boolean isEdge = false;
		if (DDTController.getBrowserType().equals(BrowserType.Edge))
			isEdge = true;
		return isEdge;
	}

	private enum TableType {
		WFN, DGrid, oDGrid, XLReact, React, MsgCenter, mdfGrid
	}

	public enum SearchType {
		Cell, Row, Col, All
	}

	// ************************************************************ LEVEL 2 *********************************************************
	// Retrieve the row number
	public int retrieveRowNumber(ParamManager pm) {
		int rowNumber = 0;

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().equalsIgnoreCase("ROW_NUMBER") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				if (!pm.getParamMap().get(param).trim().contentEquals("")) {
					rowNumber = Integer.parseInt(pm.getParamMap().get(param).trim());
				}
			}
		}
		return rowNumber;
	}

	// Retrieve the row to find from param manager
	public HashMap<String, String> retrieveRowToFind(ParamManager pm) {
		HashMap<String, String> rowToFind = new LinkedHashMap<>();

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().toUpperCase().startsWith("ROWTOFIND_") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String colName = param.trim().substring(10).toUpperCase();
				rowToFind.put(colName, pm.getParamMap().get(param));
			}
		}
		return rowToFind;
	}

	// Retrieve the Row Instance
	public int retrieveRowInstance(ParamManager pm) {
		int rowInstance = 1;

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("ROW_INSTANCE") || param.trim().equalsIgnoreCase("NUMBER_OF_INSTANCES_TO_FIND")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				rowInstance = Integer.parseInt(pm.getParamMap().get(param).trim());
			}
		}
		return rowInstance;
	}

	// Retrieve the column name
	public String retrieveColumName(ParamManager pm) {
		String colName = "";

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("COL_NAME") || param.trim().equalsIgnoreCase("COLUMN_NAME")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				colName = pm.getParamMap().get(param).trim();
			}
		}
		return colName;
	}

	// Retrieve the row data
	public HashMap<String, String> retrieveRowData(ParamManager pm) {
		HashMap<String, String> rowData = new LinkedHashMap<>();

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().toUpperCase().startsWith("ROWDATA_") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String colName = param.trim().substring(8).toUpperCase();
				rowData.put(colName, pm.getParamMap().get(param));
			}
		}
		return rowData;
	}

	// Retrieve the type of the test to verify list box contents
	public String retrieveTestType(ParamManager pm) {
		String testType = "";

		for (String param : pm.getParamMap().keySet()) {
			if ((param.trim().equalsIgnoreCase("TYPEOFTEST") || param.trim().equalsIgnoreCase("TYPE_OF_TEST")) && !pm.getParamMap().get(param).trim().contentEquals("")) {
				testType = pm.getParamMap().get(param).trim();
			}
		}
		return testType;
	}

	// Retrieve the list box contents
	public String retrieveListBoxContents(ParamManager pm) {
		String listBoxContents = "";

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().equalsIgnoreCase("LB_CONTENTS") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				listBoxContents = pm.getParamMap().get(param).trim();
			}
		}
		return listBoxContents;
	}

	// Retrieve the columns to verify the object properties
	public HashMap<String, String> retrieveColumnsToVerify(ParamManager pm) {
		HashMap<String, String> columnData = new LinkedHashMap<>();

		for (String param : pm.getParamMap().keySet()) {
			if (param.trim().toUpperCase().startsWith("COLUMN_") && !pm.getParamMap().get(param).trim().contentEquals("")) {
				String colName = param.trim().substring(7).toUpperCase();
				columnData.put(colName, pm.getParamMap().get(param));
			}
		}
		return columnData;
	}

	// ************************************************************************************************************************************
	// Perform the operation on the table cell
	public WebElement findObjectInTableCell(WebElement p_table, HashMap<String, String> p_rowToFind, int p_rowInstance, int p_rowNumber, String p_columnName, String p_selector) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		waitTillTableLoads(p_table);
		int iRRow = p_rowNumber;

		if (p_rowNumber <= 0) {
			iRRow = findRowInTable(p_table, p_rowToFind, p_rowInstance);
		}

		if (iRRow < 0) {
			fail("*** Row Not found Error *** - The row with the given criteria is not found in the table");
			return null;
		}

		int iRCol = getColumnIndex(p_table, p_columnName);
		if (iRCol < 0) {
			fail("*** Column Not found Error *** - The column -[" + p_columnName + "] is not found in the table");
			return null;
		}

		WebElement objItem = findTableObject(p_table, SearchType.Cell, p_selector, iRRow, iRCol);

		if (objItem == null) {

			// Added retry logic for identifying WebComboBox, WebTextBox in tables
			WebElement oCellObject = getCellObjectInTable(p_table, iRRow, iRCol);
			new WebObject(oCellObject).click();
			sleep(2);
			objItem = findTableObject(p_table, SearchType.Cell, p_selector, iRRow, iRCol);

			if (objItem == null) {
				return null;
			} else {
				return objItem;
			}

		} else {
			return objItem;
		}
	}

	// This function shall find an object in a table based on the object
	// characteristics and the row/column
	public WebElement findTableObject(WebElement p_table, SearchType p_searchType, String p_selector, Integer p_row, Integer p_col) throws DDTFrameworkException {

		WebElement oTabObj = null;
		int iChildCount;
		int iColCount;
		int iRowCount;

		waitTillTableLoads(p_table);

		// Search on a Row and Column
		switch (p_searchType) {
		case Cell:
			iChildCount = getChildItemCount(p_table, p_row, p_col, p_selector);
			if (iChildCount > 0) {
				oTabObj = getChildItem(p_table, p_row, p_col, p_selector);
			}
			break;

		// Search on a Row
		case Row:
			if (p_col == null) {
				p_col = 1;
			} else if (p_col <= 0) {
				p_col = 1;
			}

			iColCount = getColumnCount(p_table);

			for (int iC = p_col; iC <= iColCount; iC++) {
				iChildCount = getChildItemCount(p_table, p_row, iC, p_selector);
				if (iChildCount > 0) {
					oTabObj = getChildItem(p_table, p_row, p_col, p_selector);
					break;
				}
			}
			break;

		// Search on a column
		case Col:
			iRowCount = getRowCount(p_table);

			for (int iR = 1; iR <= iRowCount; iR++) {
				iChildCount = getChildItemCount(p_table, iR, p_col, p_selector);
				if (iChildCount > 0) {
					oTabObj = getChildItem(p_table, iR, p_col, p_selector);
					break;
				}
			}
			break;

		// Search in the table
		case All:
			By by;
			if (p_selector.toUpperCase().startsWith("CSS:")) {
				by = By.cssSelector(p_selector.substring(4));
			} else if (p_selector.toUpperCase().startsWith("XPATH:")) {
				by = By.xpath(p_selector.substring(6));
			} else {
				by = By.xpath(p_selector);
			}
			
			if(p_table.findElements(by).size()>0){
				oTabObj = p_table.findElement(by);
				break;
			}
		default:
			break;
		}

		return oTabObj;
	}

	// Perform operations on the table objects that are not a part of the grid
	public boolean performTableOps(WebElement oTable, String sAction, int vInput) throws DDTFrameworkException, IOException, DatatypeConfigurationException {

		WebElement oObject;
		boolean bFound = false;

		waitTillTableLoads(oTable);

		// Perform the action
		switch (sAction.toUpperCase()) {
		case "INSERT ROW":
		case "ADD ROW":
			if (getWebTableType(oTable) == TableType.DGrid) {
				oObject = findTableObject(oTable, SearchType.All, "XPATH:.//span[@class='fa fa-plus-circle']", null, null);
			} else {
				oObject = findTableObject(oTable, SearchType.All, "XPATH:.//*[contains(@class,'insertrow')]", null, null);
			}
			// Click the object
			if (oObject != null) {
				oObject.click();
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "DELETE ROW":
			if (getWebTableType(oTable) == TableType.DGrid) {
				oObject = findTableObject(oTable, SearchType.All, "XPATH:.//span[@class='fa fa-minus-circle']", null, null);
			} else {
				oObject = findTableObject(oTable, SearchType.All, "XPATH:.//*[contains(@class,'deleterow')]", null, null);
			}

			// Click the object
			if (oObject != null) {
				oObject.click();
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "NEXT PAGE":
			if (isNextPageEnabled(oTable)) {
				oObject = findTableObject(oTable, SearchType.All, "XPATH:.//a[contains(@id, '_next_link')]", null, null);
			} else {
				oObject = null;
			}

			// Click the object
			if (oObject != null) {
				new WebObject(oObject).click();
				General.waitForGridSpinnerToComplete();
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "SCROLL DOWN":
			int iPrevRowCount = vInput;
			tableScrollDown(oTable);
			int iCurrRowCount = getRowCount(oTable);

			// Retry
			if (iCurrRowCount == iPrevRowCount) {
				tableScrollDown(oTable);
			}

			if (iCurrRowCount > iPrevRowCount) {
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "EXPAND ALL":
			oObject = findTableObject(oTable, SearchType.All, "XPATH:.//span[text()='EXPAND ALL']", null, null);

			// Click the Object
			if (oObject != null) {
				new WebObject(oObject).click();
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "COLLAPSE ALL":
			oObject = findTableObject(oTable, SearchType.All, "XPATH:.//span[text()='COLLAPSE ALL']", null, null);

			// Click the Object
			if (oObject != null) {
				new WebObject(oObject).click();
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "GO TO FIRST PAGE":
			oObject = findTableObject(oTable, SearchType.All, "XPATH:.//a[contains(@id, '_first_link')]/parent::*", null, null);

			// Click the Object
			if (oObject != null && oObject.isDisplayed()) {
				new WebObject(oObject).click();
				General.waitForGridSpinnerToComplete();
				// ClearTableCache
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		case "SELECT ALL":
		case "UNSELECT ALL":
			WebElement oHeadersTable = getHeadersWebTable(oTable);
			oObject = findTableObject(oHeadersTable, SearchType.All, "XPATH:.//input[@type = 'checkbox')]", null, null);

			// Select the button
			if (oObject != null) {
				if (sAction.toUpperCase() == "SELECT ALL") {
					oObject.sendKeys("ON");
				} else if (sAction.toUpperCase() == "UNSELECT ALL") {
					oObject.sendKeys("OFF");
				}
				bFound = true;
			} else {
				bFound = false;
			}
			return bFound;

		}
		return bFound;

	}

	// Find the table row
	public int findRowInTable(WebElement p_table, HashMap<String, String> p_rowToFind, int p_rowInstance) throws DDTFrameworkException, IOException, DatatypeConfigurationException {

		int iRetRow = -1;
		waitTillTableLoads(p_table);

		if (p_rowToFind.size() == 1 && p_rowToFind.containsKey("[BLANK]")) {
			String rowValue = p_rowToFind.get("[BLANK]").trim();
			iRetRow = getRowWithCellText(p_table, rowValue);
		} else {
			iRetRow = findRowMultipleColVals(p_table, p_rowToFind, p_rowInstance, 1);
		}

		return iRetRow;
	}

	// This function shall return the row when a table is searched on multiple
	// column values
	private int findRowMultipleColVals(WebElement p_table, HashMap<String, String> p_rowToFind, int p_rowInstance, int p_startRow) throws DDTFrameworkException, IOException, DatatypeConfigurationException {

		int iRowCount;
		boolean bMatchFound = false;
		int iMCol;
		String sRowVal;
		String sCellData;

		waitTillTableLoads(p_table);

		int iRetRow = -1;
		int iRetCol = -1;
		int iRowFound = 0;

		String[] sColNameArr = p_rowToFind.keySet().toArray(new String[p_rowToFind.size()]);
		String[] sRowValArr = p_rowToFind.values().toArray(new String[p_rowToFind.size()]);

		if (sRowValArr.length == 0) return iRetRow;

		iRowCount = getRowCount(p_table);

		if (iRowCount == 0) iRetRow = 0;
		
		// Find the row matching first input row/value
		for (int iRow = p_startRow; iRow <= iRowCount; iRow++) {

			if (iRetRow == -1) {
				if (sRowValArr[0].trim() == "") {
					break;
				} else if (sRowValArr[0].trim().equalsIgnoreCase("[BLANK]")) {
					sRowVal = "";
				} else {
					sRowVal = sRowValArr[0].trim();
				}

				if (sColNameArr[0].startsWith("[COL_") || sColNameArr[0].startsWith("COL_")) {
					iRetCol = Integer.parseInt(sColNameArr[0].replace("[", "").replace("]", "").trim().substring(4).trim());
				} else {
					iRetCol = getColumnIndex(p_table, sColNameArr[0]);
				}

				sCellData = getCellData(p_table, iRow, iRetCol);
				String sVerifyText = sRowVal;

				if (sRowVal.contains("[REMOVESPACES]")) {
					sCellData = sCellData.replace(" ", "");
					sVerifyText = sRowVal.replace("[REMOVESPACES]", "").replace(" ", "");
				}

				if (sRowVal.contains("[PARTIAL]")) {
					sVerifyText = sVerifyText.replace("[PARTIAL]", "").trim();
					if (sCellData.contains(sVerifyText)) {
						iRetRow = iRow;
					}
				} else if (sCellData.contentEquals(sVerifyText)) {
					iRetRow = iRow;
				}
			}

			// Verify if all the other column/values match
			if (iRetRow >= 0 && !bMatchFound) {
				bMatchFound = true;

				for (int i = 1; i < sColNameArr.length; i++) {
					if (sRowValArr[i].trim() == "") {
						bMatchFound = false;
						break;
					} else if (sRowValArr[i].trim().equalsIgnoreCase("[BLANK]")) {
						sRowVal = "";
					} else {
						sRowVal = sRowValArr[i].trim();
					}

					// Find the column number for the column
					if (sColNameArr[i].startsWith("[COL_") || sColNameArr[i].startsWith("COL_")) {
						iMCol = Integer.parseInt(sColNameArr[i].replace("[", "").replace("]", "").trim().substring(4).trim());
					} else {
						iMCol = getColumnIndex(p_table, sColNameArr[i]);
					}

					if (iMCol >= 0) {
						sCellData = getCellData(p_table, iRetRow, iMCol);
						String sVerifyText = sRowVal;

						if (sRowVal.contains("[REMOVESPACES]")) {
							sCellData = sCellData.replace(" ", "");
							sVerifyText = sRowVal.replace("[REMOVESPACES]", "").replace(" ", "");
						}

						if (sRowVal.contains("[PARTIAL]")) {
							sVerifyText = sVerifyText.replace("[PARTIAL]", "").trim();
							if (!sCellData.contains(sVerifyText)) {
								bMatchFound = false;
								break;
							}
						} else if (!sCellData.toUpperCase().contentEquals(sVerifyText.toUpperCase())) {
							bMatchFound = false;
							break;
						}

					} else {
						bMatchFound = false;
						break;
					}
				}

				if (!bMatchFound) {
					iRetRow = -1;
				} else {
					iRowFound = iRowFound + 1;
					if (p_rowInstance > 0) {
						if (iRowFound != p_rowInstance) {
							iRetRow = -1;
							bMatchFound = false;
						}
					}

				}
			} else if ((iRetRow >= 0) && bMatchFound) {
				break;
			}
		}

		if (iRetRow == -1) {
			if (getWebTableType(p_table) == TableType.oDGrid || getWebTableType(p_table) == TableType.MsgCenter || getWebTableType(p_table) == TableType.XLReact || getWebTableType(p_table) == TableType.React || getWebTableType(p_table) == TableType.mdfGrid) {
				if (performTableOps(p_table, "Scroll Down", iRowCount)) {
					iRetRow = findRowMultipleColVals(p_table, p_rowToFind, p_rowInstance - iRowFound, iRowCount + 1);
				}
			} else {
				if (performTableOps(p_table, "Next Page", 0)) {
					waitTillTableLoads(p_table);
					iRetRow = findRowMultipleColVals(p_table, p_rowToFind, p_rowInstance - iRowFound, 1);
				}
			}
		}

		return iRetRow;
	}

	// Check whether next page is enabled or not
	private boolean isNextPageEnabled(WebElement oTable) throws DDTFrameworkException {
		boolean isNextPageEnabled = false;
		WebElement oObject = findTableObject(oTable, SearchType.All, "XPATH:.//div[contains(@id,'_next') and (@class = 'paginationButton')]", null, null); // changed from OR to AND
		if (oObject != null) {
			if (oObject.isDisplayed()) {
				if (oObject.getAttribute("disabled") == null) isNextPageEnabled = true;
			}
		}
		return isNextPageEnabled;
	}

	// Table to scroll down
	private void tableScrollDown(WebElement oTable) throws DDTFrameworkException {
		// Scroll to the last row displayed
		int iCol;
		int iRowCount = getRowCount(oTable);
		iCol = 1;
		// if (getWebTableType(oTable) == TableType.XLReact) {
		// iCol = 2;
		// } else {
		// iCol = 1;
		// }

		WebElement oLastElem = getChildItem(oTable, iRowCount, iCol, "XPATH:.//*");
		JavascriptExecutor jsExecutor = (JavascriptExecutor) DDTController.getWebDriver();
		jsExecutor.executeScript("arguments[0].scrollIntoView(true);", oLastElem);

		waitTillTableLoads(oTable);

		// Actions actions = new Actions(DDTController.getWebDriver());
		// actions.moveToElement(oLastElem);
		// actions.perform();
		// oLastElem.Highlight;
	}

	public void waitTillTableLoads(WebElement oTable) throws DDTFrameworkException {
		int iTimeOut = 60;
		WebElement oGridTable;

		for (int i = 1; i <= iTimeOut; i++) {
			// sleep(2);
			if (oTable.isDisplayed()) {
				if (getWebTableType(oTable) == TableType.DGrid) {
					oGridTable = getRowsWebTable(oTable, 1);
				} else if (getWebTableType(oTable) == TableType.oDGrid) {
					oGridTable = getRowsWebTable(oTable);
				} else {
					oGridTable = getRowsWebTable(oTable);
				}

				if (oGridTable.isDisplayed()) {
					break;
				}
			}
		}
		// sleep(2);
	}

	// ************************************************************ LEVEL 1
	// *********************************************************
	// Find the Type of Web Table passed in - DGrid or WFN
	private TableType getWebTableType(WebElement p_table) {

		if (webTableType != null) return webTableType;

		int dGridTableCount;
		int xlreactGridCount;
		int reactGridCount;
		int oDGridCount;
		int iMsgCount;
		int mdfGridCount;
		dGridTableCount = p_table.findElements(By.xpath(".//table[@class='dgrid-row-table']")).size();
		xlreactGridCount = p_table.findElements(By.xpath(".//div[contains(@id,'grid') and contains(@id, 'HeadersOuter')]")).size();
		reactGridCount = p_table.findElements(By.xpath(".//div[@class='reactGridHeaders']")).size();
		oDGridCount = p_table.findElements(By.xpath(".//div[contains(@id, '_headerContainer')]")).size();
//		iMsgCount = p_table.findElements(By.xpath(".//table[@class='messagesTable']")).size();
		iMsgCount = p_table.findElements(By.xpath(".//table[contains(@class,'messagesTable')]")).size();
		mdfGridCount= p_table.findElements(By.xpath(".//div[@class='vdl-row mdf-grid-header']")).size();
		//optionsGridCount = p_table.findElements(By.xpath(".//div[@class='table-grid-headers']")).size();

		if (dGridTableCount > 0) {
			webTableType = TableType.DGrid;
		} else if (xlreactGridCount > 0) {
			webTableType = TableType.XLReact;
		} else if (reactGridCount > 0) {
			webTableType = TableType.React;
		} else if (oDGridCount > 0) {
			webTableType = TableType.oDGrid;
		} else if (iMsgCount > 0) {
			webTableType = TableType.MsgCenter;
		} else if (mdfGridCount > 0) {
			webTableType = TableType.mdfGrid;
//		} else if (optionsGridCount > 0) {
//			webTableType = TableType.optionsGrid;
		} else {
			webTableType = TableType.WFN;
		}
		return webTableType;
	}

	// Find the RowObject table in a parent table
	private WebElement getRowsWebTable(WebElement p_table) {
		return getRowsWebTable(p_table, 1);
	}

	private WebElement getRowsWebTable(WebElement p_table, int p_rowIndex) {

		WebElement rowsWebTable = null;
		TableType tableType = getWebTableType(p_table);

		switch (tableType) {
		case DGrid:
			WebElement oRecWebElement = p_table.findElements(By.xpath(".//div[contains(@id,'-row-') and contains(@class,'dgrid-row')]")).get(p_rowIndex - 1);
			List<WebElement> oTableobjs = oRecWebElement.findElements(By.xpath(".//table[@class='dgrid-row-table']"));
			if (oTableobjs.size() > 1) {
				for (int iObjs = 0; iObjs < oTableobjs.size(); iObjs++) {
					List<WebElement> oChildobjs = oTableobjs.get(iObjs).findElements(By.xpath(".//table[@class='dgrid-row-table']"));
					if (oChildobjs.size() > 1) {		//Satya - Added case for handling multiple tables within a row in Dgrid
						rowsWebTable = p_table.findElements(By.xpath(".//div[contains(@id,'-row-') and contains(@class,'dgrid-row')]")).get(p_rowIndex - 1);
						break;
					}else if (oChildobjs.size() > 0) {
						rowsWebTable = oTableobjs.get(iObjs);
						break;
					}
				}
			} else {
				rowsWebTable = oTableobjs.get(0);
			}
			break;

		case XLReact:
			rowsWebTable = p_table.findElement(By.xpath(".//table[contains(@id,'gridTableOuter')]"));
			break;

		case React:
			rowsWebTable = p_table.findElement(By.xpath(".//div[contains(@class,'reactGridRows')]"));
			break;

		case oDGrid:
			rowsWebTable = p_table.findElement(By.xpath(".//div[contains(@id,'_rowContainer')]"));
			break;

		case MsgCenter:
			rowsWebTable = p_table.findElements(By.xpath(".//table[contains(@class,'messagesTable')]")).get(p_rowIndex - 1);
			break;

		case mdfGrid:
			rowsWebTable = p_table.findElement(By.xpath(".//div[@class='vdl-row']"));
			break;
			
//		case optionsGrid:
//			rowsWebTable=p_table.findElements(By.xpath(".//div[contains(@class,'table-grid-rows')]//tr[contains(@id,'_row_')]")).get(p_rowIndex-1);
//			break;
			
		case WFN:
			if (p_table.getAttribute("id").contains("_rows_table")) {
				rowsWebTable = p_table; 	
			} else if (p_table.getAttribute("id").contains("CommentsData")) {
				rowsWebTable = p_table;
			} else if (p_table.getAttribute("id").contains("optionsGrid")) {
				rowsWebTable=p_table.findElement(By.xpath(".//div[contains(@class,'table-grid-rows')]"));
				//rowsWebTable=p_table.findElements(By.xpath(".//div[contains(@class,'table-grid-rows')]//tr[contains(@id,'_row_')]")).get(p_rowIndex-1);
				
			} else if (p_table.getAttribute("id").contains("_table") && !p_table.getAttribute("id").contains("rows_table")) {
				String sHTMLID = p_table.getAttribute("id");
				sHTMLID = sHTMLID.replace("_table", "_rows_table");
				rowsWebTable = p_table.findElement(By.xpath(".//table[@id='" + sHTMLID + "']"));
			} else {
				String sHTMLID = p_table.getAttribute("id") + "_rows_table";
				List<WebElement> rowTables = p_table.findElements(By.xpath(".//table[@id='" + sHTMLID + "']"));

				if (rowTables.size() > 0) {
					rowsWebTable = rowTables.get(0);
				} else {
					rowsWebTable = p_table;
				}
			}

			break;
		}

		return rowsWebTable;

	}

	// Find the HeaderObject table in a parent table
	private WebElement getHeadersWebTable(WebElement p_table) {

		WebElement headersWebTable = null;
		TableType tableType = getWebTableType(p_table);

		switch (tableType) {
		case DGrid:
			List<WebElement> oTableobjs = p_table.findElements(By.xpath(".//table[contains(@id,'-header') and contains(@class,'dgrid-row-table')]"));
			for (int iObjs = 0; iObjs < oTableobjs.size(); iObjs++) {
				List<WebElement> oChildobjs = oTableobjs.get(iObjs).findElements(By.xpath(".//table[contains(@class,'dgrid-row-table')]"));
				if (oChildobjs.size() > 1) {	//Satya - Added case for handling multiple tables within a row in Dgrid
					headersWebTable = p_table.findElements(By.xpath(".//table[contains(@id,'-header') and contains(@class,'dgrid-row-table')]")).get(0);
					break;
				}else if (oChildobjs.size() > 0) {
					headersWebTable = oChildobjs.get(iObjs);
					break;
				} else {
					headersWebTable = oTableobjs.get(iObjs);
				}
			}
			break;

		case XLReact:
			headersWebTable = p_table.findElement(By.xpath(".//table[contains(@id,'gridTableOuter')]"));
			break;

		case React:
			headersWebTable = p_table.findElement(By.xpath(".//div[@class='reactGridHeaders']"));
			break;

		case oDGrid:
			headersWebTable = p_table.findElement(By.xpath(".//div[contains(@id,'_headerContainer')]"));
			break;

		case MsgCenter:
			headersWebTable = p_table.findElements(By.xpath(".//table[@class='messagesTable']")).get(0);
			break;

		case mdfGrid:
			headersWebTable = p_table.findElement(By.xpath(".//div[@class='vdl-row mdf-grid-header']"));
			break;
			
//		case optionsGrid:
//			headersWebTable= p_table.findElement(By.xpath(".//div[@class='table-grid-headers']"));
//			break;
			
		case WFN:
			if (p_table.getAttribute("id").contains("_headers_table")) {
				headersWebTable = p_table;
			} else if (p_table.getAttribute("id").contains("_rows_table")) {
				String sHTMLID = p_table.getAttribute("id").replace("_rows_table", "_headers_table");
				headersWebTable = DDTController.getWebDriver().findElement(By.xpath("//table[@id='" + sHTMLID + "']"));
			} else if (p_table.getAttribute("id").contains("CommentsData")) {
				headersWebTable = p_table;
			} else if (p_table.getAttribute("id").contains("optionsGrid")) {
				headersWebTable = p_table.findElement(By.xpath(".//div[@class='table-grid-headers']"));
			} else if (p_table.getAttribute("id").contains("_table") && !p_table.getAttribute("id").contains("headers_table")) {
				String sHTMLID = p_table.getAttribute("id");
				sHTMLID = sHTMLID.replace("_table", "_headers_table");
				headersWebTable = p_table.findElement(By.xpath(".//table[@id='" + sHTMLID + "']"));
			} else {
				String sHTMLID = p_table.getAttribute("id") + "_headers_table";
				List<WebElement> headerTables = p_table.findElements(By.xpath(".//table[@id='" + sHTMLID + "']"));

				if (headerTables.size() > 0) {
					headersWebTable = headerTables.get(0);
				} else {
					headersWebTable = p_table;
				}
			}
			break;
		}

		return headersWebTable;

	}

	// Get the row count in a table
	public int getRowCount(WebElement p_table) {
		int rowCount = 0;

		TableType tableType = getWebTableType(p_table);

		switch (tableType) {
		case DGrid:
			rowCount = p_table.findElements(By.xpath(".//div[contains(@id,'-row-') and contains(@class,'dgrid-row')]")).size();
			break;

		case oDGrid:
			rowCount = p_table.findElements(By.xpath(".//div[contains(@id,'row_') and @draggable = 'false']")).size();
			break;

		case XLReact:
			WebElement xlReactTable = getRowsWebTable(p_table);
			List<WebElement> xlRowChildObjs = xlReactTable.findElements(By.xpath(".//tr[contains(@id,'gridUnlocked')]"));

			int iMaxRow = -1;
			for (int i = 0; i < xlRowChildObjs.size(); i++) {
				WebElement oRowChild = xlRowChildObjs.get(i);
				int iCount = oRowChild.findElements(By.xpath(".//td")).size();
				if (iCount > 0) {
					String sHTMLID = oRowChild.getAttribute("id");
					String[] aRowCount = sHTMLID.split("\\.");
					int iRowNum = Integer.parseInt(aRowCount[aRowCount.length - 1]);
					if (iRowNum > iMaxRow) {
						iMaxRow = iRowNum;
					}
				}
			}
			rowCount = iMaxRow + 1;
			break;

		case React:
			WebElement oReactTable = getRowsWebTable(p_table);
			rowCount = oReactTable.findElements(By.xpath(".//div[contains(@id,'unlockedRow') and @class='reactGridBodyRow']")).size();
			break;

		case MsgCenter:
//			rowCount = p_table.findElements(By.xpath(".//table[@class='messagesTable']")).size();
			rowCount = p_table.findElements(By.xpath(".//table[contains(@class,'messagesTable')]")).size();
			break;

		case mdfGrid:
			rowCount = p_table.findElements(By.xpath(".//div[contains(@class,'vdl-row mdf-grid-row')]")).size();
			break;

//		case optionsGrid:
//			rowCount =p_table.findElements(By.xpath(".//tr[contains(@id,'_row_')]")).size();
//			break;
			
		case WFN:
			WebElement oRowsTable = getRowsWebTable(p_table);
			rowCount = oRowsTable.findElements(By.xpath(".//tr")).size();
			break;
			
		}

		return rowCount;
	}

	// Get the column count in a table
	private int getColumnCount(WebElement p_table) {
		int colCount = 0;

		TableType tableType = getWebTableType(p_table);
		WebElement headerWebTable = getHeadersWebTable(p_table);

		switch (tableType) {
		case DGrid:
			colCount = headerWebTable.findElements(By.xpath(".//th[(starts-with(@class,'dgrid-cell') and contains(@class,'dgrid-column-') ) or (contains(@class,'dgrid-column-') and contains(@class,'field-'))]")).size();
			break;
		case oDGrid:
			colCount = headerWebTable.findElements(By.xpath(".//div")).size();
			break;
		case XLReact:
			colCount = headerWebTable.findElements(By.xpath(".//th[contains(@class,'ColumnHeader')]")).size();
			break;
		case React:
			colCount = headerWebTable.findElements(By.xpath(".//div[contains(@class,'reactGridHeaderCell')]")).size();
			break;
		case MsgCenter:
			colCount = headerWebTable.findElements(By.xpath(".//td")).size();
			break;
		case mdfGrid:
			colCount = headerWebTable.findElements(By.xpath(".//div[contains(@class,'vdl-col-xs mdf-grid-headerCell')]")).size();
			break;
//		case optionsGrid:
//			colCount =headerWebTable.findElements(By.xpath(".//th[contains(@id,'_header_')]")).size();
//			break;
		case WFN:
			colCount = headerWebTable.findElements(By.xpath(".//th")).size();
			break;			
		}

		return colCount;
	}

	// Get the column index in a table when column name is specified
	public int getColumnIndex(WebElement p_table, String p_colName) {

		int iCol = -1;

		// Fixed Column index
		if (p_colName.contains("COL_")) {
			p_colName = p_colName.replace("[", "").replace("]", "");
			iCol = Integer.parseInt(p_colName.replace("COL_", "").trim());
			return iCol;
		}

		// Blank Column
		if (p_colName.contentEquals("[BLANKCOL]") || p_colName.contentEquals("BLANK")) {
			return 1;
		}

		// Remove the *
		p_colName = p_colName.replace("*", "").trim();

		WebElement headersWebTable = null;
		WebElement rowsWebTable = null;

		TableType tableType = getWebTableType(p_table);
		headersWebTable = getHeadersWebTable(p_table);

		switch (tableType) {
		case DGrid:
			// Get the column index from rows table
			if (p_colName.startsWith("_") && p_colName.endsWith("_")) {
				p_colName = p_colName.trim().substring(1, p_colName.length() - 2);
				rowsWebTable = getRowsWebTable(p_table, 1);
				// Get the cells in a Row
				List<WebElement> oChildObjs = rowsWebTable.findElements(By.xpath(".//td[(starts-with(@class,'dgrid-cell') and contains(@class,'dgrid-column-')) or (contains(@class,'field') and contains(@class,'dgrid-column-'))]"));
				for (int i = 0; i <= oChildObjs.size()-1; i++) {
					String sClass = oChildObjs.get(i).getAttribute("class");
					if (sClass.toUpperCase().replace("*", "").trim().contains("FIELD-" + p_colName.toUpperCase())) {
						iCol = i + 1;
						return iCol;
					}
				}
			} else { // Get the column index from headers table
				List<WebElement> oChildObjs = headersWebTable.findElements(By.xpath(".//th[(starts-with(@class,'dgrid-cell') and contains(@class,'dgrid-column-')) or (contains(@class,'field') and contains(@class,'dgrid-column-'))]"));
				for (int i = 0; i <= oChildObjs.size()-1; i++) {
					String sColText = oChildObjs.get(i).getText();
					if (sColText.contentEquals("")) {		//Retry if getText() is empty
						sColText = oChildObjs.get(i).getAttribute("innerText").trim();
					}
					if (isEdge()) {
						sColText= sColText.replaceAll("\u00A0", " ").trim();
					}
					if (sColText.toUpperCase().replace("*", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
						iCol = i + 1;
						return iCol;
					}
				}
			}
			break;

		case oDGrid:
			// Get the headers
			List<WebElement> oChildObjs = headersWebTable.findElements(By.xpath("./div"));
			for (int i = 0; i <= oChildObjs.size()-1; i++) {
				String sColText = oChildObjs.get(i).getText().trim();
				if (isEdge()) {
					sColText= sColText.replaceAll("\u00A0", " ").trim();
				}
				if (sColText.toUpperCase().replace("*", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
					iCol = i + 1;
					return iCol;
				}
			}
			break;

		case XLReact:
			List<WebElement> oxlColObjects = headersWebTable.findElements(By.xpath(".//div[contains(@id,'HeaderLabel')]"));
			for (int i = 0; i <= oxlColObjects.size()-1; i++) {
				String sColText = oxlColObjects.get(i).getAttribute("innerText");
				sColText = sColText.replace(" ", "");
				if (isEdge()) {
					sColText= sColText.replaceAll("\u00A0", " ").trim();
				}
				p_colName = p_colName.replace(" ", "");

				if (p_colName.contains("[PARTIAL]")) {
					String sColNamePartial = p_colName.replace("[PARTIAL]", "");
					if (sColText.toUpperCase().replace("*", "").trim().contains(sColNamePartial.trim().toUpperCase())) {
						String[] iColArray = oxlColObjects.get(i).getAttribute("class").split("header");
						iCol = Integer.parseInt(iColArray[iColArray.length - 1]) + 1;
						break;
					}
				} else if (sColText.toUpperCase().replace("*", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
					String[] iColArray = oxlColObjects.get(i).getAttribute("class").split("header");
					iCol = Integer.parseInt(iColArray[iColArray.length - 1]) + 1;
					break;
				}
			}
			break;

		case React:
			List<WebElement> oColObjects = headersWebTable.findElements(By.xpath(".//div[contains(@class,'reactGridHeaderCell')]"));
			for (int i = 0; i <= oColObjects.size() - 1; i++) {
				String sColText = oColObjects.get(i).getText();
				sColText = sColText.replace(" ", "");
				if (isEdge()) {
					sColText= sColText.replaceAll("\u00A0", " ").trim();
				}
				p_colName = p_colName.replace(" ", "");

				if (p_colName.contains("[PARTIAL]")) {
					String sColNamePartial = p_colName.replace("[PARTIAL]", "");
					if (sColText.toUpperCase().replace("*", "").trim().contains(sColNamePartial.trim().toUpperCase())) {
						iCol = i + 1;
						break;
					}
				} else if (sColText.toUpperCase().replace("*", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
					iCol = i + 1;
					break;
				}
			}
			break;

		case mdfGrid:
			List<WebElement> mdfColObjects = headersWebTable.findElements(By.xpath(".//div[contains(@class,'vdl-col-xs') and contains(@class,'mdf-grid-headerCell')]"));
			for (int i = 0; i <= mdfColObjects.size()-1; i++) {
				String sColText = mdfColObjects.get(i).getText();
				sColText = sColText.replace(" ", "");
				if (isEdge()) {
					sColText= sColText.replaceAll("\u00A0", " ").trim();
				}
				p_colName = p_colName.replace(" ", "");

				if (p_colName.contains("[PARTIAL]")) {
					String sColNamePartial = p_colName.replace("[PARTIAL]", "");
					if (sColText.toUpperCase().replace("*", "").replace("\n", "").trim().contains(sColNamePartial.trim().toUpperCase())) {
						iCol = i + 1;
						break;
					}
				} else if (sColText.toUpperCase().replace("*", "").replace("\n", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
					iCol = i + 1;
					break;
				}
			}
			break;

		case MsgCenter:
			break;
					
//		case optionsGrid:
//			// Get the headers
//			List<WebElement> opChildObjs = headersWebTable.findElements(By.xpath(".//th"));
//			for (int i = 0; i <= opChildObjs.size()-1; i++) {
//				String sColText = opChildObjs.get(i).getText().trim();
//				if (sColText.toUpperCase().replace("*", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
//					iCol = i + 1;
//					return iCol;
//				}
//			}
//			break;
				
		case WFN:
			List<WebElement> arrColObjects = headersWebTable.findElements(By.xpath(".//th"));
			if (arrColObjects.size() == 0){
				arrColObjects = headersWebTable.findElements(By.xpath(".//thead//td"));
			}
			for (int i = 0; i <= arrColObjects.size()-1; i++) {
				String sColText = arrColObjects.get(i).getText();
				if (isEdge()) {
					sColText= sColText.replaceAll("\u00A0", " ").trim();
				}
				if (p_colName.contains("[PARTIAL]")) {
					String sColNamePartial = p_colName.replace("[PARTIAL]", "");
					if (sColText.toUpperCase().replace("*", "").replace("\n", "").trim().contains(sColNamePartial.trim().toUpperCase())) {
						iCol = i + 1;
						break;
					}
				} else if (sColText.toUpperCase().replace("*", "").replace("\n", "").trim().contentEquals(p_colName.trim().toUpperCase())) {
					iCol = i + 1;
					break;
				}
			}
			break;
		}

		return iCol;
	}

	// Get the Cell Object in a table
	public WebElement getCellObjectInTable(WebElement p_table, int p_rowIndex, int p_colIndex) {
		WebElement oCellObject = null;
		WebElement rowsWebTable = null;

		TableType tableType = getWebTableType(p_table);

		switch (tableType) {
		case DGrid:
			rowsWebTable = getRowsWebTable(p_table, p_rowIndex);

			// Get the cell object in a row
			List<WebElement> oChildObjs = rowsWebTable.findElements(By.xpath(".//td[(starts-with(@class,'dgrid-cell') and contains(@class,'dgrid-column-')) or (contains(@class,'field') and contains(@class,'dgrid-column-'))]"));

			if (oChildObjs.size() >= p_colIndex) {
				oCellObject = oChildObjs.get(p_colIndex - 1);
			} else {
				oCellObject = oChildObjs.get(p_colIndex - 2);
			}
			break;

		case oDGrid:
			rowsWebTable = getRowsWebTable(p_table);
			String sDGridHTMLID = rowsWebTable.getAttribute("id");
			// Get the cell object in a row
			oCellObject = rowsWebTable.findElement(By.xpath("//div[@id='" + sDGridHTMLID + "']//div[contains(@id,'row_" + (p_rowIndex - 1) + "')]/DIV/DIV[" + p_colIndex + "]"));
			break;
			
//		case optionsGrid:
//			rowsWebTable = getRowsWebTable(p_table, p_rowIndex);
//			String optionsGridRowID = rowsWebTable.getAttribute("id");
//			// Get the cell object in a row
//			oCellObject = rowsWebTable.findElement(By.xpath(".//td[@id='" + optionsGridRowID +"_cell_"+ (p_colIndex-1)+"']"));
//			break;

		case XLReact:
			rowsWebTable = getRowsWebTable(p_table);
			// Get the row
			WebElement oLockedRow = rowsWebTable.findElement(By.xpath(".//tr[contains(@id,'gridLocked." + (p_rowIndex - 1) + "')]"));
			WebElement oUnLockedRow = rowsWebTable.findElement(By.xpath(".//tr[contains(@id,'gridUnlocked." + (p_rowIndex - 1) + "')]"));

			// Get the cell object for the row
			List<WebElement> oTDCollLocked = oLockedRow.findElements(By.xpath(".//div[contains(@id,'gridWrapper')]"));
			List<WebElement> oTDCollUnLocked = oUnLockedRow.findElements(By.xpath(".//div[contains(@id,'gridWrapper')]"));

			if (p_colIndex <= oTDCollLocked.size()) {
				oCellObject = oTDCollLocked.get(p_colIndex - 1);
			} else {
				p_colIndex = p_colIndex - oTDCollLocked.size();
				oCellObject = oTDCollUnLocked.get(p_colIndex - 1);
			}

			break;

		case React:
			rowsWebTable = getRowsWebTable(p_table);
			// Get the row
			WebElement oReactLockedRow = rowsWebTable.findElements(By.xpath(".//div[contains(@class,'reactGridBodyRow') and contains(@id,'.lockedRow." + (p_rowIndex - 1) + "')]")).get(0);
			WebElement oReactUnLockedRow = rowsWebTable.findElements(By.xpath(".//div[contains(@class,'reactGridBodyRow') and contains(@id,'.unlockedRow." + (p_rowIndex - 1) + "')]")).get(0);
			
			// Get the cell object for the row
			List<WebElement> oReactTDCollLocked = oReactLockedRow.findElements(By.xpath(".//div[contains(@class,'reactGridBodyRowCell')]"));
			List<WebElement> oReactTDCollUnLocked = oReactUnLockedRow.findElements(By.xpath(".//div[contains(@class,'reactGridBodyRowCell')]"));
						
			// Get the cell object for the Column
			//oCellObject = oReactUnLockedRow.findElement(By.xpath(".//div[contains(@id,'.row." + (p_rowIndex - 1) + ".cell." + (p_colIndex - 1) + "')]"));
			
			if (p_colIndex <= oReactTDCollLocked.size()) {
				oCellObject = oReactTDCollLocked.get(p_colIndex - 1);
			} else {
				p_colIndex = p_colIndex - oReactTDCollLocked.size();
				oCellObject = oReactTDCollUnLocked.get(p_colIndex - 1);
			}

			break;

		case MsgCenter:
			rowsWebTable = getRowsWebTable(p_table, p_rowIndex);

			// Get the cell object in the row
			List<WebElement> oMsgCells = rowsWebTable.findElements(By.xpath(".//td"));

			if (oMsgCells.size() >= p_colIndex) {
				oCellObject = oMsgCells.get(p_colIndex - 1);
			} else {
				oCellObject = oMsgCells.get(p_colIndex - 2);
			}

			break;

		case mdfGrid:
			rowsWebTable = getRowsWebTable(p_table);
			//String mdfGridClass = rowsWebTable.getAttribute("class");
			oCellObject = rowsWebTable.findElement(By.xpath(".//div[@data-index='" + (p_rowIndex - 1) + "' and contains(@class,'vdl-row mdf-grid-row') and not(contains(@class,'no-dnd'))]/DIV[" + (p_colIndex) + "]"));
			break;

		case WFN:
			rowsWebTable = getRowsWebTable(p_table);

			// Added logic to fetch column index based on columns with in a row
			List<WebElement> oRowCellObjects = rowsWebTable.findElements(By.xpath(".//tr[" + p_rowIndex + "]//td"));

			if (oRowCellObjects.size() == 0) {
				oCellObject = rowsWebTable.findElement(By.xpath(".//tr[" + p_rowIndex + "]"));
				return oCellObject;
			} else if (oRowCellObjects.size() < p_colIndex) {
				p_colIndex = oRowCellObjects.size();
			}

			oCellObject = rowsWebTable.findElement(By.xpath(".//tr[" + p_rowIndex + "][not(ancestor::thead)]/td[" + p_colIndex + "]"));
			break;
		}

		return oCellObject;
	}

	// Get the Cell Data in a table
	public String getCellData(WebElement p_table, int p_rowIndex, int p_colIndex) {

		WebElement oCellObject = getCellObjectInTable(p_table, p_rowIndex, p_colIndex);

		//added replace statements to handle verify in few MDF6 WebComboBox values
		String cellData = oCellObject.getText().replace("\n", " ").replace("open dropdown", "").replace("×", "").trim();
		
		if (cellData.contentEquals("")) { 	//retry if getText() is shown empty //mallelak - Added replace for &nbsp in HTML DOM using replace [\\u00A0]+
			cellData = oCellObject.getAttribute("innerText").replace("\n", " ").replace("open dropdown", "").replace("×", "").replaceAll("[\\u00A0]+", " ").trim();
		}

		// Check if the cell has an input box
		List<WebElement> oReactTextBoxDesc = oCellObject.findElements(By.xpath(".//input[starts-with(@class,'reactVDL reactTextBox') or starts-with(@class,'reactVDL selectBox') or contains(@class,'dijitInputInner') or contains(@class,'vdl-textbox')]"));
		if (oReactTextBoxDesc.size() > 0) {
			String sValue = oReactTextBoxDesc.get(0).getText().replace("\n", "").trim();

			if (sValue.contentEquals("")) {	//mallelak - Added replace for &nbsp in HTML DOM using replace [\\u00A0]+
				sValue = oReactTextBoxDesc.get(0).getAttribute("value").replace("\n", " ").replace("open dropdown", "").replace("×", "").replaceAll("[\\u00A0]+", " ").trim();
			}
			cellData = cellData + sValue;
		}

		//check if cell has toggle button
		if (oCellObject.findElements(By.xpath(".//label[contains(@class,'vdl-toggle-switch')]")).size() > 0) {
			if (oCellObject.findElement(By.xpath(".//label[contains(@class,'vdl-toggle-switch')]")).getAttribute("class").contains("checked")){
					cellData="RIGHT";
				}else{ 
					cellData ="LEFT";
			}
	
		}

		return cellData;
	}

	// Get the row with the Cell Text in a table
	public int getRowWithCellText(WebElement p_table, String p_cellText) {

		int iRetRow = -1;

		int iRowCount = getRowCount(p_table);
		int iColCount = getColumnCount(p_table);

		for (int iRow = 1; iRow <= iRowCount; iRow++) {
			for (int iCol = 1; iCol <= iColCount; iCol++) {
				String cellData = getCellData(p_table, iRow, iCol);
				if (p_cellText.contains("[PARTIAL]")) {
					String sPartialCellText = p_cellText.replace("[PARTIAL]", "");
					if (cellData.trim().contains(sPartialCellText.trim())) {
						iRetRow = iRow;
						break;
					}
				} else if (p_cellText.trim().contentEquals(cellData.trim())) {
					iRetRow = iRow;
					break;
				}
			}
			if (iRetRow == iRow) {
				break;
			}
		}

		return iRetRow;
	}

	// Get the child item in a table cell
	private WebElement getChildItem(WebElement p_table, int p_rowIndex, int p_colIndex, String p_selector) {

		WebElement oCellObject = getCellObjectInTable(p_table, p_rowIndex, p_colIndex);
		WebElement oChildItem = null;
		By by = null;

		// Find the object with the appropriate selector
		if (p_selector.toUpperCase().startsWith("CSS:")) {
			by = By.cssSelector(p_selector.substring(4));
		} else if (p_selector.toUpperCase().startsWith("XPATH:")) {
			by = By.xpath(p_selector.substring(6));
		} else {
			by = By.xpath(p_selector);
		}

		if (p_selector.toUpperCase().startsWith("CSS:") || p_selector.toUpperCase().startsWith("XPATH:")) {
			if(oCellObject.findElements(by).size() > 0){
				oChildItem = oCellObject.findElement(by);
			} else {
				oChildItem = oCellObject;
			}
		} else {
			oChildItem = oCellObject;
		}

		return oChildItem;
	}

	// Get the child item count in a table cell
	private int getChildItemCount(WebElement p_table, int p_rowIndex, int p_colIndex, String p_selector) {

		WebElement oCellObject = getCellObjectInTable(p_table, p_rowIndex, p_colIndex);
		By by = null;

		// Find the object with the appropriate selector
		if (p_selector.toUpperCase().startsWith("CSS:")) {
			by = By.cssSelector(p_selector.substring(4));
		} else if (p_selector.toUpperCase().startsWith("XPATH:")) {
			by = By.xpath(p_selector.substring(6));
		} else {
			by = By.xpath(p_selector);
		}

		return oCellObject.findElements(by).size();
	}
}
// *********************************************************************************************************************