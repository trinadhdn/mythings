package com.adp.wfnddt.objectmanager.mobile;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.objectmanager.WebTextBox;

import io.appium.java_client.AppiumDriver;

public class AppTextBox extends WebTextBox {
	
	private AppiumDriver<WebElement> m_AppDriver = DDTController.getMobileDriver();

	public AppTextBox(String p_selector) {
		super(p_selector);
	}

	public AppTextBox(WebElement p_object) {
		super(p_object);
	}
	
	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void set(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals("")) return;

		findObject();
		getObject().clear();
		if (!p_value.equalsIgnoreCase("[BLANK]")) getObject().sendKeys(p_value);
		
		m_AppDriver.hideKeyboard();
		
		return;
	}

}
