package com.adp.wfnddt.mailverification;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.AndTerm;
import javax.mail.search.BodyTerm;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.DateTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;
import javax.mail.search.StringTerm;
import javax.mail.search.SubjectTerm;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;

/**
 * @author UbbaraHa
 */

public class EmailUtil {

	private EmailConfig		m_config		= new EmailConfig();
	private Properties		m_properties	= System.getProperties();
	private static Logger	m_logger		= DDTLoggerManager.getLogger(EmailUtil.class);
	private String			m_mailBoxFolder	= null;
	private Store			m_storeObj		= null;
	private Folder			m_mailFolderObj	= null;
	private SearchTerm		m_searchConditions= null;


	public EmailUtil() {
		m_logger.setLevel(Level.INFO);
	}
	
	public EmailUtil(EmailConfig p_config) {
		this.m_mailBoxFolder = "Inbox";
		this.m_config = p_config;
		m_logger.setLevel(Level.DEBUG);
	}
	
	public EmailConfig getConfig() {
		return this.m_config;
	}

	public void enableLog() {
		m_logger.setLevel(Level.INFO);
	}
	
	public void enableLog(Level logLevel) {
		m_logger.setLevel(logLevel);
	}
	
	public void setConfig(EmailConfig p_config) {
		this.m_config = p_config;
	}
	 
	public void connectToMailBox() throws MessagingException {

		if (m_config.getProtocol().equalsIgnoreCase("imap")) {
			// server setting
			m_properties.put("mail.imap.host", m_config.getHost());
			m_properties.put("mail.imap.port", m_config.getPort());
			// SSL setting
			m_properties.setProperty("mail.imap.socketFactory.port", String.valueOf(m_config.getPort()));
			m_properties.setProperty("mail.imap.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			m_properties.setProperty("mail.imap.socketFactory.fallback", "false");

			Session session = Session.getDefaultInstance(m_properties);
			m_storeObj = session.getStore("imap");

		} else if (m_config.getProtocol().equalsIgnoreCase("pop3s")) {
			m_properties.put("mail.pop3.host", m_config.getHost());
			m_properties.put("mail.pop3.port", m_config.getPort());
			m_properties.put("mail.pop3.starttls.enable", "true");

			Session session = Session.getDefaultInstance(m_properties);
			m_storeObj = session.getStore("pop3s");
		}

		// connect to inbox in read-only mode
		m_storeObj.connect(m_config.getHost(), m_config.getUserId(), m_config.getPassword());

		if (this.m_mailBoxFolder == null || this.m_mailBoxFolder == "")
			m_mailFolderObj = m_storeObj.getDefaultFolder();
		else
			m_mailFolderObj = m_storeObj.getFolder(this.m_mailBoxFolder);

		m_mailFolderObj.open(Folder.READ_WRITE);
	}

	public String getMailFolderToSearch() {
		return m_mailBoxFolder;
	}
 
	public void setMailBoxFolder(String mailFolderToSearch) {
		if( !mailFolderToSearch.equals("") )
			this.m_mailBoxFolder = mailFolderToSearch;
	}

	
	
	public void addSeachCondition(SearchTerm newSearchTerm) {
		if (this.m_searchConditions == null) {
			this.m_searchConditions = newSearchTerm ;
		} else
			this.m_searchConditions = new AndTerm(this.m_searchConditions, newSearchTerm);
	}
	 
	public void addSeachCondition(AndTerm newAndTerm) {
		if (this.m_searchConditions == null)
			this.m_searchConditions = newAndTerm;
		else
			this.m_searchConditions = new AndTerm(this.m_searchConditions, newAndTerm);
	}
	 
	public void addSeachCondition(SearchTerm[] searchTerms) {
		addSeachCondition(new AndTerm(searchTerms));
	}
	
	public void addSeachCondition(ArrayList<SearchTerm> listOfSearchTerms) {
		SearchTerm[] arrSearchTerms =   listOfSearchTerms.toArray(new SearchTerm[0] );
		addSeachCondition(arrSearchTerms);
	}
	
	public SearchTerm getSearchConditions() {
		return m_searchConditions;
	}
	
	public void displaySearchConditions(SearchTerm[] p_searchConditions){
		//m_logger.debug("inside SearchTerm[]");
		for(SearchTerm searchTerm: p_searchConditions)
			displaySearchCondition(searchTerm);
	}
	
	public void displaySearchCondition(SearchTerm p_searchCondition){
		
		if(p_searchCondition instanceof AndTerm){
			SearchTerm[] terms = ((AndTerm) p_searchCondition).getTerms();
			displaySearchConditions(terms);
		}else if(p_searchCondition instanceof ReceivedDateTerm){
			Date date = ((DateTerm) p_searchCondition).getDate();
			m_logger.debug( leftpad("Searching * ReceivedDateTerm : ", date.toString() ) );
		}else if(p_searchCondition instanceof SentDateTerm){
			Date date = ((DateTerm) p_searchCondition).getDate();
			m_logger.debug( leftpad("Searching * SentDateTerm : ", date.toString()) );
		}else if(p_searchCondition instanceof SubjectTerm){
			String pattern = ((StringTerm) p_searchCondition).getPattern();
			m_logger.debug(leftpad("Searching * SubjectTerm : ", pattern	) );
		}else if(p_searchCondition instanceof BodyTerm){
			String pattern = ((StringTerm) p_searchCondition).getPattern();
			m_logger.debug(leftpad("Searching * BodyTerm : ", pattern) );
		}
		else if(p_searchCondition instanceof FromStringTerm){
			String pattern = ((StringTerm) p_searchCondition).getPattern();
			m_logger.debug(leftpad("Searching * FromStringTerm : ", pattern) );
		}
		else if(p_searchCondition instanceof RecipientStringTerm){
			String pattern = ((StringTerm) p_searchCondition).getPattern();
			RecipientType type = ((RecipientStringTerm) p_searchCondition).getRecipientType();
			m_logger.debug(leftpad("Searching * RecipientStringTerm : ", pattern + " [ " + type +" ]"	) );
		}else if(p_searchCondition instanceof FlagTerm){
		    FlagTerm unseenFlag = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
		    if(p_searchCondition.equals(unseenFlag))
			m_logger.debug(leftpad("Searching * FlagTerm : ", "UNSEEN = true (Unread Only)"));
		    else
			m_logger.debug(leftpad("Searching * FlagTerm : ", "UNSEEN = false"));
		}
		
	}
	
	
	
	private void displaySearchInfo(){
		m_logger.debug(leftpad("Searching * folder : " , this.m_mailFolderObj.toString() ) ); 
		displaySearchCondition(this.m_searchConditions);
	}
	
	public Message[] searchMails() throws MessagingException, IOException {
		
		displaySearchInfo();
		
		Message[] messages;
		messages = this.m_mailFolderObj.search(this.m_searchConditions);
		if (messages.length == 0)
			m_logger.info(leftpad("Searching * Result : ", "No messages found with the Search Criteria"));
		else
			m_logger.info(leftpad("Searching * Result : ",  messages.length + " messages found with the Search Criteria"));
		return messages;
	}

	// for debugging only - display Latest to Oldest 
	public void displayEmailMessagesNewestOnTop(Message[] messages) throws MessagingException, IOException {
		int nMsgs = messages.length;
		for (int index = nMsgs - 1; index >= 0; index--) {
			Message eMail = messages[index];
			this.dispalyEmailMessage(eMail);
		}
	}
	
	public void dispalyEmailMessage(Message message) throws MessagingException, IOException {
		m_logger.info("***************************************************");
		m_logger.info( leftpad( " Subject: ", message.getSubject() ));
		m_logger.info( leftpad( " From : ", Arrays.toString(message.getFrom() )));
		m_logger.info( leftpad( " To: ", Arrays.toString(message.getAllRecipients() )));
		m_logger.info( leftpad( " Date: " , message.getReceivedDate().toString() ));
		m_logger.info( leftpad( " Body: ", getTextFromMessage(message) ));
	}

	public void disconnectMailBox() throws MessagingException {
		if (this.m_mailFolderObj != null)
			this.m_mailFolderObj.close(true);
		if (this.m_storeObj != null)
			this.m_storeObj.close();
	}
	
	private String leftpad(String title,String value){
		String   m_strFormat= "%-35.35s%-100s";
		String strLeftPadded = String.format(m_strFormat,title, value);
		return strLeftPadded;
		
	}
	
	
	public String getTextFromMessage(Message message) throws MessagingException, IOException {
		String result = "";
		if (message.isMimeType("text/plain")) {
			result = message.getContent().toString();
		} else if (message.isMimeType("multipart/*")) {
			MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			result = getTextFromMimeMultipart(mimeMultipart);
		}
		return result;
	}

	private String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws MessagingException, IOException {
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; // without break same text appears twice in my tests
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}
	public String getOTPfromEmail(String subject,String from,String email,String regex  ) throws DDTFrameworkException, MessagingException, IOException
	{
		String regCode=null;
		// Start of Email Reading 
		// Prepare Filter Conditions
		General.sleep(30); // Wait for Email to be forwarded to AutoXpert
		SubjectTerm subjectTerm = new SubjectTerm(subject);//
		FromStringTerm fromStringTerm = new FromStringTerm(from);//
		RecipientStringTerm recipientStringTerm = new RecipientStringTerm(RecipientType.TO,email );//"NewHire1.234567890@gmail.com"
		FlagTerm unseenFlag = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
		ReceivedDateTerm dateTerm = new ReceivedDateTerm(ComparisonTerm.EQ, new Date());

		// Apply Filter
		SearchTerm[] searchTerms = new SearchTerm[] { subjectTerm, fromStringTerm, recipientStringTerm, dateTerm, unseenFlag };

		EmailSearcher emailSearch = new EmailSearcher();
		Message[] messages = emailSearch.searchMailBox(DDTController.getMailConfigAdp(), "Inbox/GMail", searchTerms);
		int nMsgs = messages.length;
		searchForText: if (messages.length != 0) {
		    for (int index = nMsgs - 1; index >= 0; index--) {
			Message eMail = messages[index];
			String mailBody = new EmailUtil().getTextFromMessage(eMail);
			// Subject in English
			regCode = mailBody.split(regex.split("@")[0])[1].split(regex.split("@")[1])[0].trim();
			if (!regCode.equals("null"))
				break searchForText;
		    }
		}
		
		emailSearch.disconectMailBox();
		
		if (regCode.equals("null")) {
		    throw new DDTFrameworkException(EmailUtil.class, "Unable to retrieve Registration code!");
		}
		// End of Email Reading 
		return regCode.trim();
	}
}
