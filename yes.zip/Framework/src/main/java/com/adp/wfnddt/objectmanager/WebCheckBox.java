package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;
import java.io.IOException;
import javax.xml.datatype.DatatypeConfigurationException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebCheckBox extends BaseObject {

	public WebCheckBox(String p_selector) {
		setSelector(p_selector);
	}

	public WebCheckBox(WebElement p_object) {
		setObject(p_object);
	}
	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void setValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		if (getObject().getAttribute("class").equalsIgnoreCase("revitCheckBoxIcon")) { // MDF5 checkbox
			boolean actualValue = getObject().findElement(By.xpath("./I")).getAttribute("clientHeight").equalsIgnoreCase("0") ? false : true;
			if ((!actualValue && p_value.equalsIgnoreCase("ON") || (actualValue && p_value.equalsIgnoreCase("OFF")))) {
				getObject().click();
			}
		} else if (getObject().findElements(By.cssSelector("span.reactCheckBoxIcon")).size() != 0) {
			if ((getObject().findElements(By.cssSelector("span.reactCheckBoxIcon.fa.fa-check")).size() == 0 && p_value.equalsIgnoreCase("ON")) || (getObject().findElements(By.cssSelector("span.reactCheckBoxIcon.fa.fa-check")).size() != 0 && p_value.equalsIgnoreCase("OFF"))) {
				getObject().findElement(By.cssSelector("span.reactCheckBoxIcon")).click();
			}
		} else if (getObject().getAttribute("class").contains("dijitCheckBoxInput")) {
			if ((getObject().getAttribute("aria-checked").toUpperCase().contentEquals("FALSE")) && p_value.equalsIgnoreCase("ON") || (getObject().getAttribute("aria-checked").toUpperCase().contentEquals("TRUE") && p_value.equalsIgnoreCase("OFF"))) {
				getObject().click();
			}
		} else if (getObject().getAttribute("class").contains("fa-square") || getObject().getAttribute("class").contains("fa-check-square")) {
			if ((getObject().getAttribute("class").contains("fa-check-square") && p_value.equalsIgnoreCase("OFF")) || (getObject().getAttribute("class").contains("fa-square") && p_value.equalsIgnoreCase("ON"))) {
				getObject().click();
			}
			//MDF 19		
		} else if ((getObject().getAttribute("class").contains("vdl-checkbox")) && (getObject().findElements(By.xpath(".//label[starts-with(@for,'checkbox_')]")).size() > 0)) {
			if ((getObject().findElement(By.cssSelector("input")).isSelected() && p_value.equalsIgnoreCase("OFF")) || (!getObject().findElement(By.cssSelector("input")).isSelected() && p_value.equalsIgnoreCase("ON"))) {
				WebElement checkbox = getObject().findElement(By.xpath(".//label"));
				new WebCheckBox(checkbox).jsClick();
				General.sleep(3);
				if ((getObject().findElement(By.cssSelector("input")).isSelected() && p_value.equalsIgnoreCase("OFF")) || (!getObject().findElement(By.cssSelector("input")).isSelected() && p_value.equalsIgnoreCase("ON"))) {
					WebElement oChkBx = getObject().findElement(By.xpath(".//label"));
					new WebCheckBox(oChkBx).jsClick();
				}
			}  
		} else if (getObject().getAttribute("class").contains("vdl-checkbox")) {
			if ((getObject().getAttribute("class").contains("checked") && p_value.equalsIgnoreCase("OFF")) || (!getObject().getAttribute("class").contains("checked") && p_value.equalsIgnoreCase("ON"))) {
				getObject().click();
			} 
		} else if ((!getObject().isSelected() && p_value.equalsIgnoreCase("ON") || (getObject().isSelected() && p_value.equalsIgnoreCase("OFF")))) {
			getObject().click();
		} else if (getObject().findElements(By.xpath(".//input")).size() != 0) { // New MDF checkbox 
			if ((getObject().findElement(By.xpath(".//input")).isSelected()) && p_value.equalsIgnoreCase("OFF") || !((getObject().findElement(By.xpath(".//input")).isSelected()) && p_value.equalsIgnoreCase("ON"))) {
				getObject().click();
			}
		}
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Exact });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		String expectedValue = p_value.toUpperCase();
		String actualValue =  getActualValue();

		// Compare
		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}

	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = "";

		if (getObject().getAttribute("class").equalsIgnoreCase("revitCheckBoxIcon")) { // MDF5 checkbox
			actualValue = getObject().findElement(By.xpath("./I")).getAttribute("clientHeight").equalsIgnoreCase("0") ? "OFF" : "ON";
		} else if (getObject().findElements(By.cssSelector("span.reactCheckBoxIcon")).size() != 0) {
			actualValue = getObject().findElement(By.cssSelector("span.reactCheckBoxIcon")).getAttribute("class").equalsIgnoreCase("fa fa-check reactCheckBoxIcon") ? "ON" : "OFF";
		} else if (getObject().getAttribute("class").contains("dijitCheckBoxInput")) {
			actualValue = getObject().getAttribute("aria-checked").toUpperCase().contentEquals("TRUE") ? "ON" : "OFF";
		} else if (getObject().findElements(By.xpath(".//input")).size() != 0) {
			actualValue = getObject().findElement(By.xpath(".//input")).isSelected() ? "ON" : "OFF";
		} else if (getObject().getAttribute("class").contains("vdl-checkbox")) {
			actualValue = getObject().getAttribute("class").contains("vdl-checkbox--checked") ? "ON" : "OFF";
		} else if (getObject().getAttribute("class").contains("fa fa-check-square") || getObject().getAttribute("class").contains("fa fa-square")) {
			actualValue = getObject().getAttribute("class").contains("check") ? "ON" : "OFF";
		} else if (!getObject().getCssValue(":before").isEmpty()) {
			if (getObject().getAttribute(getObject().getCssValue(":before")).equals("\"\"")) {

				if (getObject().getAttribute(getObject().getCssValue(":after")).equals("\"\""))
					actualValue = "ON";
				else
					actualValue = "OFF";
			}
		} else if (getObject().findElements(By.xpath("./ancestor::div[contains(@class,'vdl-row mdf-grid-row')]")).size() > 0) {
			actualValue = getObject().findElement(By.xpath("./ancestor::div[contains(@class,'vdl-row mdf-grid-row')]")).getAttribute("class").contains("selected") ? "ON" : "OFF";
		} else {
			if (getObject().getAttribute("checked") == null) {
				actualValue = "OFF";
			} else {
				actualValue = getObject().getAttribute("checked").equalsIgnoreCase("true") ? "ON" : "OFF";
			}
		}

		return actualValue;
	}
	
	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (exists()) {
			if (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]")) {
				if ((getObject().getAttribute("style")) != null && !(getObject().getAttribute("style").isEmpty())){
					verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_backGroundrgb187187187);
				}else if (getObject().findElements(By.cssSelector("span.reactCheckBoxIcon")).size() != 0) {
					verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject().findElement(By.cssSelector("span.reactCheckBoxIcon")));
				//MDF 19
				} else if ((getObject().getAttribute("class").contains("vdl-checkbox")) && (getObject().findElements(By.xpath(".//label[starts-with(@for,'checkbox_')]")).size() > 0)) {
					verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_ariaDisabled, getObject().findElement(By.cssSelector("input")));
				} else if (getObject().getAttribute("class").contains("dijitCheckBoxInput")) {
					verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject().findElement(By.xpath("./parent::DIV[contains(@class,'dijitCheckBox')]")));
				} else if (getObject().getAttribute("class").contains("vdl-checkbox")) {
					verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled);
				} else {
					super.verifyObjectProperties(p_property);
				}
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}
}
