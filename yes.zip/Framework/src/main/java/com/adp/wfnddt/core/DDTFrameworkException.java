/**
 * 
 */
package com.adp.wfnddt.core;

/**
 * @author autoxpert
 *
 */
public class DDTFrameworkException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4596218763672475508L;

	public DDTFrameworkException(Class<?> p_class, String p_message) {
        super(p_message);
        DDTLoggerManager.getLogger(p_class).error(p_message);
        return;
    }

	public DDTFrameworkException(Class<?> p_class, String p_message, Throwable p_cause) {
        super(p_message, p_cause);
        DDTLoggerManager.getLogger(p_class).error(p_message, p_cause);
        return;
    }

}
