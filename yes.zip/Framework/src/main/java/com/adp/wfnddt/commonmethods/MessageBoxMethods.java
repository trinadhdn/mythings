package com.adp.wfnddt.commonmethods;

import static com.adp.wfnddt.commonmethods.General.waitForGridSpinnerToComplete;
import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.objectmanager.BaseObject;
import com.adp.wfnddt.objectmanager.WebButton;
import com.adp.wfnddt.objectmanager.WebObject;
import com.adp.wfnddt.objectmanager.WebStatic;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class MessageBoxMethods extends BaseObject {

	protected WebDriver m_webDriver = DDTController.getWebDriver();
	protected WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
	DDTResultsReporter results = DDTController.getResultsReporter();
	private Logger m_Logger = DDTLoggerManager.getLogger(MessageBoxMethods.class);

	public static void verifyConfirmActionMessages(String p_value) throws DatatypeConfigurationException, DDTFrameworkException, IOException {
		   if (p_value.trim().contentEquals(""))
		      return;

		   DDTResultsReporter m_results = DDTController.getResultsReporter();
		   General.waitForGridSpinnerToComplete();
		   StatusType status = StatusType.FAILED;
		   String actualMessage = "";
		   if (new WebStatic("XPATH://div[@class='dijitDialogPaneContent' and not ( ancestor::div[contains(@style,'display: none')])]//p").exists()) {
		      actualMessage = new WebStatic("XPATH://div[@class='dijitDialogPaneContent' and not ( ancestor::div[contains(@style,'display: none')])]//p").getTextOnObject(new TextAttribute[]{TextAttribute.InnerText});
		   }

		   else if (new WebStatic("XPATH://div[@class='reactVDL' and parent::div[contains(@id,'Confirmation.Pane__Wrapper.pane')]]/div[2]/div[1]").exists()) { 
		       actualMessage = new WebStatic("XPATH://div[@class='reactVDL' and parent::div[contains(@id,'Confirmation.Pane__Wrapper.pane')]]/div[2]/div[1]").getTextOnObject(new TextAttribute[]{TextAttribute.TextContent});
		   }

		   else if (new WebStatic("XPATH://div[@class='reactVDL' and parent::div[contains(@id,'Alert.Pane__Wrapper.pane')]]/div[2]/div[1]").exists()) {
				actualMessage = new WebStatic("XPATH://div[@class='reactVDL' and parent::div[contains(@id,'Alert.Pane__Wrapper.pane')]]/div[2]/div[1]").getTextOnObject(new TextAttribute[] { TextAttribute.TextContent });
			}

		   
		   else if (new WebStatic("XPATH://div[@class='vdl-modal-content']//h4").exists()) {
		          actualMessage = new WebStatic("XPATH://div[@class='vdl-modal-content']//h4").getTextOnObject(new TextAttribute[]{TextAttribute.InnerText});
		      
		   }
		   
		   else if (new WebStatic("XPATH://div[@class='vdl-modal-content']").exists()) {
		          actualMessage = new WebStatic("XPATH://div[@class='vdl-modal-content']").getTextOnObject(new TextAttribute[]{TextAttribute.InnerText});
		      
		   }

		   else if (new WebStatic("XPATH://div[contains(@id,'divConfirmationMessage')]").exists()) {
		          actualMessage = new WebStatic("XPATH://div[contains(@id,'divConfirmationMessage')]").getTextOnObject(new TextAttribute[]{TextAttribute.InnerText});
		      
		   }

		   else if (new WebStatic("XPATH://div[@class='reactVDL' and contains(@id,'Confirmation_WRAPPER')]").exists()) {
		          actualMessage = new WebStatic("XPATH://div[@class='reactVDL' and contains(@id,'Confirmation_WRAPPER')]").getTextOnObject(new TextAttribute[]{TextAttribute.InnerText});
		   }
		   String expectedMessage = p_value;

		   m_results.startVerificationLogStep();

		   status = General.performTextComparison(expectedMessage, actualMessage, new ComparisonType[] { ComparisonType.RemoveWhiteSpaces, ComparisonType.RemoveNewLines });

		   m_results.addEntryToVerificationLog("Verify Message On Confirm Action Popup", status, expectedMessage, actualMessage);

		   m_results.endVerificationLogStep();

		}


	public void clickOnMessageBoxButton(String ParameterValue) throws DDTFrameworkException, IOException, DatatypeConfigurationException {

		if (ParameterValue.contentEquals(""))
			return;

		else {
			// mdf-6 MessageBox buttons
			List<WebElement> mb_Buttons = m_webDriver.findElements(By.cssSelector(".vdl-modal-content * button,button.reactVDL.reactButton,button.reactVDL.reactButton.secondaryButton,button.vdl-button,#RecCandInterviewsSuccessDialog.successDialogOKButton,#NAPDB_ConfirmMsg.yesButton,#NAPDB_ConfirmMsg.noButton,#okButton1"));

			// mdf-5 MessageBox buttons
			List<WebElement> mb_5_Buttons = m_webDriver.findElements(By.xpath(".//span[contains(@class,'dijitButtonText') or contains(@class,'revitButton')]"));
			mb_Buttons.addAll(mb_5_Buttons);
			boolean bFound = false;
			if (!mb_Buttons.isEmpty()) {
				for (WebElement eachButton : mb_Buttons) {
					if (eachButton.getText().equalsIgnoreCase(ParameterValue) || eachButton.getAttribute("innerText").equalsIgnoreCase(ParameterValue) ) {
						bFound = true;
						new WebObject(eachButton).click();
						break;
					}
				}
				if (!bFound && ParameterValue.toUpperCase().contentEquals("CLOSE") && m_webDriver.findElement(By.xpath("//BUTTON[contains(@class,'vdl-modal-close')]")).getAttribute("aria-label").toUpperCase().contentEquals(ParameterValue.toUpperCase())) {
					WebElement element = m_webDriver.findElement(By.xpath("//BUTTON[contains(@class,'vdl-modal-close')]"));
					new WebObject(element).click();
					bFound = true;
				}
				if (!bFound && ParameterValue.toUpperCase().contentEquals("OK") && m_webDriver.findElement(By.xpath("//button[@id='RecCandInterviewsSuccessDialog.successDialogOKButton']")).isDisplayed()) {
					WebElement element = m_webDriver.findElement(By.xpath("//button[@id='RecCandInterviewsSuccessDialog.successDialogOKButton']"));
					new WebObject(element).click();
					bFound = true;
				}
			} else {

				if (ParameterValue.toUpperCase().contentEquals("CANCEL") && m_webDriver.findElement(By.id("acaAffordabilityCancel")).getText().contentEquals(ParameterValue.toUpperCase())) {
					WebElement element = m_webDriver.findElement(By.id("acaAffordabilityCancel"));
					new WebObject(element).click();
					bFound = true;
				} else if (ParameterValue.toUpperCase().contentEquals("CANCEL") && m_webDriver.findElement(By.xpath("//SPAN[contains(@id,'button.label')")).getText().contentEquals(ParameterValue.toUpperCase())) {
					WebElement element = m_webDriver.findElement(By.xpath(".//SPAN[contains(@id,'button.label')"));
					new WebObject(element).click();
					bFound = true;
				}

				if (bFound == false) {
					fail("Button '" + ParameterValue + "' not found on Message Box");
				}

			}
		}
	}

	public void clickOnMessageBoxButtonIfExists(String ParameterValue) throws DDTFrameworkException, DatatypeConfigurationException, IOException {

		if (ParameterValue.contentEquals(""))
			return;

		else {
			waitForGridSpinnerToComplete();
			// mdf-6 MessageBox buttons
			List<WebElement> mb_Buttons = m_webDriver.findElements(By.cssSelector(".vdl-modal-content * button,button.reactVDL.reactButton,button.vdl-button,#RecCandInterviewsSuccessDialog.successDialogOKButton,#NAPDB_ConfirmMsg.yesButton,#NAPDB_ConfirmMsg.noButton,#okButton1"));

			// mdf-5 Span MessageBox buttons
			List<WebElement> mb_5_Buttons = m_webDriver.findElements(By.xpath(".//span[contains(@class,'dijitButtonText') or contains(@class,'revitButton')]"));
			mb_Buttons.addAll(mb_5_Buttons);
			// mdf-5 button tag MessageBox buttons
			List<WebElement> mb_5_ButtonTag_Buttons = m_webDriver.findElements(By.xpath(".//button[contains(@class,'reactVDL reactButton')]"));
			mb_Buttons.addAll(mb_5_ButtonTag_Buttons);
			
			boolean bFound = false;
			if (!mb_Buttons.isEmpty()) {
				for (WebElement eachButton : mb_Buttons) {
					if (eachButton.getText().equalsIgnoreCase(ParameterValue) || eachButton.getAttribute("innerText").equalsIgnoreCase(ParameterValue) ) {
						if (eachButton.isDisplayed()){
							bFound = true;
							//JE - Edge had obscure issue with objects. So we will try the click then use jsClick instead
							try {
								new WebObject(eachButton).click();
							} catch (Exception e) {
								m_Logger.debug("ERROR: Had to override the messagebox click for Edge");
								new WebButton(eachButton).jsClick();
							}
							break;
						}
					}
				}
				if (!bFound && ParameterValue.toUpperCase().contentEquals("CLOSE") && m_webDriver.findElements(By.xpath("//BUTTON[contains(@class,'vdl-modal-close')]")).size() > 0 && m_webDriver.findElement(By.xpath("//BUTTON[contains(@class,'vdl-modal-close')]")).getAttribute("aria-label").toUpperCase().contentEquals(ParameterValue.toUpperCase())) {
					WebElement element = m_webDriver.findElement(By.xpath("//BUTTON[contains(@class,'vdl-modal-close')]"));
					new WebObject(element).click();
					bFound = true;
				}
				if (!bFound && ParameterValue.toUpperCase().contentEquals("OK") && m_webDriver.findElements(By.xpath("//button[@id='RecCandInterviewsSuccessDialog.successDialogOKButton']")).size() > 0) {
					WebElement element = m_webDriver.findElement(By.xpath("//button[@id='RecCandInterviewsSuccessDialog.successDialogOKButton']"));
					new WebObject(element).click();
				}
			} else {

				if (ParameterValue.toUpperCase().contentEquals("CANCEL") && m_webDriver.findElement(By.id("acaAffordabilityCancel")).getText().contentEquals(ParameterValue.toUpperCase())) {
					WebElement element = m_webDriver.findElement(By.id("acaAffordabilityCancel"));
					new WebObject(element).click();
					bFound = true;
				} else if (ParameterValue.toUpperCase().contentEquals("CANCEL") && m_webDriver.findElement(By.xpath("//SPAN[contains(@id,'button.label')")).getText().contentEquals(ParameterValue.toUpperCase())) {
					WebElement element = m_webDriver.findElement(By.xpath(".//SPAN[contains(@id,'button.label')"));
					new WebObject(element).click();
					bFound = true;
				}

			}

			if (bFound == false) {
				m_results.startVerificationLogStep();
				m_results.addEntryToVerificationLog("Button '" + ParameterValue + "' not found on Message Box", StatusType.DONE, "Button Not Found", "Button Not Found");
				m_results.endVerificationLogStep();
			}
		}
	}

	/*
	 * public void VerifyPopupMessage(String ParameterValue) throws IOException,
	 * DatatypeConfigurationException, DDTFrameworkException {
	 * reactVDL reactButton secondaryButton
	 * DDTResultsReporter results = DDTController.getResultsReporter();
	 * List<String> aActual=new ArrayList<String>();
	 * 
	 * String
	 * msgSelector=".vdl-modal-content * h4,.vdl-modal-content * text,.vdl-modal-content * p,.vdl-modal-content * Div,.revitTid3Message.dijitInline"
	 * ; results.startVerificationLogStep();
	 * 
	 * if (ParameterValue.contentEquals("")) return;
	 * 
	 * else { //collect all message nodes List<WebElement> oPopupObj =
	 * m_webDriver.findElements(By.cssSelector(".vdl-modal-content div")); for
	 * (WebElement eachObj : oPopupObj) { if (eachObj.isDisplayed()) {
	 * aActual.add(eachObj.getText().trim()); } String
	 * aActualMessage=String.join("",aActual); String
	 * ExpectedMessage=ParameterValue.replace(" ", ""); if
	 * (aActualMessage.contains(ExpectedMessage)) {
	 * 
	 * } } } //collect all message text /* for (WebElement eachObj : oPopupObj)
	 * { if (eachObj.isDisplayed()) { switch (eachObj.getAttribute("id")) { case
	 * "inlineTextID0" : aActual.add(eachObj.getText()); if
	 * (m_webDriver.findElement(By.cssSelector("#inlineTextID1")).isDisplayed())
	 * {
	 * aActual.add(aActual.get(aActual.size()-1)+"|"+m_webDriver.findElement(By.
	 * cssSelector("#inlineTextID1")).getText()); } break; case
	 * "You have selected to Clear" : aActual.
	 * add("You have selected to Clear All Balances. At least one Arrears code is already set to Clear Balances. Do you still want to Clear All?"
	 * ); break; default : aActual.add(eachObj.getText()); } } else {
	 * aActual.add("<NOT_FOUND>"); } }
	 */

	/*
	 * Capabilities caps = ((RemoteWebDriver) m_webDriver).getCapabilities();
	 * String browserName = caps.getBrowserName(); if
	 * (ParameterValue.contains("<SPACES>")) { if
	 * (browserName=="internet explorer") { ParameterValue =
	 * ParameterValue.replace("<SPACES>", " "); } else { ParameterValue =
	 * ParameterValue.replace("<SPACES>", ""); } }
	 * 
	 * 
	 * 
	 * 
	 * results.endVerificationLogStep(); }
	 */
	/*
	 * public void verifyMessageBox(String ParameterValue) throws IOException,
	 * DatatypeConfigurationException, DDTFrameworkException {} /* public void
	 * clickButton(String p_nodeSelector) {
	 * 
	 * if (p_nodeSelector.toUpperCase().startsWith("CSS:")) { m_by =
	 * By.cssSelector(p_nodeSelector.substring(4)); } else if
	 * (p_nodeSelector.toUpperCase().startsWith("XPATH:")) { m_by =
	 * By.xpath(p_nodeSelector.substring(6)); } else { m_by =
	 * By.cssSelector(p_nodeSelector); } WebElement button =
	 * m_webDriver.findElement(m_by);
	 * m_webDriverWait.until(ExpectedConditions.elementToBeClickable(button));
	 * if (button == null) fail("Button with the given criteria -[" +
	 * p_nodeSelector + "] not found in the Message Box"); else {
	 * button.click(); }
	 * 
	 * }
	 * 
	 * public void clickButton(WebElement p_Button) {
	 * 
	 * WebElement button = p_Button;
	 * m_webDriverWait.until(ExpectedConditions.elementToBeClickable(button));
	 * if (button == null) fail("Button -[" + p_Button.getText() +
	 * "] not found in the Message Box"); else { button.click(); }
	 * 
	 * }
	 * 
	 * public void VerifyValue(String p_nodeSelector, String ActualMessage) {
	 * 
	 * if (p_nodeSelector.toUpperCase().startsWith("CSS:")) { m_by =
	 * By.cssSelector(p_nodeSelector.substring(4)); } else if
	 * (p_nodeSelector.toUpperCase().startsWith("XPATH:")) { m_by =
	 * By.xpath(p_nodeSelector.substring(6)); } else { m_by =
	 * By.cssSelector(p_nodeSelector); } WebElement txtMessage =
	 * m_webDriver.findElement(m_by);
	 * m_webDriverWait.until(ExpectedConditions.visibilityOf(txtMessage)); if
	 * (txtMessage != null) if
	 * (txtMessage.getText().contentEquals(ActualMessage)) {
	 * 
	 * } else { fail("WebElement with the given criteria -[" + p_nodeSelector +
	 * "] not found in the Message Box"); }
	 * 
	 * else {
	 * 
	 * fail("WebElement with the given criteria -[" + p_nodeSelector +
	 * "] not found in the Message Box"); } }
	 */
}