package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebButton extends BaseObject {

	public WebButton(String p_selector) {
		setSelector(p_selector);
	}

	public WebButton(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Button To Click" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void click(String p_buttonToClick) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_buttonToClick.trim().equalsIgnoreCase(m_objectName.trim()))
			return;
		m_results.addScreenshotCaptureStep(General.captureScreenshot("ScreenShot Before Clicking Button"));
		clickOnObject(ClickType.Simple);
		return;
	}

	@Step(Params = { "Button To Click", "Type of Click" })
	public void click(String p_buttonToClick, ClickType p_typeOfClick) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_buttonToClick.trim().equalsIgnoreCase(m_objectName.trim()))
			return;
		m_results.addScreenshotCaptureStep(General.captureScreenshot("ScreenShot Before Clicking Button"));
		clickOnObject(p_typeOfClick);
		return;
	}

	@Step(Params = { "Button To Click", "Mapped Value", "Type of Click" })
	public void click(String p_buttonToClick, String p_mappedValue, ClickType p_typeOfClick) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (!p_buttonToClick.trim().equalsIgnoreCase(p_mappedValue.trim()))
			return;
		m_results.addScreenshotCaptureStep(General.captureScreenshot("ScreenShot Before Clicking Button"));
		clickOnObject(p_typeOfClick);
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Exact });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		String expectedValue = p_value.trim();

		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = getActualValue();
		
		// Compare
		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}
	
	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = getObject().getText().trim();

		if (actualValue.contentEquals("")) {
			actualValue = getObject().getAttribute("textContent").trim();
		}
		
		return actualValue;
	}

	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (exists()) {
			if (getObject().getAttribute("class").contains("reactButton") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject());
			}
			// Added vdl-button
			else if (getObject().getAttribute("class").contains("vdl-button") && getObject().getAttribute("aria-disabled")!=null && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_ariaDisabled, getObject());
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}
}
