package com.adp.wfnddt.objectmanager;

import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.CardMethods;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTAssertionError;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.core.GlobalVariables.ScrollType;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebCard extends BaseObject {

	private CardMethods m_CardMethods = new CardMethods();

	public WebCard(String p_selector) {
		setSelector(p_selector);
		return;
	}

	public WebCard(WebElement p_object) {
		setObject(p_object);
		return;
	}

	public void DragAndDrop(String p_cardSelector, ObjectMap p_objectMap, String p_Source, String p_Target, String p_ItemsToMove) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_Source.contentEquals("") || p_Target.contentEquals("") || p_ItemsToMove.contentEquals(""))
			return;
		HashMap<String, String> cardToFind = new LinkedHashMap<>();

		cardToFind.put("SOURCE", p_Source);
		WebElement cardSource = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, 1, p_objectMap, -1);
		cardToFind.put("SOURCE", "");
		cardToFind.put("TARGET", p_Target);
		WebElement cardTarget = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, 1, p_objectMap, -1);

		if (cardSource == null) {
			fail("Source Object not found check your card name/title");
			return;
		}

		if (cardTarget == null) {
			fail("Target Object not found check your card name/title");
			return;
		}

		if (p_ItemsToMove.equalsIgnoreCase("[MOVEALL]")) {
			WebElement moveAllObject = m_CardMethods.getObjectInCard(cardTarget, new WebObject("XPATH:.//span[text()='Move All']"), 1);
			if (new WebObject(moveAllObject).exists()) {
				new WebObject(moveAllObject).click();
				General.sleep(1);
			} else
				fail("Object [Move All] is not found in the Target Card");

			return;
		}

		WebElement cardTargetDropContent = m_CardMethods.getObjectInCard(cardTarget, new WebObject("XPATH:.//div[contains(@class,'card-content')]"), 1);

		for (String item : p_ItemsToMove.split(";")) {
			WebElement ItemObject = m_CardMethods.getObjectInCard(cardSource, new WebObject("XPATH:.//div[text()='" + item + "']"), 1);

			if (new WebObject(ItemObject).exists())
				new WebObject(ItemObject).jsDragAndDrop(cardTargetDropContent);
			else
				fail("The value [" + item + "] is not found in the Source Card");
		}

		return;
	}

	@Step
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void enterDataInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		enterDataInCard(p_pm, p_cardSelector, p_objectMap, ClickType.Simple);
		return;
	}

	public void enterDataInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap, ClickType p_clickType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		enterDataInCard(p_pm, p_cardSelector, p_objectMap, 1, p_clickType);
		return;
	}

	@Step
	public void enterDataInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap, int p_objInstance, ClickType p_clickType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		WebElement cardObj = null;
		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);
		HashMap<String, String> cardData = m_CardMethods.retrieveCardData(p_pm);

		if (cardToFind.size() == 0 && cardNumber == -1)
			return;

		// Find the card
		WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
		if (card == null) {
			fail("The card with the the given find criteria is not found!!");
			return;
		}

		if (DDTController.getBrowserType().equals(BrowserType.Edge))
			GlobalVariables.setScrollType(ScrollType.ScrollIntoView);

		new WebCard(card).scrollIntoView();

		// Enter the data
		for (String fieldName : cardData.keySet()) {
			String fieldValue = cardData.get(fieldName);
			if (!fieldValue.trim().contentEquals("")) {
				if (!p_objectMap.getMap().containsKey(fieldName)) {
					fail("The field - [" + fieldName + "] doesn't have an object mapped to it!!");
					return;
				}

				BaseObject actionObject = p_objectMap.getMap().get(fieldName);
				cardObj = m_CardMethods.getObjectInCard(card, actionObject, p_objInstance);

				// Added to unhide the hidden Objects
				new WebObject(cardObj).mouseOver();

				switch (actionObject.getClass().getSimpleName()) {
				case "WebCheckBox":
					new WebCheckBox(cardObj).setValue(fieldValue);
					break;

				case "WebComboBox":
					new WebComboBox(cardObj).select(fieldValue);
					break;

				case "WebComboMultiSelect": // Satya - EnterDataInCard modified
											// to handle WebComboMultiSelect
					new WebComboMultiSelect(cardObj).select(fieldValue, "ADD");
					break;

				case "WebDateField":
					new WebDateField(cardObj).setValue(fieldValue);
					break;

				case "WebTextBox":
					new WebTextBox(cardObj).set(fieldValue);
					break;

				case "WebToggleButton":
					new WebToggleButton(cardObj).set(fieldValue);
					break;

				case "WebRadioButton":
					new WebRadioButton(cardObj).click();
					break;

				case "WebLink":
					new WebLink(cardObj).click();
					break;
				case "WebObject":
				case "WebButton":
					new WebButton(cardObj).click();
					break;

				default:

					DDTAssertionError.fail("Enter data on the object type -[" + actionObject.getClass().getSimpleName() + "] cannot be performed");
					break;
				}
			}
		}

		// Click the button
		String btnToClick = m_CardMethods.retrieveButtonToClick(p_pm);
		if (!btnToClick.trim().contentEquals("")) {
			if (!p_objectMap.getMap().containsKey(btnToClick)) {
				fail("The field - [" + btnToClick + "] doesn't have an object mapped to it!!");
				return;
			}

			BaseObject actionObject = p_objectMap.getMap().get(btnToClick);
			cardObj = m_CardMethods.getObjectInCard(card, actionObject);

			actionObject.setObject(cardObj);
			actionObject.clickOnObject(p_clickType);
		}

		return;
	}

	public void verifyCardInstances(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		StatusType status = StatusType.PASSED;

		int noOfInstances = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);
		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		// Find the cards matching the criteria

		if (cardToFind.size() > 0 || cardNumber > 0) {
			// added support for row with no entries message like "There are currently no entries."
			if (cardToFind.get("[NOENTRIES]") != null) {
				if (cardToFind.get("[NOENTRIES]").equalsIgnoreCase("[NOCARDS]")) { // If there is no card at all to find
					List<WebElement> totalCards = m_CardMethods.getAllCards(getObject(), p_cardSelector);
					if (!totalCards.isEmpty()) {
						status = StatusType.FAILED;
					}
					m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, "[NOCARDS]", status.value());
					return;
				}
				int noEntriesIntance = getObject().findElements(By.xpath(".//*[text()='" + cardToFind.get("[NOENTRIES]") + "']")).size();
				if (noEntriesIntance != noOfInstances) {
					status = StatusType.FAILED;
				}
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, String.valueOf(noOfInstances), String.valueOf(noEntriesIntance));
			} else {

				List<WebElement> cardColl = m_CardMethods.findAllCardsMatchCriteria(getObject(), p_cardSelector, cardToFind, -1, p_objectMap, cardNumber);

				if (cardColl.size() != noOfInstances) {
					status = StatusType.FAILED;
				}
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, String.valueOf(noOfInstances), String.valueOf(cardColl.size()));
			}

		}
		return;
	}

	public void verifyObjectDataInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);
		HashMap<String, String> cardData = m_CardMethods.retrieveCardData(p_pm);
		StatusType status = StatusType.PASSED;

		if (cardToFind.size() > 0 || cardNumber > 0) {
			if (cardToFind.get("[NOENTRIES]") != null) { // Added to check for no rows on a card set
				if (cardToFind.get("[NOENTRIES]").equalsIgnoreCase("[NOCARDS]")) { // If there is no card at all to find
					List<WebElement> totalCards = m_CardMethods.getAllCards(getObject(), p_cardSelector);
					if (!totalCards.isEmpty()) {
						status = StatusType.FAILED;
					}
					m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, "[NOCARDS]", status.value());
					return;
				}
				int noEntriesIntance = getObject().findElements(By.xpath(".//*[text()='" + cardToFind.get("[NOENTRIES]") + "']")).size();
				if (noEntriesIntance != cardInstance) {
					status = StatusType.FAILED;
				}
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, String.valueOf(cardInstance), String.valueOf(noEntriesIntance));
				return;
			}
			// Find the card
			WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
			if (card == null && cardInstance > 0) {
				// fail("The card with the the given find criteria is not found!!");
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, String.valueOf(cardInstance), "The card with the the given find criteria is not found!!");
				return;
			} else if (card == null && cardInstance <= 0) {
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.PASSED, String.valueOf(cardInstance), "0");
				return;
			}

			if (DDTController.getBrowserType().equals(BrowserType.Edge))
				GlobalVariables.setScrollType(ScrollType.ScrollIntoView);

			new WebCard(card).scrollIntoView();

			// Verify the data
			for (String fieldName : cardData.keySet()) {
				String fieldValue = cardData.get(fieldName);

				if (!fieldValue.trim().contentEquals("")) {
					if (!p_objectMap.getMap().containsKey(fieldName)) {
						fail("The field - [" + fieldName + "] doesn't have an object mapped to it!!");
						return;
					}

					BaseObject actionObject = p_objectMap.getMap().get(fieldName);
					WebElement cardObj = m_CardMethods.getObjectInCard(card, actionObject);

					switch (actionObject.getClass().getSimpleName()) {
					case "WebCheckBox":
						new WebCheckBox(cardObj).verifyValue(fieldValue);
						break;

					case "WebComboBox":
						new WebComboBox(cardObj).verifyValue(fieldValue);
						break;

					case "WebComboMultiSelect": // Satya -
												// verifyObjectDataInCard
												// modified to handle
												// WebComboMultiSelect
						new WebComboMultiSelect(cardObj).verifyValue(fieldValue);
						break;

					case "WebDateField":
						new WebDateField(cardObj).verifyValue(fieldValue);
						break;

					case "WebTextBox":
						new WebTextBox(cardObj).verifyValue(fieldValue);
						break;

					case "WebToggleButton":
						new WebToggleButton(cardObj).verifyValue(fieldValue);
						break;

					case "WebButton":
						new WebButton(cardObj).verifyValue(fieldValue);
						break;

					case "WebImage":
						new WebImage(cardObj).verifyValue(fieldValue);
						break;

					case "WebLink":
						new WebLink(cardObj).verifyValue(fieldValue);
						break;

					case "WebObject":
						new WebObject(cardObj).verifyValue(fieldValue);
						break;

					case "WebRadioButton":
						new WebRadioButton(cardObj).verifyValue(fieldValue);
						break;

					case "WebStatic":
						new WebStatic(cardObj).verifyValue(fieldValue, new ComparisonType[] { ComparisonType.RemoveNewLines });
						break;

					default:
						DDTAssertionError.fail("Verify data on the object type -[" + actionObject.getClass().getSimpleName() + "] cannot be performed on the card");
						break;
					}
				}
			}
		}
		return;
	}

	public void verifyObjectPropertiesInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		WebElement cardObj = null;
		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);
		HashMap<String, String> cardObjects = m_CardMethods.retrieveCardObjects(p_pm);

		if (cardToFind.size() > 0 || cardNumber > 0) {
			// Find the card
			WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
			if (card == null) {
				// fail("The card with the the given find criteria is not found!!");
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, String.valueOf(cardInstance), "The card with the the given find criteria is not found!!");
				return;
			}

			if (DDTController.getBrowserType().equals(BrowserType.Edge))
				GlobalVariables.setScrollType(ScrollType.ScrollIntoView);

			new WebCard(card).scrollIntoView();

			// Verify object properties
			for (String fieldName : cardObjects.keySet()) {
				String verifyProperty = cardObjects.get(fieldName);

				if (!verifyProperty.trim().contentEquals("")) {
					if (!p_objectMap.getMap().containsKey(fieldName)) {
						fail("The field - [" + fieldName + "] doesn't have an object mapped to it!!");
						return;
					}

					BaseObject actionObject = p_objectMap.getMap().get(fieldName);
					cardObj = m_CardMethods.getObjectInCard(card, actionObject);

					switch (actionObject.getClass().getSimpleName()) {
					case "WebButton":
						new WebButton(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebImage":
						new WebImage(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebLink":
						new WebLink(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebObject":
						new WebObject(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebCheckBox":
						new WebCheckBox(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebComboBox":
						new WebComboBox(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebDateField":
						new WebDateField(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebTextBox":
						new WebTextBox(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebToggleButton":
						new WebToggleButton(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebRadioButton":
						new WebRadioButton(cardObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebStatic":
						new WebStatic(cardObj).verifyObjectProperties(verifyProperty);
						break;

					default:
						DDTAssertionError.fail("Verify object properties on the object type -[" + actionObject.getClass().getSimpleName() + "] cannot be performed");
						break;
					}
				}
			}
		}
		return;
	}

	public void verifyListBoxContentsInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		WebElement cardObj = null;
		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);
		HashMap<String, String> cardObjects = m_CardMethods.retrieveCardObjects(p_pm);
		String typeOfTest = m_CardMethods.retrieveTestType(p_pm);
		String p_expectedContents = m_CardMethods.retrieveListBoxContents(p_pm);

		if (cardToFind.size() > 0 || cardNumber > 0) {
			// Find the card
			WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
			if (card == null) {
				// fail("The card with the the given find criteria is not found!!");
				m_results.addEntryToVerificationLog("Verify card instances for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, String.valueOf(cardInstance), "The card with the the given find criteria is not found!!");
				return;
			}

			if (DDTController.getBrowserType().equals(BrowserType.Edge))
				GlobalVariables.setScrollType(ScrollType.ScrollIntoView);

			new WebCard(card).scrollIntoView();

			for (String fieldName : cardObjects.keySet()) {
				BaseObject actionObject = p_objectMap.getMap().get(fieldName);
				cardObj = m_CardMethods.getObjectInCard(card, actionObject);

				if (cardObj != null && actionObject.getClass().getSimpleName().contentEquals("WebComboBox")) {
					new WebComboBox(cardObj).verifyContents(p_expectedContents, typeOfTest);
				}

				if (cardObj != null && actionObject.getClass().getSimpleName().contentEquals("WebComboMultiSelect")) {
					new WebComboMultiSelect(cardObj).verifyContents(p_expectedContents, typeOfTest);
				}

			}
		}
	}

	@Step
	public WebElement getObjectInCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap, String fieldName) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		WebElement cardObj = null;
		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);

		// Find the card
		WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
		if (card == null) {
			fail("The card with the the given find criteria is not found!!");
			return cardObj;
		}

		// Get the card object
		if (!p_objectMap.getMap().containsKey(fieldName.toUpperCase())) {
			fail("The field - [" + fieldName + "] doesn't have an object mapped to it!!");
			return cardObj;
		}

		BaseObject actionObject = p_objectMap.getMap().get(fieldName.toUpperCase());
		cardObj = m_CardMethods.getObjectInCard(card, actionObject);

		return cardObj;
	}

	@Step
	public WebElement getCard(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);
		int cardNumber = m_CardMethods.retrieveCardNumber(p_pm);

		// Find the card
		WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
		return card;
	}

	@Step
	public int getCardNumber(ParamManager p_pm, String p_cardSelector, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		int cardNumber = -1;
		HashMap<String, String> cardToFind = m_CardMethods.retrieveCardToFind(p_pm);
		int cardInstance = m_CardMethods.retrieveCardInstance(p_pm);

		WebElement card = m_CardMethods.findCardMatchCriteria(getObject(), p_cardSelector, cardToFind, cardInstance, p_objectMap, cardNumber);
		if (card != null) {
			List<WebElement> arrAllCards = m_CardMethods.getAllCards(getObject(), p_cardSelector);
			cardNumber = arrAllCards.indexOf(card) + 1;
		}
		return cardNumber;
	}

}
