package com.adp.wfnddt.objectmanager;

import java.util.HashMap;

public class ObjectMap {

	private HashMap<String, BaseObject> objectMap = new HashMap<>();
	private HashMap<String, String> objectLabelMap = new HashMap<>();

	public void addObject(String p_objectName, BaseObject p_object) {
		objectMap.put(p_objectName.toUpperCase(), p_object);
		objectLabelMap.put(p_objectName.toUpperCase(), p_objectName);
	}

	public void addObject(String p_objectName, String p_labelName, BaseObject p_object) {
		objectMap.put(p_objectName.toUpperCase(), p_object);
		objectLabelMap.put(p_objectName.toUpperCase(), p_labelName);
	}

	public void addObjects(String[] p_objectNames, BaseObject p_object) {
		for (String p_objectName : p_objectNames) {
			objectMap.put(p_objectName.toUpperCase(), p_object);
		}
	}

	public HashMap<String, BaseObject> getMap() {
		return objectMap;
	}

	public HashMap<String, String> getLabelMap() {
		return objectLabelMap;
	}

	public void clearMap() {
		objectMap.clear();
	}

	public void clearLabelMap() {
		objectLabelMap.clear();
	}
}
