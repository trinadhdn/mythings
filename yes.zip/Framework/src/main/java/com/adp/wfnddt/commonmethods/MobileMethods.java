package com.adp.wfnddt.commonmethods;

import java.io.IOException;
import java.time.Duration;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.BaseObject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class MobileMethods {

	protected static AppiumDriver<WebElement> m_AppDriver = DDTController.getMobileDriver();

	public enum MobileScrollType {
		ScrollDown, ScrollUp, ScrollLeft, ScrollRight
	}

	public static void scrollIntoView(BaseObject p_object, MobileScrollType p_scrollType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		scrollIntoView(p_object.getObject(), p_scrollType);
	}
	
	public static void scrollIntoView(WebElement p_object, MobileScrollType p_scrollType) {
		int maxSwipes = 10;
		Dimension size = m_AppDriver.manage().window().getSize();
		int startX, startY, endX, endY, currentLoc;

		TouchAction touchAction = new TouchAction<>(m_AppDriver);
		switch (p_scrollType) {
		case ScrollDown:
			startY = (int) (size.height * 0.8);
			endY = (int) (size.height * 0.2);
			startX = size.width / 2;
			endX = startX;
			
			//initLoc = p_object.getLocation().getY();
			for (int i = 1; i <= maxSwipes; i++) {
				touchAction.press(new PointOption<>().withCoordinates(startX, startY)).waitAction(new WaitOptions().withDuration(Duration.ofSeconds(2))).moveTo(new PointOption<>().withCoordinates(endX, endY)).release().perform();

				currentLoc = p_object.getLocation().getY();
				if (currentLoc < startY)
					break;
			}
			break;
		case ScrollUp:
			endY = (int) (size.height * 0.8);
			startY = (int) (size.height * 0.2);
			startX = size.width / 2;
			endX = startX;
			
			//initLoc = p_object.getLocation().getY();
			for (int i = 1; i <= maxSwipes; i++) {
				touchAction.press(new PointOption<>().withCoordinates(startX, startY)).waitAction(new WaitOptions().withDuration(Duration.ofSeconds(2))).moveTo(new PointOption<>().withCoordinates(endX, endY)).release().perform();

				currentLoc = p_object.getLocation().getY();
				if (currentLoc > startY)
					break;
			}
			break;

		case ScrollLeft:
			startX = (int) (size.width * 0.8);
			endX = (int) (size.width * 0.2);
			startY = size.height / 2;
			endY = startY;
			
			//initLoc = p_object.getLocation().getX();
			for (int i = 1; i <= maxSwipes; i++) {
				touchAction.press(new PointOption<>().withCoordinates(startX, startY)).waitAction(new WaitOptions().withDuration(Duration.ofSeconds(2))).moveTo(new PointOption<>().withCoordinates(endX, endY)).release().perform();

				currentLoc = p_object.getLocation().getX();
				if (currentLoc < startX)
					break;
			}
			break;

		case ScrollRight:
			endX = (int) (size.width * 0.8);
			startX = (int) (size.width * 0.2);
			startY = size.height / 2;
			endY = startY;

			//initLoc = p_object.getLocation().getX();
			for (int i = 1; i <= maxSwipes; i++) {
				touchAction.press(new PointOption<>().withCoordinates(startX, startY)).waitAction(new WaitOptions().withDuration(Duration.ofSeconds(2))).moveTo(new PointOption<>().withCoordinates(endX, endY)).release().perform();

				currentLoc = p_object.getLocation().getX();
				if (currentLoc < endX)
					break;
			}
			break;

		}
	}
}
