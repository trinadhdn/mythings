package com.adp.wfnddt.objectmanager.extendedobjects;

import com.adp.wfnddt.objectmanager.WebLink;

public class PasteIcon extends WebLink {
	public PasteIcon() {
		super("CSS:span.fa.fa-paste");
	}
}
