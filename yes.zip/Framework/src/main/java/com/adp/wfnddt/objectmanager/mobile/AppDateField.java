package com.adp.wfnddt.objectmanager.mobile;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.objectmanager.WebDateField;

import io.appium.java_client.AppiumDriver;

public class AppDateField extends WebDateField {

	private AppiumDriver<WebElement> m_AppDriver = DDTController.getMobileDriver();
	private WebDriverWait m_AppDriverWait = DDTController.getMobileDriverWait();

	public AppDateField(String p_selector) {
		super(p_selector);
	}

	public AppDateField(WebElement p_object) {
		super(p_object);
	}

	@Step(Params = { "Date" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void setValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForVisibility();

		// Click on the calender icon
		getObject().click();

		// Wait for the date picker
		m_AppDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("android:id/day_picker_view_pager")));
		m_AppDriver.findElement(By.xpath("//android.view.ViewGroup[@resource-id='android:id/date_picker_day_picker']//android.view.View[@content-desc='" + p_value + "']")).click();
		m_AppDriver.findElement(By.xpath("//android.widget.ScrollView[@resource-id='android:id/buttonPanel']//android.widget.Button[@text='SET']")).click();

	}

}
