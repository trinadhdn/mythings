package com.adp.wfnddt.objectmanager;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.google.gson.JsonArray;

import com.adp.wfnddt.objectmanager.mobile.AppButton;
import com.adp.wfnddt.objectmanager.mobile.AppDateField;
import com.adp.wfnddt.objectmanager.mobile.AppImage;
import com.adp.wfnddt.objectmanager.mobile.AppListBox;
import com.adp.wfnddt.objectmanager.mobile.AppTextBox;
import com.adp.wfnddt.objectmanager.mobile.AppComboBox;

public class ObjectTypes {
	private JsonArray pageObjects;
	public void setPage(JsonArray pageObjJSON) {
		pageObjects = pageObjJSON;
	}
	
	public Frame Frame(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("FRAME") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				Frame object =  new Frame(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new Frame("");
	}


	public WebStatic WebStatic(String objectName) throws IOException, DatatypeConfigurationException{
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBSTATIC") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebStatic object = new WebStatic(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebStatic("");
	}

	public WebTable WebTable(String objectName) throws IOException, DatatypeConfigurationException{
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBTABLE") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebTable object = new WebTable(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebTable("");
	}

	public WebButton WebButton(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBBUTTON") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebButton object = new WebButton(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebButton("");
	}
	
	public WebImage WebImage(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBIMAGE") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebImage object = new WebImage(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebImage("");
	}
	
	public WebTextBox WebTextBox(String objectName){
		for(int i=0;i<pageObjects.size();i++){
 			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBTEXTBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebTextBox object = new WebTextBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebTextBox("");
	}
	
	public WebComboBox WebComboBox(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBCOMBOBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebComboBox object = new WebComboBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebComboBox("");
	}
	
	public WebCheckBox WebCheckBox(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBCHECKBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebCheckBox object = new WebCheckBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebCheckBox("");
	}
	
	public WebDateField WebDateField(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBDATEFIELD") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebDateField object =  new WebDateField(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebDateField("");
	}
	
	public WebLink WebLink(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBLINK") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebLink object =  new WebLink(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebLink("");
	}
	
/**<pre>
<b>WebRadioButton</b>
*
*<i>OR JSON: </i>
*	1)Every radio button must be added to the OR json
*	
*<i>Feature file:</i>
*	2)Provide the label of the radio button as the datatable Paramater
*
*<i>Component:</i>
*	3)In the Auto-generated code
*		a)Replace the PARAMTER NAME with the Parameter provided in the feature file
*		b)Replace the MAPPED VALUE with the value of the Parameter if action/verification should be performed on that object
*	
*<i>Examples:</i>
*	{@code
*	Page.WebRadioButton("Active_Yes").click(pm.Parameter("Active"), "Yes"); 
	Page.WebRadioButton("Active_No").click(pm.Parameter("Active"), "No"); 
	}
*	</pre>
*/
	public WebRadioButton WebRadioButton(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBRADIOBUTTON") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebRadioButton object =  new WebRadioButton(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebRadioButton("");
	}
	
	public WebToggleButton WebToggleButton(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBTOGGLEBUTTON") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebToggleButton object =  new WebToggleButton(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebToggleButton("");
	}
	
	
	public WebDoubleListBox WebDoubleListBox(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBDOUBLELISTBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebDoubleListBox object =  new WebDoubleListBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebDoubleListBox("");
	}
	
	public WebCard WebCard(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBCARD") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebCard object =  new WebCard(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebCard("");
	}
	
	public WebObject WebObject(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBOBJECT") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebObject object =  new WebObject(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebObject("");
	}
	
	public WebComboMultiSelect WebComboMultiSelect(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBCOMBOMULTISELECT") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebComboMultiSelect object = new WebComboMultiSelect(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebComboMultiSelect("");
	}	

	public WebListBox WebListBox(String objectName){
		for(int i=0;i<pageObjects.size();i++){
			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBLISTBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
				WebListBox object = new WebListBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
				object.setObjectName(objectName);
				return object;
			}
		}
		return new WebListBox("");
	}	
	
	// Mobile Controls
		public AppButton AppButton(String objectName){
			for(int i=0;i<pageObjects.size();i++){
				if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("APPBUTTON") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
					AppButton object = new AppButton(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new AppButton("");
		}
		
		public AppImage AppImage(String objectName){
			for(int i=0;i<pageObjects.size();i++){
				if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("APPIMAGE") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
					AppImage object = new AppImage(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new AppImage("");
		}
		
		public AppTextBox AppTextBox(String objectName){
			for(int i=0;i<pageObjects.size();i++){
	 			if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("APPTEXTBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
	 				AppTextBox object = new AppTextBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new AppTextBox("");
		}
		
		public AppDateField AppDateField(String objectName){
			for(int i=0;i<pageObjects.size();i++){
				if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("APPDATEFIELD") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
					AppDateField object = new AppDateField(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new AppDateField("");
		}
		
		public AppListBox AppListBox(String objectName){
			for(int i=0;i<pageObjects.size();i++){
				if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("APPLISTBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
					AppListBox object = new AppListBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new AppListBox("");
		}
		
		public AppComboBox AppComboBox(String objectName){
			for(int i=0;i<pageObjects.size();i++){
				if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("APPCOMBOBOX") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
					AppComboBox object = new AppComboBox(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new AppComboBox("");
		}
		
		public WebTextEditor WebTextEditor(String objectName){
			for(int i=0;i<pageObjects.size();i++){
				if(pageObjects.get(i).getAsJsonObject().get("Object Type").getAsString().toUpperCase().contentEquals("WEBTEXTEDITOR") && pageObjects.get(i).getAsJsonObject().get("Object Name").getAsString().toUpperCase().contentEquals(objectName.toUpperCase())){
					WebTextEditor object = new WebTextEditor(pageObjects.get(i).getAsJsonObject().get("Selector").getAsString());
					object.setObjectName(objectName);
					return object;
				}
			}
			return new WebTextEditor("");
		}
}
