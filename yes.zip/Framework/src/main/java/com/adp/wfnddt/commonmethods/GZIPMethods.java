package com.adp.wfnddt.commonmethods;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;

public class GZIPMethods {
	
	public static String decompressGZIP(byte [] data) throws IOException {
        GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
       	int read;
       	byte [] buff = new byte[1024];
       	while((read = gis.read(buff)) != -1) {
       		out.write(buff, 0, read);
       	}
	    return out.toString("UTF-8");
	}
}
