package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;
import static com.adp.wfnddt.commonmethods.General.replaceSpaceKeyWord;
import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebTextEditor extends BaseObject {

	public WebTextEditor(String p_selector) {
		setSelector(p_selector);
	}

	public WebTextEditor(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void set(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		WebElement m_parentobject;
		
		//Default using tab off to clear text, if textbox having issue use method with extra argument set TabOff to false
		if (p_value.trim().contentEquals("")) return;
		p_value = p_value.trim();
		p_value = replaceSpaceKeyWord(p_value);
		findObject();
		scrollIntoView();
		m_parentobject = getObject();
		
		//ClearText
		List<WebElement> arrDatatext = getObject().findElements(By.xpath(".//span[@data-text='true']"));
		for (WebElement eachDatatextline : arrDatatext) {
			setObject (eachDatatextline);
			actionsSendKeys(Keys.chord(Keys.END, Keys.SHIFT, Keys.HOME, Keys.DELETE));
		}
		
		General.sleep(1);
		setObject (m_parentobject);
		actionsSendKeys(p_value);
		General.sleep(3);
		actionsSendKeys(Keys.TAB);
		getObject().click();

		return;
	}
		
	
	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Exact });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		String expectedValue = p_value.trim();
		expectedValue = replaceSpaceKeyWord(p_value);
		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = getActualValue();

		// Compare
		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}
	
	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = getObject().getText().trim();

		if (actualValue.contentEquals("")) {
			actualValue = getObject().getAttribute("innerText").trim();
		}

		if (actualValue.contentEquals("")) {
			actualValue = "[BLANK]";
		}
		return actualValue;
	}

//	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
//		if (exists()) {
//			if (getObject().getAttribute("class").contains("reactTextBox") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
//				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject());
//			} else {
//				super.verifyObjectProperties(p_property);
//			}
//		} else {
//			super.verifyObjectProperties(p_property);
//		}
//	}

}
