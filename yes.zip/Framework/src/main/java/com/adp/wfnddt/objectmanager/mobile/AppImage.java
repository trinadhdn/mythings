package com.adp.wfnddt.objectmanager.mobile;

import org.openqa.selenium.WebElement;

import com.adp.wfnddt.objectmanager.WebImage;

public class AppImage extends WebImage {

	public AppImage(String p_selector) {
		super(p_selector);
	}

	public AppImage(WebElement p_object) {
		super(p_object);
	}

}
