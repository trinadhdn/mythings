package com.adp.wfnddt.objectmanager;

import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.util.HashMap;
import javax.xml.datatype.DatatypeConfigurationException;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.WebTableUpdated;
import com.adp.wfnddt.core.DDTAssertionError;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebTable extends BaseObject {

	private DDTResultsReporter m_results = DDTController.getResultsReporter();

	private WebTableUpdated m_webTableMethods = new WebTableUpdated();

	Logger m_Logger = DDTLoggerManager.getLogger(WebTable.class);

	public WebTable(String p_selectorRowTable) throws IOException, DatatypeConfigurationException {
		setSelector(p_selectorRowTable);
	}

	public WebTable(WebElement p_object) {
		setObject(p_object);
	}

	@Step
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void clickLinkInTable(ParamManager p_pm, ClickType p_clickType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickObjectInTable(p_pm, new WebLink("XPATH:.//a"), p_clickType);
		return;
	}

	@Step
	public void clickObjectInTable(ParamManager p_pm, BaseObject p_actionObject) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickObjectInTable(p_pm, p_actionObject, ClickType.Simple);
	}

	@Step
	public void clickObjectInTable(ParamManager p_pm, BaseObject p_actionObject, ClickType p_clickType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		String columnName = m_webTableMethods.retrieveColumName(p_pm);

		if (rowToFind.size() <= 0 && rowNumber <= 0)
			return; // mallelak - added because component should not fail when no values are given

		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

		if (!columnName.trim().contentEquals("")) {
			WebElement tableObj = m_webTableMethods.findObjectInTableCell(getObject(), rowToFind, rowInstance, rowNumber, columnName, p_actionObject.getSelector());
			if (tableObj == null) {
				fail("The target object is not found in the table cell");
				return;
			}

			p_actionObject.setObject(tableObj);
			p_actionObject.clickOnObject(p_clickType);
		}
		return;
	}

	@Step
	public void enterDataInTable(ParamManager p_pm, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		WebElement tableObj = null;
		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> rowData = m_webTableMethods.retrieveRowData(p_pm);

		if (!(rowData.keySet().size() > 0))
			return; // mallelak - added because component should not fail when no values are given

		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

		for (String columnName : rowData.keySet()) {
			BaseObject p_actionObject = p_objectMap.getMap().get(columnName);
			String cellValue = rowData.get(columnName);
			String colName = p_objectMap.getLabelMap().get(columnName);

			if (!cellValue.contentEquals("")) {
				tableObj = m_webTableMethods.findObjectInTableCell(getObject(), rowToFind, rowInstance, rowNumber, colName, p_actionObject.getSelector());
				if (tableObj == null) {
					fail("The target object is not found in the table cell");
					return;
				}
				
				//scroll into view
				new WebObject(tableObj).scrollIntoView();
				
				// TODO Click on the webelement so that the control comes up
				switch (p_actionObject.getClass().getSimpleName()) {
				case "WebCheckBox":
					new WebCheckBox(tableObj).setValue(cellValue);
					break;

				case "WebComboBox":
					new WebComboBox(tableObj).select(cellValue);
					break;

				case "WebDateField":
					new WebDateField(tableObj).setValue(cellValue);
					break;

				case "WebTextBox":
					new WebTextBox(tableObj).set(cellValue,false);
					break;

				case "WebToggleButton":
					new WebToggleButton(tableObj).set(cellValue);
					break;

				case "WebRadioButton":
					new WebRadioButton(tableObj).click();
					break;

				case "WebButton":
					new WebButton(tableObj).click();
					break;

				case "WebLink":
					new WebLink(tableObj).click();
					break;

				default:
					DDTAssertionError.fail("Enter data on the object type -[" + p_actionObject.getClass().getSimpleName() + "] cannot be performed");
					break;
				}
			}
		}
	}

	public void verifyRowInstancesInTable(ParamManager p_pm, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		verifyRowInstancesInTable(p_pm); // Verify the row exists first then verify individual objects using RowData
		WebElement tableObj = null;
		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> rowData = m_webTableMethods.retrieveRowData(p_pm);

		if (!(rowData.keySet().size() > 0))
			return; // mallelak - added because component should not fail when no values are given

		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

		for (String columnName : rowData.keySet()) {
			BaseObject p_actionObject = p_objectMap.getMap().get(columnName);
			String cellValue = rowData.get(columnName);
			String colName = p_objectMap.getLabelMap().get(columnName);

			if (!cellValue.contentEquals("")) {
				tableObj = m_webTableMethods.findObjectInTableCell(getObject(), rowToFind, rowInstance, rowNumber, colName, p_actionObject.getSelector());
				if (tableObj == null) {
					fail("The target object is not found in the table cell");
					return;
				}

				switch (p_actionObject.getClass().getSimpleName()) {
				case "WebCheckBox":
					WebCheckBox cxb = new WebCheckBox(tableObj);
					cxb.setObjectName(colName);
					cxb.verifyValue(cellValue);
					break;

				case "WebComboBox":
					WebComboBox cbx = new WebComboBox(tableObj);
					cbx.setObjectName(colName);
					cbx.verifyValue(cellValue);
					break;

				case "WebDateField":
					WebDateField dtf = new WebDateField(tableObj);
					dtf.setObjectName(colName);
					dtf.verifyValue(cellValue);
					break;

				case "WebTextBox":
					WebTextBox wtb = new WebTextBox(tableObj);
					wtb.setObjectName(colName);
					wtb.verifyValue(cellValue);
					break;

				case "WebToggleButton":
					WebToggleButton tb = new WebToggleButton(tableObj);
					tb.setObjectName(colName);
					tb.verifyValue(cellValue);
					break;

				case "WebRadioButton":
					WebRadioButton wrb = new WebRadioButton(tableObj);
					wrb.setObjectName(colName);
					wrb.verifyValue(cellValue);
					break;

				case "WebButton":
					WebButton wb = new WebButton(tableObj);
					wb.setObjectName(colName);
					wb.verifyValue(cellValue);
					break;

				case "WebLink":
					WebLink wl = new WebLink(tableObj);
					wl.setObjectName(colName);
					wl.verifyValue(cellValue);
					break;

				default:
					DDTAssertionError.fail("Enter data on the object type -[" + p_actionObject.getClass().getSimpleName() + "] cannot be performed");
					break;
				}
			}
		}
	}

	public void verifyRowInstancesInTable(ParamManager p_pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		StatusType status = StatusType.PASSED;

		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		if (rowToFind.size() == 0) {
			rowToFind = m_webTableMethods.retrieveRowData(p_pm);
		}

		if (rowToFind.size() <= 0 && rowNumber <= 0)
			return; // mallelak - added because component should not fail when no values are given

		// currently no records
		if (rowToFind.get("[NOENTRIES]") != null){
			int noEntriesIntance = getObject().findElements(By.xpath(".//*[text()='"+rowToFind.get("[NOENTRIES]")+"']")).size();
			if (noEntriesIntance != rowInstance) {
				status = StatusType.FAILED;
			}
			m_results.addEntryToVerificationLog("Verify row instances in table for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, String.valueOf(rowInstance), String.valueOf(noEntriesIntance));
			return;
		}
		
		
		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

	
		if (rowToFind.size() > 0 || rowNumber > 0) {
			int retRow = m_webTableMethods.findRowInTable(getObject(), rowToFind, rowInstance);
			int actualValue = rowInstance;

			if (rowNumber > 0) {
				actualValue = rowNumber;
				if (retRow != rowNumber) {
					status = StatusType.FAILED;
				}
			} else {
				if (retRow <= 0 && rowInstance > 0) {
					status = StatusType.FAILED;
					actualValue = 0;
				} else if (retRow > 0 && rowInstance <= 0) {
					status = StatusType.FAILED;
					actualValue = 1;
				}
			}

			m_results.addEntryToVerificationLog("Verify row instances in table for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, String.valueOf(rowInstance), String.valueOf(actualValue));

		}

		return;
	}

	public void verifyTableCellObjectProperties(ParamManager p_pm, ObjectMap p_objectMap) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> columnData = m_webTableMethods.retrieveColumnsToVerify(p_pm);

		if (rowToFind.size() <= 0 && rowNumber <= 0)
			return; // mallelak - added because component should not fail when no values are given

		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

		for (String columnName : columnData.keySet()) {
			BaseObject p_actionObject = p_objectMap.getMap().get(columnName);
			String verifyProperty = columnData.get(columnName);
			String colName = p_objectMap.getLabelMap().get(columnName);

			if (!verifyProperty.contentEquals("")) {
				WebElement tableObj = m_webTableMethods.findObjectInTableCell(getObject(), rowToFind, rowInstance, rowNumber, colName, p_actionObject.getSelector());

				if (tableObj == null) {
					switch (verifyProperty) {
					case "[DOES_NOT_EXIST]":
					case "[DOESNOTEXIST]":
					case "[DOES NOT EXIST]":
						m_results.addEntryToVerificationLog("Verification for field: " + columnName, StatusType.PASSED, verifyProperty, "[DOES_NOT_EXIST]");
						break;
					default:
						m_results.addEntryToVerificationLog("Verification for field: " + columnName, StatusType.FAILED, verifyProperty, "[DOES_NOT_EXIST]");
						break;
					}
				} else {
					switch (p_actionObject.getClass().getSimpleName()) {
					case "WebButton":
						new WebButton(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebImage":
						new WebImage(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebLink":
						new WebLink(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebObject":
						new WebObject(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebCheckBox":
						new WebCheckBox(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebComboBox":
						new WebComboBox(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebDateField":
						new WebDateField(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebTextBox":
						new WebTextBox(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebToggleButton":
						new WebToggleButton(tableObj).verifyObjectProperties(verifyProperty);
						break;

					case "WebRadioButton":
						new WebRadioButton(tableObj).verifyObjectProperties(verifyProperty);
						break;

					default:
						DDTAssertionError.fail("Verify object properties on the object type -[" + p_actionObject.getClass().getSimpleName() + "] cannot be performed");
						break;
					}
				}
			}
		}
	}

	public void verifyRowDataListBoxContentsInTable(ParamManager p_pm, BaseObject oComboBox) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		String columnName = m_webTableMethods.retrieveColumName(p_pm);
		String typeOfTest = m_webTableMethods.retrieveTestType(p_pm);
		String p_expectedContents = m_webTableMethods.retrieveListBoxContents(p_pm);

		if (rowToFind.size() <= 0 && rowNumber <= 0)
			return; // mallelak - added because component should not fail when no values are given

		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

		if (!columnName.trim().contentEquals("")) {
			WebElement tableObj = m_webTableMethods.findObjectInTableCell(getObject(), rowToFind, rowInstance, rowNumber, columnName, oComboBox.getSelector());
			if (tableObj == null) {
				fail("The target object is not found in the table cell");
				return;
			}

			new WebComboBox(tableObj).verifyContents(p_expectedContents, typeOfTest);
		}
	}

	public WebElement getObjectInTableCell(ParamManager p_pm, BaseObject p_actionObject) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		int rowNumber = m_webTableMethods.retrieveRowNumber(p_pm);
		int rowInstance = m_webTableMethods.retrieveRowInstance(p_pm);
		HashMap<String, String> rowToFind = m_webTableMethods.retrieveRowToFind(p_pm);
		String columnName = m_webTableMethods.retrieveColumName(p_pm);

		if (rowToFind.size() <= 0 && rowNumber <= 0)
			return null; // mallelak - added because component should not fail when no values are given

		m_webTableMethods.performTableOps(this.getObject(), "GO TO FIRST PAGE", 1); // JE - added because we need to start on the first page before searching

		if (!columnName.trim().contentEquals("")) {
			WebElement tableObj = m_webTableMethods.findObjectInTableCell(getObject(), rowToFind, rowInstance, rowNumber, columnName, p_actionObject.getSelector());
			if (tableObj == null) {
				fail("The target object is not found in the table cell");
				return null;
			}
			return tableObj;
		}
		return null;
	}
}