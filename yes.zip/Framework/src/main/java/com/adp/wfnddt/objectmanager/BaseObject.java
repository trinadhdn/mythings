package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.takeComponentScreenshot;
import static com.adp.wfnddt.commonmethods.General.waitForPageLoad;
import static org.assertj.core.api.Assertions.assertThat;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.core.DDTController.Mobile_OSName;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTLoggerManager;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.core.GlobalVariables.ScrollType;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;
import io.appium.java_client.AppiumDriver;

public abstract class BaseObject {

	protected WebDriver m_webdriver = DDTController.getWebDriver();
	protected AppiumDriver<WebElement> m_appdriver = DDTController.getMobileDriver();

	protected WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
	protected WebDriverWait m_AppDriverWait = DDTController.getMobileDriverWait();

	protected By m_by = null;
	private WebElement m_object = null;
	protected String m_objectName = "";
	protected String m_selector = "";
	protected DDTResultsReporter m_results = DDTController.getResultsReporter();
	private Logger m_logger = DDTLoggerManager.getLogger(BaseObject.class);

	public enum ClickType {
		Simple, Actions, MouseOver, ScrollIntoViewClick, Robot, JSClick
	}

	public enum TextAttribute {
		Text, TextContent, InnerText, Value, Text_RemoveSplChars
	}

	public enum VerifyPropertyType {
		Default("[DEFAULT]"), DISABLED_classDisabled("[DISABLED],[ENABLED]"), DISABLED_classDisableComponent("[DISABLED],[ENABLED]"), DISABLED_outerHTMLopacity02("[DISABLED],[ENABLED]"), DISABLED_outerHTMLreadonly("[DISABLED],[ENABLED]"), DISABLED_cursorNotAllowed("[DISABLED],[ENABLED]"), DISABLED_classInactive("[DISABLED],[ENABLED]"), DISABLED_classSelected("[SELECTED],[UNSELECTED]"), DISABLED_styleopacity04("[DISABLED],[ENABLED]"), DISABLED_backGroundrgb187187187("[DISABLED],[ENABLED]"), DISABLED_ariaDisabled("[DISABLED],[ENABLED]"), DISABLED_ariaDisabledParentDiv("[DISABLED],[ENABLED]"), TEXTBOX_error("[INFIELDERROR],[NO_INFIELDERROR]");
		;

		private String property;

		private VerifyPropertyType(String p_property) {
			this.property = p_property;
		}

		public List<String> getProperties() {
			return Arrays.asList(this.property.split(","));
		}
	}

	protected void setSelector(String p_selector) {
		if (DDTController.isMobile() && DDTController.getMobileOSName().equals(Mobile_OSName.iOS)) {
			if (p_selector.toUpperCase().startsWith("XPATH:") && p_selector.contains("text()")) {
				p_selector = p_selector.replace("text()", "@text");
			}
		}

		m_selector = p_selector;
		return;
	}

	public String getSelector() {
		return m_selector;
	}

	protected void setObject(WebElement p_object) {
		m_object = p_object;
	}

	public HashMap<String, Object> getObjectInfo() {
		HashMap<String, Object> objectInfo = new HashMap<>();
		objectInfo.put("Object Name", m_objectName);
		objectInfo.put("Selector", m_selector);

		return objectInfo;
	}

	protected void findObject() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		// Wait till page loads
		waitForPageLoad();

		if (m_objectName.contentEquals(""))
			m_objectName = m_selector;

		if (m_object != null) {
			if (DDTController.getBrowserType().equals(BrowserType.Edge) || DDTController.getBrowserType().equals(BrowserType.Firefox32)) {
				((JavascriptExecutor) m_webdriver).executeScript("arguments[0].scrollIntoView(({ behavior: 'auto', block: 'center' }));", m_object);
			}
			return;
		}

		// Find the object with the appropriate selector
		if (m_selector.toUpperCase().startsWith("CSS:")) {
			m_by = By.cssSelector(m_selector.substring(4));
		} else if (m_selector.toUpperCase().startsWith("XPATH:")) {
			m_by = By.xpath(m_selector.substring(6));
		} else {
			m_by = By.cssSelector(m_selector);
		}

		m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(m_by));
		if (DDTController.getBrowserType().equals(BrowserType.Edge) || DDTController.getBrowserType().equals(BrowserType.Firefox32)) {
			((JavascriptExecutor) m_webdriver).executeScript("arguments[0].scrollIntoView(({ behavior: 'auto', block: 'center' }));", getObject());
		}
		String screenshot = takeComponentScreenshot();
		if (screenshot != "") {
			m_results.addComponentScreenshot(screenshot);
		}
		return;
	}

	public void setSelectorVariable(String p_varName, String p_replaceWith) {
		String strVariable = "$(" + p_varName + ")";
		m_selector = m_selector.replace(strVariable, p_replaceWith);
		return;
	}

	public WebElement getObject() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (m_object != null) {
			return m_object;
		} else {
			if (m_by == null) {
				findObject();
			}

			if (!DDTController.isUseAppDriver()) {
				m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(m_by));
				return m_webdriver.findElement(m_by);
			} else {
				m_AppDriverWait.until(ExpectedConditions.presenceOfElementLocated(m_by));
				return m_appdriver.findElement(m_by);
			}
		}
	}

	public List<WebElement> getObjects() throws IOException, DatatypeConfigurationException {
		if (m_selector.toUpperCase().startsWith("CSS:")) {
			m_by = By.cssSelector(m_selector.substring(4));
		} else if (m_selector.toUpperCase().startsWith("XPATH:")) {
			m_by = By.xpath(m_selector.substring(6));
		} else {
			m_by = By.cssSelector(m_selector);
		}

		if (!DDTController.isUseAppDriver()) {
			return m_webdriver.findElements(m_by);
		} else {
			return m_appdriver.findElements(m_by);
		}
	}

	public void waitForPresense() {
		if (m_by == null)
			return;
		m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(m_by));
		return;
	}

	public void waitForVisibility() {
		if (m_by == null)
			return;
		m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(m_by));
		return;
	}

	public void waitForClickable() {
		if (m_by == null)
			return;
		m_webDriverWait.until(ExpectedConditions.elementToBeClickable(m_by));
		return;
	}

	public boolean exists() {
		if (m_selector != "") {
			// Find the object with the appropriate selector
			if (m_selector.toUpperCase().startsWith("CSS:")) {
				m_by = By.cssSelector(m_selector.substring(4));
			} else if (m_selector.toUpperCase().startsWith("XPATH:")) {
				m_by = By.xpath(m_selector.substring(6));
			} else {
				m_by = By.cssSelector(m_selector);
			}

			if (!DDTController.isUseAppDriver()) {
				if (m_webdriver.findElements(m_by).size() != 0) {
					if (DDTController.getBrowserType().equals(BrowserType.Edge) || DDTController.getBrowserType().equals(BrowserType.Firefox32))
						return true;
					return (m_webdriver.findElement(m_by).isDisplayed() ? true : false);
				} else {
					return false;
				}

				// return (m_webdriver.findElements(m_by).size() != 0 ? true : false);
			} else {
				return (m_appdriver.findElements(m_by).size() != 0 ? true : false);
			}
		} else {
			return (m_object != null);
		}
	}

	public boolean isDisplayed() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		findObject();

		if (DDTController.getBrowserType().equals(BrowserType.Edge) || DDTController.getBrowserType().equals(BrowserType.Firefox32)) {
			GlobalVariables.setScrollType(ScrollType.ScrollIntoView);
			scrollIntoView();
		}

		return getObject().isDisplayed();

	}

	public boolean exists(int p_maxWaitTime) throws DDTFrameworkException {
		int itr = 1;
		boolean bElemFound = false;
		do {
			General.sleep(1);
			if (m_selector != "") {
				// Find the object with the appropriate selector
				if (m_selector.toUpperCase().startsWith("CSS:")) {
					m_by = By.cssSelector(m_selector.substring(4));
				} else if (m_selector.toUpperCase().startsWith("XPATH:")) {
					m_by = By.xpath(m_selector.substring(6));
				} else {
					m_by = By.cssSelector(m_selector);
				}

				if (!DDTController.isUseAppDriver()) {
					if (m_webdriver.findElements(m_by).size() != 0) {
						if (DDTController.getBrowserType().equals(BrowserType.Edge) || DDTController.getBrowserType().equals(BrowserType.Firefox32))
							bElemFound = true;
						bElemFound = (m_webdriver.findElement(m_by).isDisplayed() ? true : false);
					} else {
						bElemFound = false;
					}

					// bElemFound = m_webdriver.findElements(m_by).size() != 0 ? true : false;
				} else {
					bElemFound = m_appdriver.findElements(m_by).size() != 0 ? true : false;
				}
			} else {
				bElemFound = m_object != null ? true : false;
			}
			itr++;
		} while (!bElemFound && itr <= p_maxWaitTime);

		return bElemFound;
	}

	public void highlight() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		for (int i = 0; i <= 2; i++) {
			JavascriptExecutor js = (JavascriptExecutor) DDTController.getWebDriver();
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", getObject(), "color: yellow; border: 2px solid red;");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", getObject(), "");
		}
		return;
	}

	public void setObjectName(String p_objectName) {
		m_objectName = p_objectName;
		return;
	}

	protected void verifyObjectProperties(String p_property, VerifyPropertyType p_verifyPropertyType, WebElement p_objectToVerify) throws DatatypeConfigurationException, DDTFrameworkException, IOException {
		if (p_property.trim().contentEquals(""))
			return;
		String screenshot = takeComponentScreenshot();
		if (screenshot != "") {
			m_results.addComponentScreenshot(screenshot);
		}

		boolean propMatched = false;
		switch (p_verifyPropertyType) {
		case DISABLED_classDisabled:
			if (p_objectToVerify.getAttribute("class").contains("Disabled") || p_objectToVerify.getAttribute("class").contains("disabled"))
				propMatched = true;
			break;
		case DISABLED_classSelected:
			if (p_objectToVerify.getAttribute("class").contains("Selected"))
				propMatched = true;
			break;

		case DISABLED_classDisableComponent:
			if (p_objectToVerify.getAttribute("class").contains("disableComponent"))
				propMatched = true;
			break;

		case DISABLED_outerHTMLreadonly:
			if (p_objectToVerify.getAttribute("outerHTML").contains("readonly"))
				propMatched = true;
			break;

		case DISABLED_outerHTMLopacity02:
			if (p_objectToVerify.getAttribute("outerHTML").contains("opacity: 0.2;"))
				propMatched = true;
			break;

		case DISABLED_styleopacity04:
			if (p_objectToVerify.getAttribute("style").contains("opacity: 0.4;"))
				propMatched = true;
			break;

		case DISABLED_cursorNotAllowed:
			if (p_objectToVerify.getAttribute("style").contains("cursor: not-allowed;"))
				propMatched = true;
			break;

		case DISABLED_classInactive:
			if (p_objectToVerify.getAttribute("class").contains("inactive"))
				propMatched = true;
			break;
		case DISABLED_backGroundrgb187187187:
			if (p_objectToVerify.getAttribute("style").contains("background-color: rgb(187, 187, 187);") || p_objectToVerify.getAttribute("style").contains("background-color: rgb(168, 172, 172);"))
				propMatched = true;
			break;
		// added for mdf 19 radio buttons and checkboxes
		case DISABLED_ariaDisabled:
			if (p_objectToVerify.getAttribute("aria-disabled").contains("true"))
				propMatched = true;
			break;
		// added for mdf 19 radio buttons and checkboxes when OR object is DIV
		case DISABLED_ariaDisabledParentDiv:
			if (p_objectToVerify.findElement(By.xpath(".//input")).getAttribute("aria-disabled").contains("true"))
				propMatched = true;
			break;
		case TEXTBOX_error:
			if (p_objectToVerify.findElements(By.xpath("./parent::div[contains(@class,'vdl-validation-error')]")).size() > 0) {
				propMatched = true;
			}

			if (p_objectToVerify.getAttribute("class").contains("TextBoxError") || p_objectToVerify.getAttribute("class").contains("vdl-validation-error"))
				propMatched = true;
			break;
		default:
			assertThat("Invalid value for verifyObjectProperties: " + p_verifyPropertyType);
			break;
		}

		String actualValue = "";
		if (propMatched) {
			actualValue = p_verifyPropertyType.getProperties().get(0);
		} else {
			actualValue = p_verifyPropertyType.getProperties().get(1);
		}

		if (p_property.equalsIgnoreCase(actualValue)) {
			m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, p_property, actualValue);
		} else {
			m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, actualValue);
		}

		return;
	}

	public void verifyObjectProperties(String p_property, VerifyPropertyType p_verifyPropertyType) throws DatatypeConfigurationException, DDTFrameworkException, IOException {
		if (p_property.trim().contentEquals(""))
			return;

		if (p_verifyPropertyType.getProperties().contains(p_property.trim())) {
			verifyObjectProperties(p_property, p_verifyPropertyType, getObject());
		} else {
			verifyObjectProperties(p_property);
		}

		return;
	}

	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (p_property.trim().contentEquals(""))
			return;

		boolean objectExists = true;

		String screenshot = takeComponentScreenshot();
		if (screenshot != "") {
			m_results.addComponentScreenshot(screenshot);
		}
		if (exists()) {
			findObject();
		} else {
			objectExists = false;
		}
		if (m_objectName.contentEquals(""))
			m_objectName = m_selector;
		switch (p_property) {
		case "[DOES_NOT_EXIST]":
		case "[DOESNOTEXIST]":
		case "[DOES NOT EXIST]":
			if (objectExists)
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[DOES_NOT_EXIST]", "[EXISTS]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[DOES_NOT_EXIST]", "[DOES_NOT_EXIST]");
			break;
		case "[EXISTS]":
			if (objectExists)
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[EXISTS]", "[EXISTS]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[EXISTS]", "[DOES_NOT_EXIST]");
			break;
		case "[VERIFY_READONLY]":
			if (objectExists == false) {
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, "[DOES_NOT_EXIST]");
				break;
			}
			if (getObject().getAttribute("readonly") == "readonly")
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[VERIFY_READONLY]", "[VERIFY_READONLY]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[VERIFY_READONLY]", "[VERIFY_NOT_READONLY]");
			break;
		case "[VERIFY_NOT_READONLY]":
			if (objectExists == false) {
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, "[DOES_NOT_EXIST]");
				break;
			}
			if (getObject().getAttribute("readonly") != "readonly" || getObject().getAttribute("readonly") == null)
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[VERIFY_NOT_READONLY]", "[VERIFY_NOT_READONLY]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[VERIFY_NOT_READONLY]", "[VERIFY_READONLY]");
			break;
		case "[VERIFY_EDITABLE]":
			if (objectExists == false) {
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, "[DOES_NOT_EXIST]");
				break;
			}
			if (getObject().getAttribute("disabled") == "0" || !getObject().getAttribute("class").contains("dijitDisabled"))
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[VERIFY_EDITABLE]", "[VERIFY_EDITABLE]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[VERIFY_EDITABLE]", "[VERIFY_NOT_EDITABLE]");
			break;
		case "[VERIFY_NOT_EDITABLE]":
			if (objectExists == false) {
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, "[DOES_NOT_EXIST]");
				break;
			}
			if (getObject().getAttribute("disabled") == "1")
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[VERIFY_NOT_EDITABLE]", "[VERIFY_NOT_EDITABLE]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[VERIFY_NOT_EDITABLE]", "[VERIFY_EDITABLE]");
			break;
		case "[ENABLED]":
			if (objectExists == false) {
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, "[DOES_NOT_EXIST]");
				break;
			}
			if (getObject().isEnabled())
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[ENABLED]", "[ENABLED]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[ENABLED]", "[DISABLED]");
			break;
		case "[DISABLED]":
			if (objectExists == false) {
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, p_property, "[DOES_NOT_EXIST]");
				break;
			}
			if (getObject().isEnabled())
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.FAILED, "[DISABLED]", "[ENABLED]");
			else
				m_results.addEntryToVerificationLog("Verification for field: " + m_objectName, StatusType.PASSED, "[DISABLED]", "[DISABLED]");
			break;
		default:
			assertThat("Invalid value for verifyObjectProperties: " + p_property);
			break;
		}
		return;

	}

	public WebElement getShadowRoot() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;
		return (WebElement) jsExecutor.executeScript("return arguments[0].shadowRoot;", getObject());
	}

	@Step
	public void jsClick() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickOnObject(ClickType.JSClick);
		return;
	}

	@Step
	public void click() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickOnObject(ClickType.Simple);
		return;
	}

	@Step
	public void actionClick() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickOnObject(ClickType.Actions);
		return;
	}

	@Step
	public void robotClick(int p_offSetX, int p_offSetY) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickOnObject(ClickType.Robot, p_offSetX, p_offSetY);
		return;
	}

	@Step
	public void mouseOver() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickOnObject(ClickType.MouseOver);
		return;
	}

	@Step
	public void scrollIntoViewClick() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		clickOnObject(ClickType.ScrollIntoViewClick);
		return;
	}

	@Step
	public void scrollIntoView() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (DDTController.isMobile() && DDTController.getMobileOSName().equals(Mobile_OSName.iOS))
			return;

		JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;

		try {
			findObject();
			switch (GlobalVariables.getScrollType()) {
			case SkipScroll:
				break;
			case ScrollIntoView:
				jsExecutor.executeScript("arguments[0].scrollIntoView(({ behavior: 'auto', block: 'center' }));", getObject());
				break;
			case ScrollBy:
				jsExecutor.executeScript("arguments[0].scrollIntoView(true);", getObject());
				break;
			case ScrollByElement:
				jsExecutor.executeScript("window.scrollBy(" + GlobalVariables.getScrollXPixels() + "," + GlobalVariables.getScrollYPixels() + ")");
				break;
			case ScrollDown:
				jsExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
				break;
			case ScrollTop:
				jsExecutor.executeScript("window.scrollTo(0, 0)");
				break;
			case Default:
				String scrollElementToCenterJS = "var viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);" + "var elementTop = arguments[0].getBoundingClientRect().top;" + "window.scrollBy(0, elementTop-(viewHeight/2));";
				jsExecutor.executeScript(scrollElementToCenterJS, getObject());
				break;
			}
		} catch (TimeoutException e) {

		}

	}

	@Step
	public void scrollIntoView(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;
		findObject();
		switch (GlobalVariables.getScrollType()) {
		case SkipScroll:
			break;
		case ScrollIntoView:
			jsExecutor.executeScript("arguments[0].scrollIntoView(({ behavior: 'auto', block: 'center' }));", getObject());
			break;
		case ScrollBy:
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", getObject());
			break;
		case ScrollByElement:
			jsExecutor.executeScript("window.scrollBy(" + GlobalVariables.getScrollXPixels() + "," + GlobalVariables.getScrollYPixels() + ")");
			break;
		case ScrollDown:
			jsExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			break;
		case ScrollTop:
			jsExecutor.executeScript("window.scrollTo(0, 0)");
			break;
		case Default:
			String scrollElementToCenterJS = "var viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);" + "var elementTop = arguments[0].getBoundingClientRect().top;" + "window.scrollBy(0, elementTop-(viewHeight/2));";
			jsExecutor.executeScript(scrollElementToCenterJS, getObject());
			break;
		}
	}

	@Step
	public void actionsSendKeys(CharSequence keys) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		Actions actions = new Actions(m_webdriver);
		actions.moveToElement(getObject());
		actions.click();
		actions.sendKeys(keys);
		actions.build().perform();
		return;
	}

	@Step
	public void clearText() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		switch (GlobalVariables.getClearTextType()) {
		case SkipClear:
			break;
		case Clear:
			scrollIntoView();
			getObject().clear();
			break;
		case ClearRTE:
			scrollIntoView();
			getObject().sendKeys(Keys.CONTROL + "a");
			getObject().sendKeys(Keys.BACK_SPACE);
			break;
		case JSClear:
			this.jsClearText();
			break;
		case ClearKeys:
		case Default:
			scrollIntoView();
			new WebObject(getObject()).click();
			getObject().sendKeys(Keys.chord(Keys.END, Keys.SHIFT, Keys.HOME, Keys.DELETE));
			getObject().sendKeys(Keys.BACK_SPACE);
			return;
		}
	}

	@Step
	public void clearText(WebElement p_object) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		scrollIntoView();
		p_object.click();
		p_object.sendKeys(Keys.chord(Keys.END, Keys.SHIFT, Keys.HOME, Keys.DELETE));
		p_object.sendKeys(Keys.BACK_SPACE);
		return;
	}

	@Step
	public void actionsClearText() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		Actions actions = new Actions(m_webdriver);
		actions.moveToElement(getObject());
		actions.click();
		actions.sendKeys(Keys.chord(Keys.END, Keys.SHIFT, Keys.HOME, Keys.DELETE));
		actions.sendKeys(Keys.BACK_SPACE);
		actions.build().perform();
		return;
	}

	@Step
	public void jsClearText() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;
		jsExecutor.executeScript("arguments[0].value=''", getObject());

		return;
	}

	@Step
	public void jsDragAndDrop(WebElement p_target) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		String jsDragDropScript = new StringBuilder().append("function simulateDragDrop(sourceNode, destinationNode){").append("function createCustomEvent(type) {").append("       var event = new CustomEvent('CustomEvent');").append("       event.initCustomEvent(type, true, true, null);").append("       event.dataTransfer = {").append("           data: {").append("         },").append("        setData: function(type, val) {").append("            this.data[type] = val;").append("       },").append("       getData: function(type) {").append("          return this.data[type];").append("      }").append("   };").append("   return event;").append("}").append("function dispatchEvent(node, type, event) {").append("   if (node.dispatchEvent) {").append("       return node.dispatchEvent(event);").append("    }").append("      if (node.fireEvent) {").append("          return node.fireEvent('on' + type, event);").append("     }").append(" }").append("  var event = createCustomEvent('dragstart');").append("  dispatchEvent(sourceNode, 'dragstart', event);").append(" ").append("  var dropEvent = createCustomEvent('drop');").append("  dropEvent.dataTransfer = event.dataTransfer;").append("  dispatchEvent(destinationNode, 'drop', dropEvent);").append("                 ").append("   var dragEndEvent = createCustomEvent('dragend');").append("  dragEndEvent.dataTransfer = event.dataTransfer;").append("   dispatchEvent(sourceNode, 'dragend', dragEndEvent);").append("};").append("simulateDragDrop(arguments[0],arguments[1]);").toString();

		JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;
		jsExecutor.executeScript(jsDragDropScript, getObject(), p_target);
	}

	protected void clickOnObject(ClickType p_clickType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		findObject();

		// Skip other click types for Safari on iOS
		if (DDTController.isMobile() && DDTController.getMobileOSName().equals(Mobile_OSName.iOS)) {
			p_clickType = ClickType.Simple;
		}

		if (p_clickType == ClickType.Simple) {
			// fixed issue for Chrome not able to click span/div element
			try {
				getObject().click();
			} catch (Exception e) {
				if (e.getMessage().contains("Element is obscured")) {
					JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;
					jsExecutor.executeScript("arguments[0].click();", getObject());
				}
			}
		} else if (p_clickType == ClickType.Actions) {
			Actions action = new Actions(m_webdriver);
			action.moveToElement(getObject()).click().perform();
		} else if (p_clickType == ClickType.JSClick) {
			JavascriptExecutor executor = (JavascriptExecutor) m_webdriver;
			executor.executeScript("arguments[0].click();", getObject());
		} else if (p_clickType == ClickType.MouseOver) {
			Actions action = new Actions(m_webdriver);
			action.moveToElement(getObject()).perform();
		} else if (p_clickType == ClickType.ScrollIntoViewClick) {
			scrollIntoView();
			try {
				getObject().click();
			} catch (Exception e) {
				JavascriptExecutor jsExecutor = (JavascriptExecutor) m_webdriver;
				jsExecutor.executeScript("arguments[0].click();", getObject());
			}
		} else if (p_clickType == ClickType.Robot) {
			getObject().click();
			clickOnObject(ClickType.Robot, 0, 0);
		}
	}

	protected void clickOnObject(ClickType p_clickType, int p_offSetX, int p_offSetY) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		findObject();

		if (p_clickType == ClickType.Robot) {
			org.openqa.selenium.Point coordinates = getObject().getLocation();
			try {
				Robot robot = new Robot();
				robot.mouseMove(coordinates.getX() + p_offSetX, coordinates.getY() + p_offSetY);
				robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
				robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
			} catch (AWTException e) {
				throw new DDTFrameworkException(BaseObject.class, "Failed to create new Robot object", e);
			}
		}
		return;
	}

	public void clickAllObjects(ClickType p_ClickType) throws DDTFrameworkException {
		// This method will click all objects of the same selector on the page
		if (m_selector.isEmpty() || m_selector == "")
			return;
		// Find the object with the appropriate selector
		if (m_selector.toUpperCase().startsWith("CSS:")) {
			m_by = By.cssSelector(m_selector.substring(4));
		} else if (m_selector.toUpperCase().startsWith("XPATH:")) {
			m_by = By.xpath(m_selector.substring(6));
		} else {
			m_by = By.cssSelector(m_selector);
		}
		Integer i = 0, j = 1;
		while (i < 10) {
			i++;
			try {
				if (m_webdriver.findElements(m_by).size() < 1)
					break;
				for (WebElement obj : m_webdriver.findElements(m_by)) {
					switch (p_ClickType) {
					case Actions:
						setObject(obj);
						actionClick();
						break;
					case ScrollIntoViewClick:
						setObject(obj);
						scrollIntoViewClick();
						break;
					case JSClick:
						setObject(obj);
						jsClick();
						break;
					default: // Simple
						setObject(obj);
						click();
						break;
					}
					if (m_selector.toUpperCase().startsWith("XPATH:") && !obj.isDisplayed()) { // run this only if not displayed or not visible
						j++;
						m_by = By.xpath("(" + m_selector.substring(6) + ")[" + Integer.toString(j) + "]");
					}
				}
			} catch (InvalidSelectorException ise) {
				m_logger.error("Invalid selector: " + m_selector);
				break;
			} catch (Exception e) {
				m_logger.debug("clickAllObjects: Could not click on object with selector '" + m_selector + "' - continuing");
				j++;
				m_by = By.xpath("(" + m_selector.substring(6) + ")[" + Integer.toString(j) + "]");
				continue;
			}
			General.sleep(2);
		}
	}

	/*
	 * public void getShadowDOMObject(String p_rootSelector) throws DDTFrameworkException, IOException, DatatypeConfigurationException { // Shadow DOM objects are hidden so we need to look under shadow-root // Ex p_rootSelector = XPATH://*[@id='download'] - WORK IN PROGRESS! By by = null; if (p_rootSelector.toUpperCase().startsWith("CSS:")) { by = By.cssSelector(p_rootSelector.substring(4)); } else if (p_rootSelector.toUpperCase().startsWith("XPATH:")) { by = By.xpath(p_rootSelector.substring(6)); } else { by = By.cssSelector(p_rootSelector); } WebElement shadowRoot = (WebElement) ((JavascriptExecutor) m_webdriver).executeScript("return arguments[0].shadowRoot", m_webdriver.findElement(by)); m_object = shadowRoot.findElement(m_by); // Finds object under Shadow DOM return; }
	 */
	public String getTextOnObject(TextAttribute[] textAttributes) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		findObject();

		String text = "";

		List<TextAttribute> textAttributesArr = new ArrayList<>(Arrays.asList(textAttributes));

		if (textAttributesArr.contains(TextAttribute.InnerText)) {
			if ((getObject().getAttribute("innerText")) != null && !(getObject().getAttribute("innerText").isEmpty()))
				text = getObject().getAttribute("innerText");
		} else if (textAttributesArr.contains(TextAttribute.TextContent)) {
			if ((getObject().getAttribute("textContent")) != null && !(getObject().getAttribute("textContent").isEmpty()))
				text = getObject().getAttribute("textContent");
		} else if (textAttributesArr.contains(TextAttribute.Value)) {
			if ((getObject().getAttribute("value")) != null && !(getObject().getAttribute("value").isEmpty()))
				text = getObject().getAttribute("value");
		} else if (textAttributesArr.contains(TextAttribute.Text)) {
			if ((getObject().getText()) != null && !(getObject().getText().isEmpty()))
				text = getObject().getText();
		}

		if (textAttributesArr.contains(TextAttribute.Text_RemoveSplChars)) {
			text = General.convertToUTF8(text);
		}
		return text;
	}
}
