package com.adp.wfnddt.objectmanager.extendedobjects;

import com.adp.wfnddt.objectmanager.WebLink;

public class CopyIcon extends WebLink {
	public CopyIcon() {
		super("CSS:span.fa.fa-copy");
	}
}
