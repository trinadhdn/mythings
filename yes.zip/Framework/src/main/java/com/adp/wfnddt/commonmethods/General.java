package com.adp.wfnddt.commonmethods;

import static org.assertj.core.api.Assertions.fail;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.imageio.ImageIO;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.BrowserType;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.core.GlobalVariables.ClearTextType;
import com.adp.wfnddt.core.GlobalVariables.ScrollType;
import com.adp.wfnddt.objectmanager.WebButton;
import com.adp.wfnddt.objectmanager.WebComboBox;
import com.adp.wfnddt.objectmanager.WebDoubleListBox;
import com.adp.wfnddt.objectmanager.WebLink;
import com.adp.wfnddt.objectmanager.WebObject;
import com.adp.wfnddt.objectmanager.WebTextBox;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class General {
	private static boolean m_capScreenshot = false;
	private static String m_ParentWindowHandle = null;

	public static enum ComparisonType {
		Exact, CaseInsensitive, Partial, RemoveSpaces, RemoveNewLines, RemoveWhiteSpaces, Partial_RemoveAllSpaces, Exact_RemoveAllSpaces, DoesNotExist
	}

	public static String captureScreenshot(String captureName) throws IOException, DDTFrameworkException {
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");
		Date date = new Date();

		String screenshotName = "SCREENSHOT_" + InetAddress.getLocalHost().getHostName() + "_" + dateFormat.format(date).toString();
		String screenshotPath = DDTController.getScreenshotPath() + "/" + screenshotName + ".png";

		try {
			// Wait for page load
			waitForPageLoad();

			File scrFile = ((TakesScreenshot) DDTController.getWebDriver()).getScreenshotAs(OutputType.FILE);
			DDTController.addToScreenshotMap(screenshotPath, scrFile);

			// Comment the below section to copy the screenshots at the test run end
			/*
			 * if (DDTController.getRunID() > 0) { screenshotPath = screenshotPath.replace("\\", "/");
			 * 
			 * try { NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("es.ad.adp.com", "autoxpert", "adpadp"); DDTUtilityFunctions.copyLocalFileToNetFolder(scrFile, new SmbFile("smb:" + screenshotPath, auth)); } catch (Exception e) { // Copy using the file utils if the SMB fails FileUtils.copyFile(scrFile, new File(screenshotPath)); } } else { FileUtils.copyFile(scrFile, new File(screenshotPath)); }
			 */
		} catch (UnhandledAlertException ex) {
			BufferedImage image;
			try {
				image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			} catch (HeadlessException | AWTException e) {
				throw new DDTFrameworkException(General.class, "Exception while capturing screenshot through Robot");
			}
			ImageIO.write(image, "png", new File(screenshotPath));
			DDTController.getWebDriver().switchTo().alert().accept();
		} catch (WebDriverException ex) {
			BufferedImage image;
			try {
				image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			} catch (HeadlessException | AWTException e) {
				throw new DDTFrameworkException(General.class, "Exception while capturing screenshot through Robot");
			}
			ImageIO.write(image, "png", new File(screenshotPath));
		}
		return screenshotName;
	}

	public static String takeComponentScreenshot() throws IOException, DDTFrameworkException {
		if (m_capScreenshot) {
			String captureName = Thread.currentThread().getStackTrace()[4].getMethodName();
			m_capScreenshot = false;
			return captureScreenshot(captureName);
		} else {
			return "";
		}
	}

	public static void startComponent() throws DDTFrameworkException {
		m_capScreenshot = true;
		GlobalVariables.setScrollType(ScrollType.Default);
		GlobalVariables.setClearTextType(ClearTextType.Default);
		waitForGridSpinnerToComplete();
	}

	public static void waitForPageLoad() throws DDTFrameworkException {
		if (DDTController.getWebDriver() == null || DDTController.isUseAppDriver())
			return;

		int iWaitTime = 0;
		String pageLoadStatus;
		do {
			JavascriptExecutor js = (JavascriptExecutor) DDTController.getWebDriver();
			pageLoadStatus = (String) js.executeScript("return document.readyState");
			iWaitTime++;
			sleep(1);
		} while (iWaitTime <= DDTController.getMaxWaitTime() && !pageLoadStatus.equals("complete"));
	}

	public static String convertIntoSingleSpace(String p_convert) {
		String sConvert = p_convert;
		for (int i = 0; i <= 10; i++) {
			sConvert = p_convert.replace("  ", " ");
		}
		return sConvert;
	}

	public static void waitForGridSpinnerToComplete() throws DDTFrameworkException {

		WebDriver m_webDriver = DDTController.getWebDriver();
		if (m_webDriver == null)
			return;
		String spinnerSelector = "//*[(contains(@class,'gridSpinner') or contains(@class,'vdl-busy-indicator') or contains(@id,'BPEDefault.Standby') or contains(@class,'gridSpinner') or contains(@class,'revitLoadingIndicator')) and not (ancestor-or-self::*[contains(@style,'none')])]";

		// Wait till grid spinner to complete
		sleep(2);
		int iWaitTime = 0;
		do {
			boolean spinnerFound = true;
			List<WebElement> spinnerObjects = m_webDriver.findElements(By.xpath(spinnerSelector));
			if (spinnerObjects.size() == 0)
				spinnerFound = false;
			for (WebElement spinnerObj : spinnerObjects) {
				try {
					if (!spinnerObj.isDisplayed()) {
						spinnerFound = false;
						break;
					}
				} catch (StaleElementReferenceException e) {
					// Skip
				}
			}

			if (spinnerFound) {
				iWaitTime = iWaitTime + 1;
				sleep(1);
			} else {
				break;
			}
		} while (iWaitTime <= DDTController.getMaxWaitTime());
		sleep(1);
		// while (iWaitTime <= DDTController.getMaxWaitTime());
		return;
	}

	public static void parameterValueValidation(ParamManager p_paramMgr, String p_parameterName, String[] p_arrayOfAllowedValues) throws DDTFrameworkException {
		String parameterValue = p_paramMgr.Parameter(p_parameterName);

		boolean bFound = false;

		if (parameterValue.contentEquals(""))
			return;

		for (int i = 0; i < p_arrayOfAllowedValues.length; i++) {
			if (p_arrayOfAllowedValues[i].toUpperCase().trim().contentEquals(parameterValue.toUpperCase())) {
				bFound = true;
				break;
			}
		}

		if (bFound == false) {
			fail("Invalid Parameter Value for Parameter " + parameterValue + " Parameter Value >>" + parameterValue + "<< is NOT valid, you must specify one of the Valid Values as described on the Parameters Description, contact Automation Team for further assistance...  Have a Nice Day!!");
		}
	}

	public static void searchEmployee(String p_positionID, String p_lastName, String p_workedInCountry) throws DDTFrameworkException, IOException, DatatypeConfigurationException {
		if (!p_positionID.contentEquals("")) {
			searchEmployeeByPositionID(p_positionID);
		} else if (!p_lastName.contentEquals("")) {
			searchEmployeeByLastName(p_lastName, p_workedInCountry);
		}

		return;
	}

	public static void searchEmployeeByPositionID(String p_positionID) throws DDTFrameworkException, IOException, DatatypeConfigurationException {
		WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
		WebDriver m_webDriver = DDTController.getWebDriver();
		boolean bPositionIDMatch = false;

		if (p_positionID.contentEquals("")) {
			return;
		}

		// New employee IDBar
		if (new WebLink("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//button[@id='empidbar-empsearch-link']").exists()) {
			if (new WebObject("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//div[@class='empidbar-midsection-fields']//div[@class='empidbar-value empidbar-positionid'][contains(text(),'" + p_positionID + "')]").exists()) {
				return;
			}

			new WebLink("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//button[@id='empidbar-empsearch-link']").click();
			General.sleep(1);
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='skinnylist-advlink']")));
			m_webDriver.findElement(By.xpath("//button[@id='skinnylist-advlink']")).click();
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='ID Position ID']//input")));
			new WebTextBox("XPATH://div[@id='ID Last Name']//input").clearText();
			new WebTextBox("XPATH://div[@id='ID Position ID']//input").set(p_positionID);
			m_webDriver.findElement(By.xpath("//button[@id='advmode-searchall']")).click();
			General.sleep(3);
			m_webDriverWait.until(ExpectedConditions.visibilityOf(m_webDriver.findElement(By.xpath("//div[@aria-rowindex='1']//div[@aria-colindex='1']//button"))));
			m_webDriver.findElement(By.xpath("//div[@aria-rowindex='1']//div[@aria-colindex='1']//button")).click();
			General.sleep(3);
			return;
		}

		// loop 3 times
		for (int iEESearch = 1; iEESearch < 4; iEESearch = iEESearch + 1) {
			if ((m_webDriver.findElement(By.xpath("//*[@id='empIdBarEmpData_PfId_Aoid' or ( @class='empidbar-value empidbar-positionid'  and not(ancestor::div[contains(@class,'empidbar-midsection vdl-hidden-sm-down vdl-hidden-xl-up')]))]")).getText().equals(p_positionID))) {
				bPositionIDMatch = true;
				break;
			} else {
				JavascriptExecutor js = (JavascriptExecutor) m_webDriver;
				js.executeScript("$.post(\"/wfn/chr/core/ajax?action=employeeIdBarBean.processSelectedEmployeeRequestAuto&type=METHOD_ACTION\", {positionID: \"" + p_positionID + "\"},function(resp) {if (resp && resp.status === \"success\") {wfn.common.chr.employeeIdBar.navigateToEmployee('EmpIdBarEmpSelClickDummy');}});");
				sleep(3);
			}
		}

		if (!bPositionIDMatch) {
			new WebLink("CSS:#employeeIdBarEmpListTooltipBtn,.empidbar-empsearch-filter").click();
			waitForGridSpinnerToComplete();
			sleep(3);
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#advSearchLink,#skinnylist-advlink")));
			new WebLink("CSS:#advSearchLink,#skinnylist-advlink").click();
			waitForGridSpinnerToComplete();
			if (new WebLink("CSS:#advancedSearchTabContainer_tablist_searchOptions").exists()) {
				new WebLink("CSS:#advancedSearchTabContainer_tablist_searchOptions").click();
			}

			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='label_search_options_position_id_field' or (@class='fieldsrenderer-textbox' and @id='ID Position ID')]")));

			WebTextBox fileNumberEdit = new WebTextBox("CSS:#file_number,input[class*='textbox-file_number']");
			fileNumberEdit.set("");

			WebTextBox lastNameEdit = new WebTextBox("CSS:#label_search_options_last_name_field,input[class*='textbox-name']");
			lastNameEdit.set("");

			WebComboBox companyCodeComb = new WebComboBox("CSS:#widget_label_search_options_company_code_field,div[class*='selected_co_codes']");
			companyCodeComb.select("");

			WebTextBox positionIdEdit = new WebTextBox("CSS:#label_search_options_position_id_field,input[class*='textbox-position_id']");
			positionIdEdit.set(p_positionID);

			if (new WebComboBox("CSS:#widget_advancedSearchResultsGrid_toolbar_viewSelect").exists()) {
				WebComboBox showFilterComb = new WebComboBox("CSS:#widget_advancedSearchResultsGrid_toolbar_viewSelect");
				showFilterComb.select("Position");
			}
			if (new WebButton("CSS:#advmode-toggle-right").exists()) {
				new WebButton("CSS:#advmode-toggle-right").click();

			}

			WebElement searchBtn = m_webDriver.findElement(By.xpath("//*[@id='advSearchBtn_label' or @id='advmode-searchall']"));
			Actions action = new Actions(m_webDriver);
			action.moveToElement(searchBtn).click().perform();

			waitForGridSpinnerToComplete();

			m_webDriverWait.until(ExpectedConditions.visibilityOf(m_webDriver.findElement(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0' or @id='tablerenderer-empname']"))));
			sleep(3);
			m_webDriver.findElement(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0_hyperlink' or @id='tablerenderer-empname']")).click();
			sleep(3);
			m_webDriverWait.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0' or @id='tablerenderer-empname']"), 0));
		}
	}

	public static void searchEmployeeByLastName(String p_lastName, String p_workedInCountry) throws DDTFrameworkException, IOException, DatatypeConfigurationException {
		WebDriverWait m_webDriverWait = DDTController.getWebDriverWait();
		WebDriver m_webDriver = DDTController.getWebDriver();

		if (p_lastName.contentEquals("")) {
			return;
		}

		// New employee IDBar
		if (new WebLink("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//button[@id='empidbar-empsearch-link']").exists()) {
			new WebLink("XPATH://div[@class='empidbar-midsection vdl-hidden-lg-down']//button[@id='empidbar-empsearch-link']").click();
			General.sleep(1);
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='skinnylist-advlink']")));
			m_webDriver.findElement(By.xpath("//button[@id='skinnylist-advlink']")).click();
			m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='ID Position ID']//input")));
			new WebTextBox("XPATH://div[@id='ID Position ID']//input").clearText();
			new WebTextBox("XPATH://div[@id='ID Last Name']//input").set(p_lastName);
			m_webDriver.findElement(By.xpath("//button[@id='advmode-searchall']")).click();
			General.sleep(3);
			m_webDriverWait.until(ExpectedConditions.visibilityOf(m_webDriver.findElement(By.xpath("//div[@aria-rowindex='1']//div[@aria-colindex='1']//button"))));
			m_webDriver.findElement(By.xpath("//div[@aria-rowindex='1']//div[@aria-colindex='1']//button")).click();
			General.sleep(3);
			return;
		}

		new WebLink("CSS:#employeeIdBarEmpListTooltipBtn,.empidbar-empsearch-filter").click();
		waitForGridSpinnerToComplete();
		m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#advSearchLink,#skinnylist-advlink")));
		new WebLink("CSS:#advSearchLink,#skinnylist-advlink").click();
		waitForGridSpinnerToComplete();
		if (new WebLink("CSS:#advancedSearchTabContainer_tablist_searchOptions").exists()) {
			new WebLink("CSS:#advancedSearchTabContainer_tablist_searchOptions").click();
		}

		m_webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='label_search_options_position_id_field' or (@class='fieldsrenderer-textbox' and @id='ID Position ID')]")));

		WebTextBox fileNumberEdit = new WebTextBox("CSS:#file_number,input[class*='textbox-file_number']");
		fileNumberEdit.set("");

		WebTextBox lastNameEdit = new WebTextBox("CSS:#label_search_options_last_name_field,input[class*='textbox-name']");
		lastNameEdit.set(p_lastName);

		WebComboBox companyCodeComb = new WebComboBox("CSS:#widget_label_search_options_company_code_field,div[class*='selected_co_codes']");
		companyCodeComb.select("");

		WebTextBox positionIdEdit = new WebTextBox("CSS:#label_search_options_position_id_field,input[class*='textbox-position_id']");
		positionIdEdit.set("");

		if (p_workedInCountry.contentEquals("") == false) {
			new WebLink("CSS:#editSearchFieldsLink,#advmode-editall-editbtn").click();
			new WebDoubleListBox("CSS:#advancedSearchFields,.react-dual-listbox").moveValues("Worked In Country", "RIGHT");

			new WebButton("CSS:#saveSearchFieldsBtn,#dualmultipopover-btngroup-save").click();
			new WebComboBox("CSS:#label_inh_employee_workedincountry,div[class*='select-country']").select(p_workedInCountry);
		}
		if (new WebComboBox("CSS:#widget_advancedSearchResultsGrid_toolbar_viewSelect").exists()) {
			WebComboBox showFilterComb = new WebComboBox("CSS:#widget_advancedSearchResultsGrid_toolbar_viewSelect");
			showFilterComb.select("Position");
		}
		if (new WebButton("CSS:#advmode-toggle-right").exists()) {
			new WebButton("CSS:#advmode-toggle-right").click();
		}
		WebElement searchBtn = m_webDriver.findElement(By.xpath("//*[@id='advSearchBtn_label' or @id='advmode-searchall']"));
		Actions action = new Actions(m_webDriver);
		action.moveToElement(searchBtn).click().perform();

		m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0' or @id='tablerenderer-empname']")));
		m_webDriverWait.until(ExpectedConditions.visibilityOf(m_webDriver.findElement(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0' or @id='tablerenderer-empname']"))));
		m_webDriver.findElement(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0_hyperlink' or @id='tablerenderer-empname']")).click();
		sleep(3);
		m_webDriverWait.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//*[@id='advancedSearchResultsGrid_row_0_cell_0' or @id='tablerenderer-empname']"), 0));
	}

	public static void verifyOnScreenMessageOrExistanceOnPage(String p_value) throws DatatypeConfigurationException, DDTFrameworkException, IOException {
		verifyOnScreenMessageOrExistanceOnPage(p_value, false);
	}

	public static void verifyOnScreenMessageOrExistanceOnPage(String p_value, boolean errorMsg) throws DatatypeConfigurationException, DDTFrameworkException, IOException {
		if (p_value.trim().contentEquals(""))
			return;

		DDTResultsReporter m_results = DDTController.getResultsReporter();
		General.waitForGridSpinnerToComplete();
		String screenshot;
		try {
			screenshot = takeComponentScreenshot();
			if (screenshot != "") {
				m_results.addComponentScreenshot(screenshot);
			}
		} catch (IOException e) {
			throw new DDTFrameworkException(General.class, "Unable to create screenshot in verifyOnScreenMessageOrExistanceOnPage");
		}
		String[] expectedMessages = p_value.split("\\[\\+\\]");
		List<String> actualMessages = getOnscreenMessages(errorMsg);

		// Verification
		m_results.startVerificationLogStep();
		for (String expectedMessage : expectedMessages) {
			StatusType status = StatusType.FAILED;
			String actualMessageRep = String.join("[+]", actualMessages);
			expectedMessage = convertIntoSingleSpace(expectedMessage).trim();
			expectedMessage = convertToUTF8(expectedMessage);

			if (expectedMessage.toUpperCase().trim().contentEquals("[ERROR_MESSAGE_DOES_NOT_EXIST]")) {
				if (actualMessages.size() == 0) {
					status = StatusType.PASSED;
					actualMessageRep = "[ERROR_MESSAGE_DOES_NOT_EXIST]";
				}
			} else {
				for (String actualMessage : actualMessages) {
					if (expectedMessage.contains("[EXACT]")) {
						expectedMessage = expectedMessage.replace("[EXACT]", "");
						if (actualMessage.contentEquals(expectedMessage)) {
							status = StatusType.PASSED;
							actualMessageRep = actualMessage;
							break;
						}
					} else if (actualMessage.contains(expectedMessage)) {
						actualMessageRep = actualMessage;
						status = StatusType.PASSED;
						break;
					}
				}
			}
			m_results.addEntryToVerificationLog("Verify Onscreen Message", status, expectedMessage, actualMessageRep);
		}

		m_results.endVerificationLogStep();
	}

	public static List<String> getOnscreenMessages(boolean errorMsg) throws DDTFrameworkException, IOException, DatatypeConfigurationException {
		WebDriver m_webDriver = DDTController.getWebDriver();
		List<String> arrMessages = new ArrayList<String>();
		String messageSelctor = "";
		if (errorMsg) {
			messageSelctor = ".vdl-popover--error .popover-content,.errorMessageText.errorToolTip,.errorRowHdr_class,.experience-vdl-error-label,.revitTooltip3.revitTooltip3Error,.mdf-label-error,.respond-to-offer-error-label,.label-error,.vdl-validation-error,.personalInfo-vdl-error-label,.field-error,.skill-vdl-error-label,.self-review-signature-required-label,.status-vdl-error-label,.invalid-email-error-label,.required-text-font-color,.vdl-alert__content";
		} else {
			messageSelctor = ".progressLabel,.vdl-alert__content,.revitTidMessage.dijtReset.dijitInline,.revitTid3Message.dijitInline,.reactVDL.messageText.errorMessageText,.reactVDL.messageText.infoMessageText,.reactVDL.messageText.warningMessageText,.revitTid3Message.dijitInline,.reactVDL.messageText.successMessageText,.toolTip.toolTipShow.errorToolTip,.messageContent_class,.errorRowHdr_class,.adpUserCalendarWarning_class,.revitTid3Error,.experience-vdl-error-label,.vdl-alert.vdl-alert--default-style.vdl-alert--animate,.RecInterviewsNotLoggedInMsg_class,.dEOOab.RxsGPe,.vdl-modal-body,.font-size-medium,.dijitTooltip.dijitTooltipRight.revitTooltip3.revitTooltip3Error,.mdf-label-error,.respond-to-offer-error-label,.label-error,.vdl-validation-error,.personalInfo-vdl-error-label,.field-error,.skill-vdl-error-label,.self-review-signature-required-label,.status-vdl-error-label,.invalid-email-error-label,.vdl-popover__container .popover-content,.confirmationMsg:last-child";
		}

		// Wait till messages appear
		int iWaitTime = 0;
		do {
			boolean msgFound = false;
			List<WebElement> messageObjs = m_webDriver.findElements(By.cssSelector(messageSelctor));
			for (WebElement messageObj : messageObjs) {
				if (new WebObject(messageObj).isDisplayed()) {
					msgFound = true;
					break;
				}
			}

			if (!msgFound) {
				iWaitTime = iWaitTime + 2;
				sleep(2);
			} else {
				break;
			}
		} while (iWaitTime <= DDTController.getMaxWaitTime());

		// Get all messages
		List<WebElement> messageObjs = m_webDriver.findElements(By.cssSelector(messageSelctor));
		for (int i = 0; i < messageObjs.size(); i++) {
			WebElement messageObj = messageObjs.get(i);
			if (messageObj.getText() != "" && new WebObject(messageObj).isDisplayed()) {
				String actualValue = convertIntoSingleSpace(messageObj.getText().trim().replace("<br>", ""));
				actualValue = convertToUTF8(actualValue);
				arrMessages.add(actualValue);
			}
		}
		return arrMessages;
	}

	// For encoding double quote, greater than, less than
	public static String convertToUTF8(String s) {
		s = new String(s.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
		return s.toString();
	}

	public static void sleep(int p_secondsToWait) throws DDTFrameworkException {
		try {
			Thread.sleep(p_secondsToWait * 1000);
		} catch (InterruptedException e) {
			throw new DDTFrameworkException(General.class, e.getMessage(), e);
		}
		return;
	}

	public static StatusType performTextComparison(String p_expectedText, String p_actualText, ComparisonType[] p_comparisonTypes) {
		StatusType status = StatusType.PASSED;

		String expectedText = p_expectedText;
		String actualText = p_actualText;
		if (DDTController.getBrowserType() == BrowserType.Edge) {
			actualText = actualText.replaceAll("\u00A0", " ").trim();
			actualText = removeNonPrintableCharacters(actualText);
		}
		boolean bPartial = false;
		boolean bDoesNotExist = false;
		List<ComparisonType> comparisonTypes = new ArrayList<ComparisonType>(Arrays.asList(p_comparisonTypes));

		// Keywords
		if (p_expectedText.contains("[BLANK]")) {
			expectedText = "[BLANK]";
		}

		if (p_expectedText.contains("[PARTIAL]")) {
			expectedText = expectedText.replace("[PARTIAL]", "");
			comparisonTypes.add(ComparisonType.Partial);
		}

		if (p_expectedText.contains("[PARTIAL_REMOVEALLSPACES]")) {
			expectedText = expectedText.replace("[PARTIAL_REMOVEALLSPACES]", "");
			comparisonTypes.add(ComparisonType.Partial_RemoveAllSpaces);
		}

		if (p_expectedText.contains("[EXACT_REMOVEALLSPACES]")) {
			expectedText = expectedText.replace("[EXACT_REMOVEALLSPACES]", "");
			comparisonTypes.add(ComparisonType.Exact_RemoveAllSpaces);
		}

		if (p_expectedText.contains("[REMOVESPACES]")) {
			expectedText = expectedText.replace("[REMOVESPACES]", "");
			comparisonTypes.add(ComparisonType.RemoveSpaces);
		}

		if (p_expectedText.contains("[REMOVENEWLINES]")) {
			expectedText = expectedText.replace("[REMOVENEWLINES]", "");
			comparisonTypes.add(ComparisonType.RemoveNewLines);
		}

		if (p_expectedText.contains("[CASE INSENSITIVE]")) {
			expectedText = expectedText.replace("[CASE INSENSITIVE]", "");
			comparisonTypes.add(ComparisonType.CaseInsensitive);
		}

		if (p_expectedText.contains("[DOES NOT EXIST]")) {
			expectedText = expectedText.replace("[DOES NOT EXIST]", "");
			comparisonTypes.add(ComparisonType.DoesNotExist);
		}

		// Comparison Type
		for (ComparisonType compType : comparisonTypes) {
			switch (compType) {
			case Exact:
				expectedText = expectedText.trim();
				actualText = actualText.trim();
				break;

			case CaseInsensitive:
				expectedText = expectedText.toUpperCase();
				actualText = actualText.toUpperCase();
				break;

			case Partial:
				bPartial = true;
				break;

			case RemoveSpaces:
				expectedText = expectedText.replace(" ", "").trim();
				actualText = actualText.replace(" ", "").trim();
				actualText = actualText.replace("\u00A0", "").trim();
				break;

			case RemoveNewLines:
				expectedText = expectedText.replace("\n", " ").trim();
				actualText = actualText.replace("\n", " ").trim();
				break;

			case RemoveWhiteSpaces:
				expectedText = expectedText.replace("\\s", " ").trim();
				actualText = actualText.replace("\n", " ").trim();
				actualText = actualText.replace("\u00A0", " ").trim();
				break;

			case Partial_RemoveAllSpaces:
				expectedText = expectedText.replace("\n", " ").trim();
				expectedText = expectedText.replace("\\s", " ").trim();
				expectedText = expectedText.replace(" ", "").trim();
				actualText = actualText.replace("\n", " ").trim();
				actualText = actualText.replace("\\s", " ").trim();
				actualText = actualText.replace(" ", "").trim();
				actualText = actualText.replace("\u00A0", " ").trim();
				bPartial = true;
				break;
			case Exact_RemoveAllSpaces:
				expectedText = expectedText.replace("\n", " ").trim();
				expectedText = expectedText.replace("\\s", " ").trim();
				expectedText = expectedText.replace(" ", "").trim();
				actualText = actualText.replace("\n", " ").trim();
				actualText = actualText.replace("\\s", " ").trim();
				actualText = actualText.replace(" ", "").trim();
				actualText = actualText.replace("\u00A0", " ").trim();
				bPartial = false;
				break;
			case DoesNotExist:
				bDoesNotExist = true;
				break;
			}
		}

		// Compare
		if (!bPartial) {
			if ((!actualText.contentEquals(expectedText) && !bDoesNotExist) || (actualText.contentEquals(expectedText) && bDoesNotExist)) {
				status = StatusType.FAILED;
			}
		} else {
			if ((!actualText.contains(expectedText) && !bDoesNotExist) || (actualText.contains(expectedText) && bDoesNotExist)) {
				status = StatusType.FAILED;
			}
		}

		return status;
	}

	// Added to handle null charecters in Edge Browser
	public static String removeNonPrintableCharacters(String text) {
		// strips off all non-ASCII characters
		text = text.replaceAll("[^\\x00-\\x7F]", "");

		// erases all the ASCII control characters
		text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");

		// removes non-printable characters from Unicode
		text = text.replaceAll("\\p{C}", "");

		return text.trim();
	}

	public static String replaceSpaceKeyWord(String p_parameterValue) throws DDTFrameworkException, IOException, DatatypeConfigurationException {
		if (p_parameterValue.toUpperCase().contains("[SPACE]")) {
			p_parameterValue = p_parameterValue.replace("[SPACE]", " ");
		}
		if (p_parameterValue.toUpperCase().contains("[SPACE")) {
			String m_strSearchMatch = "";
			String m_strReplace = "";
			Pattern pattern = Pattern.compile("\\[SPACE\\d+\\]", Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(p_parameterValue);
			while (matcher.find()) {
				m_strSearchMatch = matcher.group(0);
				m_strReplace = m_strSearchMatch;
				int p_NumOfSpace;
				m_strReplace = m_strReplace.toUpperCase().replace("[SPACE", "").replaceAll("]", "").trim();
				if (!m_strReplace.equals("")) {
					p_NumOfSpace = Integer.parseInt(m_strReplace);
					m_strReplace = "";
					for (int i = 0; i < p_NumOfSpace; i++) {
						m_strReplace = m_strReplace + " ";
					}
				}
				p_parameterValue = p_parameterValue.replace(m_strSearchMatch, m_strReplace);
			}
		}
		return p_parameterValue;
	}

	public static String replaceParameterKeyWords(String p_parameterValue) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException {
		boolean bCADate = false;
		String p_converteddate = "";
		if (GlobalVariables.getLanguagePreference().equals("CA")) {
			bCADate = true;
		}

		// if (p_parameterValue.toUpperCase().contentEquals("[BLANK]")) {
		// p_parameterValue = "";
		// }

		// Canada Date format
		if (p_parameterValue.toUpperCase().contains("CA_")) {
			bCADate = true;
			p_parameterValue = p_parameterValue.replace("CA_", "");
		}

		// [CURRENT YEAR] - CURRENT YEAR ONLY
		if (p_parameterValue.toUpperCase().contains("[CURRENT YEAR]") || p_parameterValue.toUpperCase().contains("[CURRENTYEAR]")) {
			Date date = new Date(System.currentTimeMillis());
			p_converteddate = new SimpleDateFormat("yyyy").format(date);
			p_parameterValue = p_parameterValue.replace("[CURRENT YEAR]", p_converteddate);
			p_parameterValue = p_parameterValue.replace("[CURRENTYEAR]", p_converteddate);
		}

		// [SYSTEM DATE] - SYSTEM DATE ONLY
		if (p_parameterValue.toUpperCase().contains("[SYSTEM DATE]") || p_parameterValue.toUpperCase().contains("[SYSTEMDATE]")) {
			Date date = new Date(System.currentTimeMillis());
			if (bCADate) {
				p_converteddate = new SimpleDateFormat("dd/MM/yyyy").format(date);
				p_parameterValue = p_parameterValue.replace("[SYSTEM DATE]", p_converteddate);
				p_parameterValue = p_parameterValue.replace("[SYSTEMDATE]", p_converteddate);
			} else {
				p_converteddate = new SimpleDateFormat("MM/dd/yyyy").format(date);
				p_parameterValue = p_parameterValue.replace("[SYSTEM DATE]", p_converteddate);
				p_parameterValue = p_parameterValue.replace("[SYSTEMDATE]", p_converteddate);
			}
		}

		if (p_parameterValue.toUpperCase().contains("[SYSTEM DATE") || p_parameterValue.toUpperCase().contains("[SYSTEMDATE")) {
			String ExpectedParamterValue = p_parameterValue;
			String[] SplitSYSTEMFormatfromStr = p_parameterValue.split("SYSTEM");
			String[] SplitSYSTEMFormat = SplitSYSTEMFormatfromStr[1].split("]");
			p_parameterValue = "[SYSTEM" + SplitSYSTEMFormat[0] + "]";

			// Date Calculation
			// [SYSTEM DATE [-](nn)YR [-](nn)MO [-](nnn)DAY]
			// Ex: [CA_SYSTEM DATE 1YR 1MO -1DAY MONTHTEXT]
			if (p_parameterValue.toUpperCase().contains("[SYSTEM DATE ") || p_parameterValue.toUpperCase().contains("[SYSTEMDATE ")) {

				String p_parameterValue_Trunc = p_parameterValue.replace("[SYSTEM DATE ", "").replace("]", "").replace("[SYSTEMDATE ", "");
				String p_formatedDate;
				String p_sAdjustedDate;
				Boolean p_SDFDate = false;
				Boolean p_MonthDate = false;
				Boolean p_FullMonthDate = false;
				Date date = new Date(System.currentTimeMillis());
				int p_ChangeInYears = 0;
				int p_ChangeInMonths = 0;
				int p_ChangeInDay = 0;
				String[] aParsedCalculation;

				if (p_parameterValue_Trunc.toUpperCase().contains("SDF")) {
					p_parameterValue_Trunc = p_parameterValue_Trunc.toUpperCase().replace("SDF", "").trim();
					p_SDFDate = true;
				}
				if (p_parameterValue_Trunc.toUpperCase().contains("MONTHTEXT") || p_parameterValue_Trunc.toUpperCase().contains("FULLMONTHTEXT")) {
					p_parameterValue_Trunc = p_parameterValue_Trunc.toUpperCase().replace("MONTHTEXT", "").replace("FULLMONTHTEXT", "").trim();
					p_FullMonthDate = true;
				}
				if (p_parameterValue_Trunc.toUpperCase().contains("MONTH")) {
					p_parameterValue_Trunc = p_parameterValue_Trunc.toUpperCase().replace("MONTH", "").trim();
					p_MonthDate = true;
				}

				if (p_parameterValue_Trunc.toUpperCase().contains("YR")) {
					aParsedCalculation = p_parameterValue_Trunc.toUpperCase().split("YR");
					p_ChangeInYears = Integer.parseInt(aParsedCalculation[0].trim());
					if (aParsedCalculation.length > 1) {
						p_parameterValue_Trunc = aParsedCalculation[1].trim();
					}
					aParsedCalculation = null;

				}
				if (p_parameterValue_Trunc.toUpperCase().contains("MO")) {
					aParsedCalculation = p_parameterValue_Trunc.toUpperCase().split("MO");
					p_ChangeInMonths = Integer.parseInt(aParsedCalculation[0].trim());
					if (aParsedCalculation.length > 1) {
						p_parameterValue_Trunc = aParsedCalculation[1].trim();
					}
					aParsedCalculation = null;
				}
				if (p_parameterValue_Trunc.toUpperCase().contains("DAY")) {
					aParsedCalculation = p_parameterValue_Trunc.toUpperCase().split("DAY");
					p_ChangeInDay = Integer.parseInt(aParsedCalculation[0].trim());
					if (aParsedCalculation.length > 1) {
						p_parameterValue_Trunc = aParsedCalculation[1].trim();
					}
					aParsedCalculation = null;
				}

				SimpleDateFormat p_sdf = new SimpleDateFormat("MM/dd/yyyy");
				Calendar c = Calendar.getInstance();
				p_formatedDate = new SimpleDateFormat("MM/dd/yyyy").format(date);

				c.setTime(p_sdf.parse(p_formatedDate));

				c.add(Calendar.YEAR, p_ChangeInYears);
				c.add(Calendar.MONTH, p_ChangeInMonths);
				c.add(Calendar.DATE, p_ChangeInDay);

				p_sAdjustedDate = p_sdf.format(c.getTime());
				Date p_dAdjustedDate = new SimpleDateFormat("MM/dd/yyyy").parse(p_sAdjustedDate);
				p_parameterValue = new SimpleDateFormat("MM/dd/yyyy").format(p_dAdjustedDate);

				// Get Date Output Format
				// Ex: [SYSTEM DATE -30YR 2MO 1DAY SDF]
				// SDF - Single Dig Format ex:1/1/2010
				// TEXT - Jan 01, 2010
				// MONTHTEXT/FULLMONTHTEXT - January 01, 2010
				if (bCADate) { // Added because CA_SYSTEM Date with MO or YR was not working
					p_parameterValue = new SimpleDateFormat("dd/MM/yyyy").format(p_dAdjustedDate);
				} else {
					p_parameterValue = new SimpleDateFormat("MM/dd/yyyy").format(p_dAdjustedDate);
				}
				if (p_SDFDate) {
					if (bCADate) {
						p_parameterValue = new SimpleDateFormat("d/M/yyyy").format(p_dAdjustedDate);
					} else {
						p_parameterValue = new SimpleDateFormat("M/d/yyyy").format(p_dAdjustedDate);
					}
				}
				if (p_FullMonthDate) {
					if (bCADate) {
						p_parameterValue = new SimpleDateFormat("dd MMMM, yyyy").format(p_dAdjustedDate);
					} else {
						p_parameterValue = new SimpleDateFormat("MMMM dd, yyyy").format(p_dAdjustedDate);
					}
					p_parameterValue_Trunc = p_parameterValue_Trunc.replace("MONTHTEXT", "").replace("FULLMONTHTEXT", "");
				}
				if (p_MonthDate) {
					if (bCADate) {
						p_parameterValue = new SimpleDateFormat("dd MMM, yyyy").format(p_dAdjustedDate);
					} else {
						p_parameterValue = new SimpleDateFormat("MMM dd, yyyy").format(p_dAdjustedDate);
					}
				}

			}
			p_parameterValue = ExpectedParamterValue.replace("[SYSTEM" + SplitSYSTEMFormat[0] + "]", p_parameterValue);
		}

		if (p_parameterValue.toUpperCase().contains("[JSONDATA_")) {
			String strVal = JSONMethods.getJSONData(p_parameterValue.substring(p_parameterValue.indexOf("[JSONDATA_") + 10, p_parameterValue.indexOf("]", p_parameterValue.indexOf("[JSONDATA_"))).trim());
			p_parameterValue = p_parameterValue.replace(p_parameterValue.substring(p_parameterValue.indexOf("[JSONDATA_"), p_parameterValue.indexOf("]", p_parameterValue.indexOf("[JSONDATA_")) + 1), strVal);
		}

		if (p_parameterValue.toUpperCase().contains("CURRENTDATE")) {
			p_parameterValue = transformDate(p_parameterValue);
		}
		if (p_parameterValue.toUpperCase().contains("[PIPE]")) {
			p_parameterValue = p_parameterValue.replace("[PIPE]", "|");
		}
		if (p_parameterValue.toUpperCase().contains("[AUTOSYSTEM")) {
			p_parameterValue = pto_DateKeywords(p_parameterValue);
		}
		return p_parameterValue;
	}

	public static String transformDate(String p_parameterValue) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException {

		String sPhrase, sNewPhrase;
		if (p_parameterValue.contains("[CURRENTDATE]") && p_parameterValue.contains("[##") && p_parameterValue.contains("##]")) {
			for (String sSubPhrase : p_parameterValue.split("\\[##")) {
				if (sSubPhrase.contains("##]")) {
					sPhrase = sSubPhrase.split("##]")[0];
					sNewPhrase = evaluateDateKeyword(sPhrase);
					p_parameterValue = p_parameterValue.replace("[##" + sPhrase + "##]", sNewPhrase);
				}
			}
		}
		return p_parameterValue;
	}

	public static String evaluateDateKeyword(String sKeyword) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException {

		String sCurrChar, sOperator, sWeekDay;
		String sKey = "", vDate = null, sOperations = null;
		int iChange, iExpNumber, iWeekDayCount;
		int iWeekDay = 0;
		Date dTempDate;

		String sDataType = sKeyword.split("\\(")[0].toUpperCase().trim();
		String sSubKeyword = sKeyword.split("\\(")[1].split("\\)")[0].toUpperCase().trim();
		String sBaseType = sSubKeyword.split("\\[")[1].split("\\]")[0].toUpperCase().trim();
		if (sSubKeyword.split("\\]").length > 1) {
			sOperations = sSubKeyword.split("\\]")[1].toUpperCase().trim();
		}

		Calendar c = Calendar.getInstance();
		Date dDate = new Date();
		switch (sBaseType) {
		case "CURRENTDATE":
			if (!(sOperations == null)) {
				dDate = Calendar.getInstance().getTime();
				for (int i = 1; i <= sOperations.length(); i++) {
					sCurrChar = Character.toString(sOperations.charAt(i - 1));
					if (sCurrChar.contentEquals("-") || sCurrChar.contentEquals("+") || i == sOperations.length()) {
						if (i == sOperations.length()) {
							sKey = sKey + sCurrChar;
						}
						if (i > 1) {
							// TODO: Below might fail if length is less than 3
							if (sKey.substring(sKey.length() - 3).contentEquals("DAY")) {
								iChange = Integer.parseInt(sKey.replace("DAY", "").trim());
								dDate = dateAdd("d", iChange, dDate);
							} else if (sKey.substring(sKey.length() - 2).contentEquals("WK")) {
								iChange = Integer.parseInt(sKey.replace("WK", "").trim()) * 7;
								dDate = dateAdd("d", iChange, dDate);
							} else if (sKey.substring(sKey.length() - 2).contentEquals("MO")) {
								iChange = Integer.parseInt(sKey.replace("MO", "").trim());
								dDate = dateAdd("m", iChange, dDate);
							} else if (sKey.substring(sKey.length() - 2).contentEquals("YR")) {
								iChange = Integer.parseInt(sKey.replace("YR", "").trim());
								dDate = dateAdd("yyyy", iChange, dDate);
							} else if (sKey.contains("[CURRENTWEEKDAY]") || sKey.contains("SUN") || sKey.contains("MON") || sKey.contains("TUE") || sKey.contains("WED") || sKey.contains("THU") || sKey.contains("FRI") || sKey.contains("SAT")) {
								sOperator = Character.toString(sKey.charAt(0));
								iExpNumber = Integer.parseInt(Character.toString(sKey.charAt(1)));
								if (sKey.contains("[CURRENTWEEKDAY]")) {
									c.setTime(Calendar.getInstance().getTime());
									iWeekDay = c.get(Calendar.DAY_OF_WEEK);
								} else {
									sWeekDay = sKey.substring(3, sKey.length());
									switch (sWeekDay) {
									case "SUN":
										iWeekDay = 1;
										break;
									case "MON":
										iWeekDay = 2;
										break;
									case "TUE":
										iWeekDay = 3;
										break;
									case "WED":
										iWeekDay = 4;
										break;
									case "THU":
										iWeekDay = 5;
										break;
									case "FRI":
										iWeekDay = 6;
										break;
									case "SAT":
										iWeekDay = 7;
										break;
									}
								}

								// Evaluate Week Days
								iWeekDayCount = 0;
								for (int j = 0; j <= 70; j++) {
									if (sOperator == "+") {
										dTempDate = dateAdd("d", j, dDate);
									} else {
										dTempDate = dateAdd("d", -j, dDate);
									}
									c.setTime(dTempDate);
									if (c.get(Calendar.DAY_OF_WEEK) == iWeekDay) {
										iWeekDayCount = iWeekDayCount + 1;
										if (iWeekDayCount == iExpNumber) {
											dDate = dTempDate;
											break;
										}
									}
								}
							}
						}
						sKey = "";
					}
					sKey = sKey + sCurrChar;
				}
			}
		}

		// Get the date type value
		DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
		switch (sDataType) {
		case "DATE":
			vDate = dateFormat.format(dDate);
			break;
		case "DAY":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.DAY_OF_MONTH));
			break;
		case "DD":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.DAY_OF_MONTH));
			if (vDate.length() == 1) {
				vDate = "0" + vDate;
			}
			break;
		case "MO":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.MONTH) + 1);
			break;
		case "MM":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.MONTH) + 1);
			if (vDate.length() == 1) {
				vDate = "0" + vDate;
			}
			break;
		case "YR":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.YEAR));
			break;
		case "YY":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.YEAR));
			vDate = vDate.substring(2, 4);
			break;
		case "MONAME":
			c.setTime(dDate);
			vDate = new DateFormatSymbols().getMonths()[c.get(Calendar.MONTH) - 1];
			break;
		case "MMM":
			c.setTime(dDate);
			vDate = new SimpleDateFormat("MMM").format(dDate);
			break;
		case "WEEKDAY":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.DAY_OF_WEEK));
			switch (vDate) {
			case "1":
				vDate = "Sunday";
				break;
			case "2":
				vDate = "Monday";
				break;
			case "3":
				vDate = "Tuesday";
				break;
			case "4":
				vDate = "Wednesday";
				break;
			case "5":
				vDate = "Thursday";
				break;
			case "6":
				vDate = "Friday";
				break;
			case "7":
				vDate = "Saturday";
				break;
			}
		case "DOW":
			c.setTime(dDate);
			vDate = Integer.toString(c.get(Calendar.DAY_OF_WEEK));
			switch (vDate) {
			case "1":
				vDate = "Sun";
				break;
			case "2":
				vDate = "Mon";
				break;
			case "3":
				vDate = "Tue";
				break;
			case "4":
				vDate = "Wed";
				break;
			case "5":
				vDate = "Thu";
				break;
			case "6":
				vDate = "Fri";
				break;
			case "7":
				vDate = "Sat";
				break;
			}
		}

		return vDate;
	}

	public static String pto_DateKeywords(String p_parameterValue) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException {

		String tDayNo = "", sTemp1 = "", sTempDate = "";
		String[] sPar = null;
		Calendar c = Calendar.getInstance();
		Date dDate = Calendar.getInstance().getTime();
		Date sStartDate = dDate, sEndDate = null, tDate;
		DateFormat tDatef = new SimpleDateFormat("MM/dd/yyyy");

		p_parameterValue = p_parameterValue.replace("- /]", "-/]");

		while (p_parameterValue.contains("[AUTOSYSTEM")) {
			if (p_parameterValue.contains("[AUTOSYSTEMDATE")) {

				String[] aTemp1 = p_parameterValue.split("\\[AUTOSYSTEMDATE", 2);
				String[] aTemp2 = aTemp1[1].split("]", 2);
				sTemp1 = "[AUTOSYSTEMDATE" + aTemp2[0] + "]";

				String trimmed_Date = sTemp1.substring(1, sTemp1.length() - 1);
				sPar = trimmed_Date.split(" ");
				String noWeeks = sPar[3].replace("]", "");

				sTempDate = tDatef.format(sStartDate);
				tDate = tDatef.parse(sTempDate);

				c.setTime(tDate);
				tDayNo = Integer.toString(c.get(Calendar.DAY_OF_WEEK));

				int a = Integer.parseInt(noWeeks) - 1;
				int eDay = Integer.parseInt(sPar[2]);

				switch (sPar[1]) {
				case "1":
					eDay = Integer.parseInt(sPar[2]) - 1;
					if (Integer.parseInt(tDayNo) > 1) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo), sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				case "2":
					eDay = Integer.parseInt(sPar[2]) - 2;
					if (Integer.parseInt(tDayNo) > 2) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) + 1, sStartDate);
					} else if (Integer.parseInt(tDayNo) < 2) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) - 6, sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				case "3":
					eDay = Integer.parseInt(sPar[2]) - 3;
					if (Integer.parseInt(tDayNo) > 3) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) + 2, sStartDate);
					} else if (Integer.parseInt(tDayNo) < 3) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) - 5, sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				case "4":
					eDay = Integer.parseInt(sPar[2]) - 4;
					if (Integer.parseInt(tDayNo) > 4) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) + 3, sStartDate);
					} else if (Integer.parseInt(tDayNo) < 4) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) - 4, sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				case "5":
					eDay = Integer.parseInt(sPar[2]) - 5;
					if (Integer.parseInt(tDayNo) > 5) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) + 4, sStartDate);
					} else if (Integer.parseInt(tDayNo) < 5) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) - 3, sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				case "6":
					eDay = Integer.parseInt(sPar[2]) - 6;
					if (Integer.parseInt(tDayNo) > 6) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) + 5, sStartDate);
					} else if (Integer.parseInt(tDayNo) < 6) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) - 2, sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				case "7":
					eDay = Integer.parseInt(sPar[2]) - 7;
					if (Integer.parseInt(tDayNo) < 7) {
						sStartDate = dateAdd("d", 8 - Integer.parseInt(tDayNo) - 1, sStartDate);
					}
					sEndDate = dateAdd("d", (7 * a) + eDay, sStartDate);
					break;
				}
			} else if (p_parameterValue.contains("[AUTOSYSTEMMONTH")) {

				String[] aTemp1 = p_parameterValue.split("\\[AUTOSYSTEMMONTH", 2);
				String[] aTemp2 = aTemp1[1].split("]", 2);

				sTemp1 = "[AUTOSYSTEMMONTH" + aTemp2[0] + "]";

				String trimmed_Date = sTemp1.substring(1, sTemp1.length() - 1);
				sPar = trimmed_Date.split(" ");

				int iMonRange = Integer.parseInt(sPar[1]);

				sStartDate = dateAdd("m", iMonRange, sStartDate);
				sEndDate = dateAdd("m", iMonRange + 1, sStartDate);

			} else if (p_parameterValue.contains("[AUTOSYSTEMYEAR")) {

				String[] aTemp1 = p_parameterValue.split("\\[AUTOSYSTEMYEAR", 2);
				String[] aTemp2 = aTemp1[1].split("]", 2);

				sTemp1 = "[AUTOSYSTEMYEAR" + aTemp2[0] + "]";

				String trimmed_Date = sTemp1.substring(1, sTemp1.length() - 1);
				sPar = trimmed_Date.split(" ");

				int iYrRange = Integer.parseInt(sPar[1]);

				sStartDate = dateAdd("yyyy", iYrRange, sStartDate);
				c.setTime(sStartDate);
				sTempDate = "01/01/" + Integer.toString(c.get(Calendar.YEAR));
				sStartDate = tDatef.parse(sTempDate);

				sEndDate = dateAdd("yyyy", iYrRange + 1, sStartDate);
				c.setTime(sEndDate);
				sTempDate = "01/01/" + Integer.toString(c.get(Calendar.YEAR));
				sEndDate = tDatef.parse(sTempDate);

			} else if (p_parameterValue.contains("[AUTOSYSTEMLEAPYEAR")) {

				String[] aTemp1 = p_parameterValue.split("\\[AUTOSYSTEMLEAPYEAR", 2);
				String[] aTemp2 = aTemp1[1].split("]", 2);

				sTemp1 = "[AUTOSYSTEMLEAPYEAR" + aTemp2[0] + "]";

				String trimmed_Date = sTemp1.substring(1, sTemp1.length() - 1);
				sPar = trimmed_Date.split(" ");

				int vYear = c.get(Calendar.YEAR);// Integer.parseInt(sPar[1]);
				int sCount = 0;
				boolean Flag = false;
				do {
					if ((vYear % 4 == 0) && (vYear % 100 != 0)) {
						sCount = sCount + 1;
						if (sCount == 1) {
							Flag = false;
							sTempDate = "01/01/" + vYear;
							sStartDate = tDatef.parse(sTempDate);
						} else if (sCount == 2) {
							Flag = true;
							sTempDate = "01/01/" + vYear;
							sEndDate = tDatef.parse(sTempDate);
						} else {
							Flag = false;
						}
					}
					vYear = vYear + 1;
				} while (Flag == false);

			} else {
				sTempDate = tDatef.format(sStartDate);
				sStartDate = tDatef.parse(sTempDate);
			}

			String[] aVar = sPar[0].split("_");

			if (aVar[1].contentEquals("S")) {
				p_parameterValue = p_parameterValue.replace(sTemp1, tDatef.format(sStartDate));
			} else if (aVar[1].contentEquals("E")) {
				p_parameterValue = p_parameterValue.replace(sTemp1, tDatef.format(sEndDate));
			}
		}

		return p_parameterValue;
	}

	public static Date dateAdd(String type, int increment, Date date) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		switch (type.toLowerCase()) {
		case "d":
			cal.add(Calendar.DATE, increment);
			break;
		case "m":
			cal.add(Calendar.MONTH, increment);
			break;
		case "yyyy":
			cal.add(Calendar.YEAR, increment);
			break;
		}

		return cal.getTime();
	}

	public static String getUniqueFilename(String start) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException {

		String strDate1;
		Date now = new Date();
		// SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss a");

		if (start.contentEquals("@")) {
			start = "---";
		}

		// strDate = sdf.format(now);
		strDate1 = sdf1.format(now);
		// strDate2 = strDate + "_" + strDate1;
		return start + (getAlphaNumericString(2) + "_" + strDate1).replace("-", "").replace(":", "").replace(" ", "");

	}

	// function to generate a random string of length n
	public static String getAlphaNumericString(int n) {

		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789";

		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			int index = (int) (AlphaNumericString.length() * Math.random());

			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	// Window methods
	public static void switchToChildWindow(String p_ChildWindowTitle) {
		WebDriver m_webdriver = DDTController.getWebDriver();
		m_ParentWindowHandle = m_webdriver.getWindowHandle();

		// Block to iterate over WindowHandles
		for (String sWindowHandle : m_webdriver.getWindowHandles()) {
			if (m_webdriver.switchTo().window(sWindowHandle).getTitle().equalsIgnoreCase(p_ChildWindowTitle)) {
				m_webdriver.manage().window().maximize();
				break;
			}
		}
		return;
	}

	public static void switchToChildWindow(WebObject p_Object, Integer p_Occurrence) {
		WebDriver m_webdriver = DDTController.getWebDriver();
		m_ParentWindowHandle = m_webdriver.getWindowHandle();

		// Block to iterate over WindowHandles
		for (String sWindowHandle : m_webdriver.getWindowHandles()) {
			m_webdriver.switchTo().window(sWindowHandle);
			if (p_Object.exists() && p_Occurrence <= 1) {
				// m_webdriver.manage().window().maximize();
				break;
			} else if (p_Object.exists()) {
				p_Occurrence--;
			}
		}
		return;
	}

	public static void closeChildWindow(String p_ChildWindowTitle) {
		WebDriver m_webdriver = DDTController.getWebDriver();

		// Block to iterate over WindowHandles and close Child Window
		for (String sWindowHandle : m_webdriver.getWindowHandles()) {
			if (m_webdriver.switchTo().window(sWindowHandle).getTitle().equalsIgnoreCase(p_ChildWindowTitle)) {
				m_webdriver.close();
				m_webdriver.switchTo().window(m_ParentWindowHandle);
				break;
			}
		}
		return;
	}

	public static void switchToMainWindow(String p_MainWindowTitle) {

		WebDriver m_webdriver = DDTController.getWebDriver();

		if (!p_MainWindowTitle.trim().contentEquals("")) {
			// Block to iterate over WindowHandles and switch to Main Window
			for (String sWindowHandle : m_webdriver.getWindowHandles()) {
				if (m_webdriver.switchTo().window(sWindowHandle).getTitle().trim().equalsIgnoreCase(p_MainWindowTitle)) {
					m_webdriver.manage().window().maximize();
					break;
				}
			}
		} else {
			m_webdriver.switchTo().defaultContent();
		}
		return;
	}

	public static int getFoundElementIndex(String[] p_selectors, int p_maxWaitTime) throws DDTFrameworkException {
		int index = -1;
		int itr = 1;
		do {
			General.sleep(1);
			for (int i = 0; i < p_selectors.length; i++) {
				String selector = p_selectors[i];
				if (new WebObject(selector).exists()) {
					return i;
				}
				itr++;
			}
		} while (itr <= p_maxWaitTime);

		return index;
	}

	public static void sendEmail(String p_htmlFilePath, String p_subject, String p_from, String p_toDistributionList) throws IOException {
		// using host as localhost
		String host = "172.26.243.42";

		// Getting system properties
		Properties properties = System.getProperties();

		// Setting up mail server
		properties.setProperty("mail.smtp.host", host);

		// creating session object to get properties
		Session session = Session.getDefaultInstance(properties);

		try {
			// MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From Field: adding senders email to from field.
			message.setFrom(new InternetAddress(p_from));

			// Set To Field: adding recipient's email to from field.
			// message.addRecipient(Message.RecipientType.TO, new InternetAddress(p_toDistributionList));
			message.addRecipients(Message.RecipientType.TO, p_toDistributionList);

			// Set Subject
			message.setSubject(p_subject);

			String message1 = new String(Files.readAllBytes(Paths.get(p_htmlFilePath)));
			message.setContent(message1, "text/html");

			// Send email.
			Transport.send(message);
			// System.out.println("Mail successfully sent");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}

	public static void sendEmailAttachment(String p_htmlFilePath, String p_subject, String p_from, String p_toDistributionList) throws IOException {
		// using host as localhost
		String host = "172.26.243.42";

		// Getting system properties
		Properties properties = System.getProperties();

		// Setting up mail server
		properties.setProperty("mail.smtp.host", host);

		// creating session object to get properties
		Session session = Session.getDefaultInstance(properties);

		try {
			// MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From Field: adding senders email to from field.
			message.setFrom(new InternetAddress(p_from));

			// Set To Field: adding recipient's email to from field.

			message.addRecipients(Message.RecipientType.TO, p_toDistributionList);

			Multipart multipart = new MimeMultipart();
			// Set Subject
			message.setSubject(p_subject);
			// BodyPart messageBodyPart1 = new MimeBodyPart();

			// Set Body
			BodyPart messageBodyPart = new MimeBodyPart();
			DataSource source = new FileDataSource(p_htmlFilePath);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(p_htmlFilePath);
			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);

			// Send email.
			Transport.send(message);
			// System.out.println("Mail successfully sent");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}

	public static String sortedString(String inputString) {
		// convert input string to char array
		char tempArray[] = inputString.toCharArray();

		// sort tempArray
		Arrays.sort(tempArray);

		// return new sorted string
		return new String(tempArray);
	}
}
