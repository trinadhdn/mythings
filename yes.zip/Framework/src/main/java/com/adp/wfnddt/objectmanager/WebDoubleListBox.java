package com.adp.wfnddt.objectmanager;

import org.openqa.selenium.*;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

import static org.assertj.core.api.Assertions.*;

import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

public class WebDoubleListBox extends BaseObject {

	public WebDoubleListBox(String p_selector) {
		setSelector(p_selector);
	}

	public WebDoubleListBox(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value(s) to select", "Side" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void moveValues(String p_value, String p_side) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		moveValues(p_value, p_side, ClickType.Simple);
	}
	
	
	public void moveValues(String p_value, String p_side, ClickType p_typeOfClick) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForClickable();

		// Configure the move left/right buttons
		WebElement moveAllRight = null;
		WebElement moveSelectedRight = null;
		WebElement moveSelectedLeft = null;
		WebElement moveAllLeft = null;
		WebElement option = null;

		String className = getObject().getAttribute("class");
		if (className.contains("revitDualMultiSelect")) {
			moveAllRight = getObject().findElement(By.xpath(".//span[contains(@class,'revitButton') and @title='Move All Right']"));
			moveSelectedRight = getObject().findElement(By.xpath(".//span[contains(@class,'revitButton') and @title='Move Selected Right']"));
			moveSelectedLeft = getObject().findElement(By.xpath(".//span[contains(@class,'revitButton') and @title='Move Selected Left']"));
			moveAllLeft = getObject().findElement(By.xpath(".//span[contains(@class,'revitButton') and @title='Move All Left']"));
		} else if (className.contains("react-dual-listbox")) {
			moveAllRight = getObject().findElement(By.xpath(".//button[contains(@class,'rdl-move-right') and @title='Move all right']"));
			moveSelectedRight = getObject().findElement(By.xpath(".//button[contains(@class,'rdl-move-right') and @title='Move right']"));
			moveSelectedLeft = getObject().findElement(By.xpath(".//button[contains(@class,'rdl-move-left') and @title='Move left']"));
			moveAllLeft = getObject().findElement(By.xpath(".//button[contains(@class,'rdl-move-left') and @title='Move all left']"));
		} else if (className.contains("vdl-dual-select")) {
			moveAllRight = getObject().findElement(By.xpath(".//button[contains(@class,'move-all-right') and @title='Move all right']"));
			moveSelectedRight = getObject().findElement(By.xpath(".//button[contains(@class,'move-right') and @title='Move right']"));
			moveSelectedLeft = getObject().findElement(By.xpath(".//button[contains(@class,'move-left') and @title='Move left']"));
			moveAllLeft = getObject().findElement(By.xpath(".//button[contains(@class,'move-all-left') and @title='Move all left']"));
		}

		else {
			moveAllRight = getObject().findElement(By.xpath(".//div[@id='add-all']"));
			moveSelectedRight = getObject().findElement(By.xpath(".//div[@id='add-one']"));
			moveSelectedLeft = getObject().findElement(By.xpath(".//div[@id='remove-one']"));
			moveAllLeft = getObject().findElement(By.xpath(".//div[@id='remove-all']"));
		}

		String[] inputItems = p_value.split(";");
		switch (inputItems[0].trim().toUpperCase()) {
		case "SELECTALL":
		case "[SELECTALL]":
			if (p_side.trim().equalsIgnoreCase("RIGHT")) {
				new WebObject(moveAllRight).clickOnObject(p_typeOfClick);
			} else {
				new WebObject(moveAllLeft).clickOnObject(p_typeOfClick);
			}
			break;
		case "EMPTY":
		case "[EMPTY]":
			if (p_side.trim().equalsIgnoreCase("LEFT")) {
				new WebObject(moveAllRight).clickOnObject(p_typeOfClick);
			} else {
				new WebObject(moveAllLeft).clickOnObject(p_typeOfClick);
			}
			break;
		default:
			if (p_side.trim().equalsIgnoreCase("RIGHT")) {
				new WebObject(moveAllLeft).clickOnObject(p_typeOfClick);
			} 
			else if (p_side.trim().equalsIgnoreCase("LEFT")) {
				new WebObject(moveAllRight).clickOnObject(p_typeOfClick);
			}

			General.sleep(5);
			for (int i = 0; i < inputItems.length; i++) {
				if (className.contains("react-dual-listbox"))
					option = getObject().findElement(By.xpath(".//option[translate(text(),' ', '')='" + inputItems[i].trim() + "']"));

				else if (className.contains("vdl-dual-select")) {
					option = getObject().findElement(By.xpath(".//li/span[translate(text(),' ', '')='" + inputItems[i].trim() + "']"));
				}

				else {
					option = getObject().findElement(By.xpath(".//li[translate(text(),' ', '')='" + inputItems[i].trim() + "']")); // Replace
																															// white
																															// spaces
				}
				if (option != null) {
					option.click();
					if (p_side.trim().equalsIgnoreCase("RIGHT") || p_side.trim().equalsIgnoreCase("RIGHTSELECTED")) {
						new WebObject(moveSelectedRight).clickOnObject(p_typeOfClick);
					} else if (p_side.trim().equalsIgnoreCase("LEFT") || p_side.trim().equalsIgnoreCase("LEFTSELECTED")) {
						new WebObject(moveSelectedLeft).clickOnObject(p_typeOfClick);
					}
				} else {
					fail("The value [" + inputItems[i] + "] is not found in the DoublelistBox");
					return;
				}
			}
			break;
		}

		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value, String p_boxSide) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		DDTResultsReporter results = DDTController.getResultsReporter();

		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		
		String strActual = getActualValue(p_boxSide);
		
		if (p_value.trim().contentEquals(strActual)) {
			results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\") - " + p_boxSide, StatusType.PASSED, p_value, strActual);
		} else {
			results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\") - " + p_boxSide, StatusType.FAILED, p_value, strActual);
		}
		return;
	}
	
	public String getActualValue(String p_boxSide) throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		WebElement boxElem = null;
		List<WebElement> arrItems = null;
		String className = getObject().getAttribute("class");

		if (p_boxSide.trim().equalsIgnoreCase("LEFT")) {
			if (className.contains("react-dual-listbox")) {
				boxElem = getObject().findElement(By.xpath(".//select[contains(@id,'-available')]"));
				arrItems = boxElem.findElements(By.xpath(".//option"));
			} else if (className.contains("vdl-dual-select")) {
				boxElem = getObject().findElement(By.xpath(".//ul[contains(@class,'available')]"));
				arrItems = boxElem.findElements(By.xpath(".//li/span"));
			} else {
				boxElem = getObject().findElement(By.xpath(".//ul[contains(@id,'_Left') or contains(@class,'left-list')]"));
				arrItems = boxElem.findElements(By.xpath(".//li"));
			}

		} else if (p_boxSide.trim().equalsIgnoreCase("RIGHT")) {
			if (className.contains("react-dual-listbox")) {
				boxElem = getObject().findElement(By.xpath(".//select[contains(@id,'-selected')]"));
				arrItems = boxElem.findElements(By.xpath(".//option"));
			} else if (className.contains("vdl-dual-select")) {
				boxElem = getObject().findElement(By.xpath(".//ul[contains(@class,'selected')]"));
				arrItems = boxElem.findElements(By.xpath(".//li/span"));
			} else {
				boxElem = getObject().findElement(By.xpath(".//ul[contains(@id,'_Right') or contains(@class,'right-list')]"));
				arrItems = boxElem.findElements(By.xpath(".//li"));
			}
		}

		String strActual = "";
		if (arrItems.isEmpty()) {
			strActual = "[BLANK]";
		} else {
			for (WebElement dblListItem : arrItems) {
				if (!dblListItem.getAttribute("innerText").contentEquals("")) {
					strActual = strActual + ";" + dblListItem.getAttribute("innerText");
				}
			}
			strActual = strActual.substring(1);
		}
		
		return strActual;
	}
}
