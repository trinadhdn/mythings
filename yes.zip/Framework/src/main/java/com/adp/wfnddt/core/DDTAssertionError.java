/**
 * 
 */
package com.adp.wfnddt.core;

import org.assertj.core.api.Fail;

/**
 * @author Wiermanp
 *
 */
public class DDTAssertionError {
	
	public static void fail(String p_stepName, String p_description) {
		Fail.fail(p_stepName, new AssertionError(p_description));
		return;
	}

	public static void fail(String p_stepName) {
		Fail.fail(p_stepName);
		return;
	}
}
