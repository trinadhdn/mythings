package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.performTextComparison;
import static com.adp.wfnddt.commonmethods.General.sleep;
import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.pagefactory.ByAll;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.E_OSs;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebComboBox extends BaseObject {

	private WebElement m_dropDownBtn = null;
	private boolean m_bypassDropDownClick = false;

	public WebComboBox(String p_selector) {
		setSelector(p_selector);
	}

	public WebComboBox(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void select(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForClickable();

		if (p_value.contentEquals("[BLANK]")) {
			// dropdown has no blank but with clear value
			ByAll blankOption = new ByAll(By.xpath(".//SPAN[@class='Select-clear']"), By.xpath(".//*[contains(@class,'MDFSelectBox__clear-indicator')]"));
			if (getObject().findElements(blankOption).size() != 0) {
				getObject().findElement(blankOption).click();
				return;
			}

			if (getObject().findElements(By.xpath(".//INPUT[not(contains(@class,'ArrowButton') or contains(@class,'ValidationIcon') or contains(@class,'DateTimeTriggerIcon')) and (@type='text' or @type='search')]")).size() != 0) {
				getObject().findElement(By.xpath(".//INPUT[not(contains(@class,'ArrowButton') or contains(@class,'ValidationIcon') or contains(@class,'DateTimeTriggerIcon')) and (@type='text' or @type='search')]")).clear();
			}

			List<WebElement> dropdownColl = openDropDown();
			for (WebElement select : dropdownColl) {
				if (select.getText().trim().contentEquals("")) {
					select.click();
					sleep(2);
					return;
				}
			}

		} else {

			// enter value into dropdown - for infinite scroll item
//			if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
//				getObject().findElement(By.xpath(".//input")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
//				m_bypassDropDownClick = true;
//			} else if (getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__indicators')]")).size() != 0) {
//				getObject().findElement(By.xpath(".//input")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
//				m_bypassDropDownClick = true;
//			}
			if (getObject().getAttribute("class").contains("infinite")){
				getObject().findElement(By.xpath(".//input")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
				m_bypassDropDownClick = true;
			} else if(getObject().findElements(By.xpath("./parent::div[contains(@class,'infinite')]")).size() != 0) {
				getObject().findElement(By.xpath(".//input")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
				m_bypassDropDownClick = true;
			} else if (getObject().findElements(By.xpath(".//div[contains(@class,'loadingIndicator')]")).size() != 0) {
				getObject().findElement(By.xpath(".//input[@role='textbox']")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
				m_bypassDropDownClick = true;
				
			//last 2 conditions should use SetAndSelect method instead of Set.	- Pan comment out if any other impact
			//uncommented below lines as it is impacting many components in New Hire - Ashish - 11/19/2019	
			} else if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
				getObject().findElement(By.xpath(".//input")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
				m_bypassDropDownClick = true;
			} else if (getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__indicators')]")).size() != 0) {
				getObject().findElement(By.xpath(".//input")).sendKeys(p_value.replace("[PARTIAL]", "").trim());
				m_bypassDropDownClick = true;
			}

			List<WebElement> dropdownColl = openDropDown();

			for (WebElement select : dropdownColl) {
				if (p_value.contains("[PARTIAL]")) {
					if (select.getText().trim().contains(p_value.replace("[PARTIAL]", "").trim())) {
						select.click();
						sleep(1);
						return;
					}
				} else {
					if (select.getText().trim().contentEquals(p_value.trim())) {
						select.click();
						sleep(1);
						return;
					}
				}
			}
			fail("The value [" + p_value + "] is not found in the combobox");
		}
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		verifyValue(p_value, new ComparisonType[] { ComparisonType.Exact });
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();

		String expectedValue = p_value.trim();

		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		// added replace statements to handle verify in few MDF6 WebComboBox values
		String actualValue = getActualValue();
		if (getObject().findElements(By.cssSelector(".react-phone-number-input__icon-image")).size() != 0) {
			expectedValue = expectedValue + ".svg" + "[PARTIAL]";
		}
		
		// Compare
		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);

		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);

		return;
	}
	
	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		String actualValue = getObject().getText().replace("\n", "").replace("open dropdown", "").replace("×", "").trim();

		if (actualValue.contentEquals("")) {
			if (getObject().findElements(By.cssSelector("input.reactVDL.selectBox")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector("input.reactVDL.selectBox")).getAttribute("value").trim();
			} else if (getObject().findElements(By.cssSelector("input.dijitReset.dijitInputInner[role='textbox']")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector("input.dijitReset.dijitInputInner[role='textbox']")).getAttribute("value").trim();
			} else if (getObject().findElements(By.cssSelector("input")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector("input")).getAttribute("value").trim();
			} else if (getObject().findElements(By.cssSelector(".vdl-dropdown-list__input")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector(".vdl-dropdown-list__input")).getAttribute("value");
				String actualValue2 = getObject().findElement(By.cssSelector(".vdl-dropdown-list__input")).getText();
				if (actualValue == null) {
					actualValue = actualValue2;
				}
				if (actualValue.isEmpty() && !actualValue2.isEmpty()) {
					actualValue = actualValue2;
				}
				actualValue = actualValue.trim();
			} else if (getObject().findElements(By.cssSelector(".react-phone-number-input__icon-image")).size() != 0) {
				actualValue = getObject().findElement(By.cssSelector(".react-phone-number-input__icon-image")).getAttribute("src").trim();
			} else {
				actualValue = getObject().getAttribute("value").trim();
			}
		}

		// Handling [BLANK] Verification
		if (actualValue.contentEquals("")) {
			actualValue = "[BLANK]";
		}
		
		return actualValue;
	}

	public void verifyContents(String p_expectedContents, String p_contentType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_expectedContents.trim().contentEquals(""))
			return;

		String actualContents = "";
		findObject();
		waitForClickable();
		StatusType status = StatusType.FAILED;

		if (p_contentType.equalsIgnoreCase("[SET_AND_VERIFY]")) {
			for (String item : p_expectedContents.split(";")) {
				if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {

					if (DDTController.getOS().equals(E_OSs.Windows)) {
						getObject().findElement(By.xpath(".//input")).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
					} else {
						getObject().findElement(By.xpath(".//input")).sendKeys(Keys.chord(Keys.COMMAND, "a", Keys.DELETE));
					}

					getObject().findElement(By.xpath(".//input")).sendKeys(item);
					sleep(1);
				}
				m_bypassDropDownClick = true;
				List<WebElement> dropdownColl = openDropDown();
				m_bypassDropDownClick = false;
				for (WebElement select : dropdownColl) {
					if (select.getText().trim().contentEquals(item.trim())) {
						actualContents = actualContents.concat(";" + select.getAttribute("innerText").replace("empty ;", "[BLANK]").replace("empty", "[BLANK]").replace("\n", "").trim());
					}
				}
			}
			if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
				getObject().findElement(By.xpath(".//input")).sendKeys(Keys.ESCAPE);
			}
			actualContents = actualContents.substring(1);
			if (actualContents.equals(p_expectedContents)) {
				status = StatusType.PASSED;
			} else {
				status = StatusType.FAILED;
			}
			m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);

			return;
		}

		List<WebElement> dropdownColl = openDropDown();

		for (WebElement item : dropdownColl) {
			String m_itemText = item.getAttribute("innerText").trim();
			//handle first item with blank for some Combobox
			m_itemText = m_itemText.replaceAll("&"+"nbsp;", "[BLANK]");
			m_itemText = m_itemText.replaceAll(String.valueOf((char) 160), "[BLANK]");
			actualContents = actualContents.concat(";" + (m_itemText.length() == 0 ? "[BLANK]" : m_itemText.replace("empty ;", "[BLANK]").replace("empty", "[BLANK]").replace("\n", "").trim()));
		}
		actualContents = actualContents.substring(1);
		List<String> actContentsArr = Arrays.asList(actualContents.split(";"));
		List<String> expContentsArr = Arrays.asList(p_expectedContents.split(";"));

		switch (p_contentType.replaceAll("\\[|\\]", "")) {
		case "EXACT":
			if (actualContents.equals(p_expectedContents)) {
				status = StatusType.PASSED;
			} else {
				status = StatusType.FAILED;
			}
			m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);
			break;
		case "EXACT_ANY_ORDER":
			if (expContentsArr.size() == actContentsArr.size()) {
				for (String item : expContentsArr) {
					if (actContentsArr.contains(item)) {
						status = StatusType.PASSED;
					} else {
						status = StatusType.FAILED;
						break; // break out of for loop on first occurrence of a failure
					}
				}
			}
			m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);
			break;
		case "PARTIAL":
			for (String item : expContentsArr) {
				if (actContentsArr.contains(item)) {
					status = StatusType.PASSED;
				} else {
					status = StatusType.FAILED;
					break; // break out of for loop on first occurrence of a failure
				}
			}
			m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);
			break;
		case "DOES_NOT_EXIST":
			for (String item : expContentsArr) {
				if (!actContentsArr.contains(item)) {
					status = StatusType.PASSED;
				} else {
					status = StatusType.FAILED;
					break; // break out of for loop on first occurrence of a failure
				}
			}
			m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);

			break;
		default:
			fail("Unknown Type in WebComboBox verifyContents");
			break;
		}
		m_dropDownBtn.click();
		sleep(2);
		return;
	}

	private WebElement getVisibleDropdownMenu(By p_selector) throws DDTFrameworkException {
		WebElement dropdown = null;
		int iWaitTime = 0;
		do {
			List<WebElement> dropdownMenuColl = m_webdriver.findElements(p_selector);
			for (WebElement dropDownPopUp : dropdownMenuColl) {
				if (dropDownPopUp.isDisplayed()) {
					dropdown = dropDownPopUp;
					break;
				}
			}

			if (dropdown == null) {
				iWaitTime = iWaitTime + 2;
				sleep(2);
			} else {
				break;
			}
		} while (iWaitTime <= DDTController.getMaxWaitTime());

		// Return the visible dropdown
		return dropdown;
	}

	private List<WebElement> openDropDown() throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		findObject();
		waitForClickable();

		List<WebElement> dropdownColl = new ArrayList<WebElement>();

		if (getObject().findElements(By.xpath("./parent::div/parent::div/following-sibling::*//span[contains(@class,'fa fa fa-search')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath("./parent::div/parent::div/following-sibling::*//span[contains(@class,'fa fa fa-search')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("/*//div[@id='react-autowhatever-1']"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath(".//li[contains(@id,'react-autowhatever-1--')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
			// dijit controls
		} else if (getObject().findElements(By.cssSelector(".dijitInputField.dijitArrowButtonInner")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.cssSelector(".dijitInputField.dijitArrowButtonInner"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.dijitComboBoxMenu[id$='_popup']:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".dijitReset.dijitMenuItem"));
			} else {
				dropdown = getVisibleDropdownMenu(By.cssSelector("div.revitSearchListPopup[id$='_dropdown']:not([style*='display: none']"));
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.cssSelector(".dgrid-row"));
				} else {
					fail("The dropdown menu is not found !!");
				}
			}
			// JE - found a condition where the drop down arrow is not under the control but under a widget. Rare case for revit
		} else if (getObject().findElements(By.xpath("//INPUT[@id='" + getObject().getAttribute("id") + "']/ancestor::DIV[@id='widget_" + getObject().getAttribute("id") + "']//INPUT[contains(@class,'dijitInputField dijitArrowButtonInner')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath("//INPUT[@id='" + getObject().getAttribute("id") + "']/ancestor::DIV[@id='widget_" + getObject().getAttribute("id") + "']//INPUT[contains(@class,'dijitInputField dijitArrowButtonInner')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.dijitComboBoxMenu[id$='_popup']:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".dijitReset.dijitMenuItem"));
			} else {
				fail("The dropdown menu is not found !!");
			}
			// revit controls
		} else if (getObject().findElements(By.xpath("./parent::*//DIV[contains(@class,'fa-chevron-down')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath("./parent::*//DIV[contains(@class,'fa-chevron-down')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.reactVDL[id$='.dropDown_popup']:not([style*='display: none'])")));
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.reactVDL[id$='.dropDown_popup']:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".reactVDL.selectOptionOuter"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath("//BUTTON[@class='rrui__input-element rrui__select__button' and @type='button']")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath("//BUTTON[@class='rrui__input-element rrui__select__button' and @type='button']"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//ul[contains(@class,'rrui__expandable rrui__expandable--overlay rrui__select__options rrui__shadow rrui__select__options--autocomplete')]"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath("//li[@class='rrui__expandable__content rrui__select__options-list-item rrui__expandable__content--expanded rrui__select__options-list-item--expanded']"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
			// Skip clicking arrow, dropdown automatic showed after enter value into dropdown
			m_dropDownBtn = getObject().findElement(By.xpath(".//SPAN[@class='Select-arrow']"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			General.sleep(1);
			WebElement dropdown = getVisibleDropdownMenu(By.xpath(".//div[@class='Select-menu-outer']"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath(".//DIV[contains(@class,'VirtualizedSelectOption')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.cssSelector(".vdl-dropdown-list__picker")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.cssSelector(".vdl-dropdown-list__picker"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			General.sleep(1);
			// if (!m_bypassDropDownClick) new WebButton(getObject().findElement(By.cssSelector(".vdl-dropdown-list__picker"))).actionClick();
			m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.vdl-popup:not([style*='display: none'])")));
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.vdl-popup:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".vdl-list__option"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.cssSelector(".vdl-dropdown-button__icon")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.cssSelector(".vdl-dropdown-button__icon"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			General.sleep(1);
			// if (!m_bypassDropDownClick) new WebButton(getObject().findElement(By.cssSelector(".vdl-dropdown-list__picker"))).actionClick();
			m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.vdl-popup:not([style*='display: none'])")));
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.vdl-popup:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".vdl-list__option"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.cssSelector(".dijitInputField.dijitDateTimeTriggerIcon")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.cssSelector(".dijitInputField.dijitDateTimeTriggerIcon"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.dijitTimePicker[id$='_popup']:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".dijitTimePickerItem"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.cssSelector(".fa.fa-chevron-down,.fa.fa-clock-o:not([style*='display: none'])")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.cssSelector(".fa.fa-chevron-down,.fa.fa-clock-o:not([style*='display: none'])"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			m_webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.reactVDL[id$='.dropDown_popup']:not([style*='display: none'])")));
			WebElement dropdown = getVisibleDropdownMenu(By.cssSelector("div.reactVDL[id$='.dropDown_popup']:not([style*='display: none'])"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.cssSelector(".reactVDL.selectOptionOuter"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath(".//A[contains(@class,'ui-select-match')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath(".//A[contains(@class,'ui-select-match')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//div[contains(@class,'ui-select-dropdown')]"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath("//DIV[contains(@class,'ui-select-choices-row-inner')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath("./parent::*//DIV[contains(@id,'react-autowhatever')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath("./parent::div/parent::div//span[contains(@class,'fa fa-search')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath(m_selector.replace("XPATH:", "") + "/parent::*//div[contains(@id,'react-autowhatever')]"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath("//li[@role='option' and contains(@id,'react-autowhatever')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
			// Time Picker
		} else if (getObject().findElements(By.xpath(".//span[@class='vdl-date-time-picker__select']")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath(".//span[@class='vdl-date-time-picker__select']"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath(".//div[@class='vdl-timelist-popup vdl-popup']"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath(".//li[contains(@id,'time_listbox__option')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath(".//DIV[contains(@class,'rrui__select__arrow')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath(".//DIV[contains(@class,'rrui__select__arrow')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//ul[@class='rrui__expandable rrui__expandable--overlay rrui__select__options rrui__shadow rrui__select__options--autocomplete rrui__expandable--expanded rrui__select__options--expanded rrui__expandable--left-aligned rrui__select__options--left-aligned rrui__select__options--downward']"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath("//li[@class='rrui__expandable__content rrui__select__options-list-item rrui__expandable__content--expanded rrui__select__options-list-item--expanded']"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath(".//span[contains(@class,'rrui__select__arrow')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath(".//span[contains(@class,'rrui__select__arrow')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//div[contains(@class,'rrui__expandable--downward')]"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath("//li[contains(@class,'list-item')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		} else if (getObject().findElements(By.xpath(".//DIV[contains(@class,'dropdown-indicator')]")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath(".//DIV[contains(@class,'dropdown-indicator')]"));
			if (!m_bypassDropDownClick)
				m_dropDownBtn.click();
				General.sleep(3);
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//div[contains(@class,'MDFSelectBox__menu-list')]"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__option')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}
		}
		// new employee search combobox
		else if (getObject().findElements(By.xpath("//DIV[contains(@class,'employee-search-bar-employee-list')]")).size() != 0) {
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//DIV[contains(@class,'employee-search-bar-employee-list')]"));
			dropdownColl = dropdown.findElements(By.xpath(".//DIV[@class='employee-search-bar-employee']"));
		}
		// val table combobox
		else if (getObject().findElements(By.xpath("//div[contains(@class,'search') and contains(@class,'option') and contains(@class,'list')]")).size() != 0) {
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//div[contains(@class,'search') and contains(@class,'option') and contains(@class,'list')]"));
			dropdownColl = dropdown.findElements(By.xpath(".//div[contains(@class,'search') and contains(@class,'option') and contains(@class,'row')]/span"));
		}

		else if (getObject().findElements(By.xpath("//*[@id='" + getObject().getAttribute("id") + "_popup']")).size() != 0) {
			WebElement dropdown = getVisibleDropdownMenu(By.xpath("//*[@id='" + getObject().getAttribute("id") + "_popup']"));
			dropdownColl = dropdown.findElements(By.cssSelector(".dijitReset.dijitMenuItem"));
		}
		// combobox with select node
		else if (getObject().getTagName().contains("select")) {
			getObject().click();
			General.sleep(1);
			dropdownColl = getObject().findElements(By.xpath("./option"));
		}
		else {
			//default just click on object
			getObject().click();
		}


		return dropdownColl;
	}

	public void verifyObjectProperties(String p_property) throws DDTFrameworkException, DatatypeConfigurationException, IOException {
		if (exists()) {
			if (getObject().findElements(By.cssSelector("input.reactVDL.selectBox")).size() != 0 && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled, getObject().findElement(By.cssSelector("input.reactVDL.selectBox")));
			} else if (getObject().getAttribute("class").contains("dijitTextBox dijitComboBox") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled);
			} else if (getObject().getAttribute("class").contains("Select") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled);
			} else if (getObject().getAttribute("class").contains("vdl-dropdown") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled);
			} // Due to MDF change(V20) added is disabled
			else if (getObject().getAttribute("class").contains("is-disabled") && (p_property.equalsIgnoreCase("[DISABLED]") || p_property.equalsIgnoreCase("[ENABLED]"))) {
				verifyObjectProperties(p_property, VerifyPropertyType.DISABLED_classDisabled);
			} else {
				super.verifyObjectProperties(p_property);
			}
		} else {
			super.verifyObjectProperties(p_property);
		}
	}

	private void set(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
			getObject().click();
			actionsClearText();
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.xpath(".//input[@role='textbox']")).sendKeys(p_value);
		} else if (getObject().findElements(By.xpath(".//input[@role='textbox']")).size() != 0) {
			getObject().findElement(By.xpath(".//input[@role='textbox']")).click();
			// actionsClearText();
			General.sleep(2);
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.xpath(".//input[@role='textbox']")).sendKeys(p_value);
		} else if (getObject().findElements(By.xpath(".//input")).size() != 0) {
			getObject().click();
			if (getObject().findElements(By.xpath(".//*[contains(@class,'clear-indicator')]")).size() != 0){
				getObject().findElement(By.xpath(".//*[contains(@class,'clear-indicator')]")).click();
			}
			General.sleep(1);
//			getObject().findElement(By.xpath(".//input")).click();
//			General.sleep(2);
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.xpath(".//input")).sendKeys(p_value);
		} else {
			getObject().clear();
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().sendKeys(p_value);
		}
		return;
	}

	public void setAndSelect(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForClickable();

		set(p_value);
		General.sleep(2);
		actionClick();
		m_bypassDropDownClick = true;
		List<WebElement> dropdownColl = openDropDown();

		for (WebElement select : dropdownColl) {
			if (select.getText().trim().contentEquals(p_value.trim())) {
				select.click();
				sleep(2);
				return;
			}
		}
		fail("The value [" + p_value + "] is not found in the combobox");
		return;
	}

	public void setAndSelect(String p_value, String p_setValue) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;
		// setValue is partial text in case the field does not take spaces or other issues
		findObject();
		waitForClickable();

		set(p_setValue);
		General.sleep(2);
		//actionClick();
		m_bypassDropDownClick = true;
		List<WebElement> dropdownColl = openDropDown();

		for (WebElement select : dropdownColl) {
			if (select.getText().trim().contains(p_value.trim())) {
				select.click();
				sleep(2);
				return;
			}
		}
		fail("The value [" + p_value + "] is not found in the combobox");
		return;
	}

	public String GetValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String m_CurrentValue = "";
		findObject();

		// Return if not displayed
		if (!getObject().isDisplayed()) {
			return m_CurrentValue;
		}

		if (getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__value')]")).size() != 0) {
			m_CurrentValue = getObject().getText().trim();
		} else if (getObject().findElements(By.cssSelector("input.reactVDL.selectBox")).size() != 0) {
			m_CurrentValue = getObject().findElement(By.cssSelector("input.reactVDL.selectBox")).getAttribute("value").trim();
		} else if (getObject().findElements(By.cssSelector("div.Select-value")).size() != 0) {
			m_CurrentValue = getObject().findElement(By.cssSelector("div.Select-value")).getText().trim();
		} else if (getObject().findElements(By.cssSelector("input.dijitReset.dijitInputInner[role='textbox']")).size() != 0) {
			m_CurrentValue = getObject().findElement(By.cssSelector("input.dijitReset.dijitInputInner[role='textbox']")).getAttribute("value").trim();
		} else if (getObject().findElements(By.cssSelector("vdl-dropdown-list__input")).size() != 0) {
			m_CurrentValue = getObject().findElement(By.cssSelector("vdl-dropdown-list__input")).getAttribute("value").trim();
		} else if (getObject().findElements(By.cssSelector("input")).size() != 0) {
			m_CurrentValue = getObject().findElement(By.cssSelector("input")).getAttribute("value").trim();
		} else {
			m_CurrentValue = getObject().getAttribute("value").trim();
		}

		// added replace statements to handle verify in few MDF6 WebComboBox values
		m_CurrentValue = m_CurrentValue.replace("\n", "").replace("open dropdown", "").trim();

		return m_CurrentValue;
	}

}
