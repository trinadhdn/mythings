package com.adp.wfnddt.parammanager;

import static com.adp.wfnddt.commonmethods.General.replaceParameterKeyWords;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.adp.wfnddt.core.DDTFrameworkException;

public class ParamManager {
	private HashMap<String, String> paramMap = new LinkedHashMap<>();
	private HashMap<String, String> runTimeParamMap = new LinkedHashMap<>();
	private boolean runTimeMap = false;

	private int p_currentIteration = 0;

	public ParamManager(List<List<String>> p_parameters, int p_iteration) throws DDTFrameworkException, IOException, DatatypeConfigurationException, ParseException {

		p_currentIteration = p_iteration;
		for (List<String> param : p_parameters) {
			String paramName = param.get(0).toString().trim();
			String paramValue = param.get(p_iteration + 1).toString().trim();
			paramValue = replaceParameterKeyWords(paramValue);
			//need additional keyword conversion
			paramValue = replaceParameterKeyWords(paramValue);
			paramMap.put(paramName.toUpperCase() , paramValue);
			runTimeParamMap.put(paramName.toUpperCase(), paramValue);
		}
		return;
	}

	public HashMap<String, String> getParamMap() {
		if (!runTimeMap) {
			return paramMap;
		} else {
			return runTimeParamMap;
		}
	}

	public String Parameter(String p_paramName) {
		if (!runTimeMap) {
			if (paramMap.containsKey(p_paramName.toUpperCase())) {
				return paramMap.get(p_paramName.toUpperCase());
			} else {
				return "";
			}
		} else {
			if (runTimeParamMap.containsKey(p_paramName.toUpperCase())) {
				return runTimeParamMap.get(p_paramName.toUpperCase());
			} else {
				return "";
			}
		}
	}

	public int getCurrentIteration() {
		return p_currentIteration;
	}

	public void deleteParameter(String p_paramName) {
		if (runTimeParamMap.containsKey(p_paramName.toUpperCase())) {
			runTimeParamMap.remove(p_paramName.toUpperCase());
		}
	}

	public void setParameter(String p_paramName, String p_paramValue) {
		runTimeParamMap.put(p_paramName.toUpperCase(), p_paramValue);
	}

	public void setRunTimeMap(boolean p_runTimeMap) {
		runTimeMap = p_runTimeMap;
	}

	public void resetRunTimeMap() {
		runTimeParamMap = paramMap;
	}
	
	public void clearRunTimeMap() {
		runTimeParamMap.clear();
	}

}
