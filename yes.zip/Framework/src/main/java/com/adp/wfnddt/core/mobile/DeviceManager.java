/**
 * 
 */
package com.adp.wfnddt.core.mobile;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpClient.Factory;
import org.openqa.selenium.remote.internal.OkHttpClient;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTController.Mobile_OSName;
import com.adp.wfnddt.core.DDTFrameworkException;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileCommand;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileBrowserType;
import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.OkHttpClient.Builder;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;

/**
 * @author autoxpert
 *
 */
public class DeviceManager {
	private static AppiumDriver<WebElement> driver;
	private static String AppiumServer;

	// Proxy host/port and authentication
	private static final String proxy_host = "11.164.4.21";
	private static final String proxy_port = "8080";
	private static final String proxy_user = "autoxpert";
	private static final String proxy_password = "adpadp";

	// Android Emulators
	private static String Appium_AndoirdEmulator = "http://hyrdwsz0057:4723/wd/hub";

	// Experitest Demo Cloud
	private static boolean isExperitest = DDTController.getAppiumRemoteURL().contains("experitest") || DDTController.getAppiumRemoteURL().contains("10.223.21.246");
	private static String Appium_ExperitestDemoCloud = DDTController.getAppiumRemoteURL();
	private static String Experitest_AccessKey = "eyJ4cC51Ijo2LCJ4cC5wIjoyLCJ4cC5tIjoiTVRVME56Y3dOekl4TlRnek53IiwiYWxnIjoiSFMyNTYifQ.eyJleHAiOjE4NjMwNjcyMTYsImlzcyI6ImNvbS5leHBlcml0ZXN0In0.TwAwE9IPg-PXy0fxyxGOzlpNuCN2JG3TYHWc5Cqks08";

	public static AppiumDriver<WebElement> setupAppiumDriver() throws DDTFrameworkException, MalformedURLException {
		long lMaxWait = DDTController.getMaxWaitTime();

		System.getProperties().put("http.proxyHost", proxy_host);
		System.getProperties().put("http.proxyPort", proxy_port);
		System.getProperties().put("https.proxyHost", proxy_host);
		System.getProperties().put("https.proxyPort", proxy_port);

		System.getProperties().put("http.proxyUser", proxy_user);
		System.getProperties().put("http.proxyPassword", proxy_password);
		System.getProperties().put("https.proxyUser", proxy_user);
		System.getProperties().put("https.proxyPassword", proxy_password);

		// Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();

		switch (DDTController.getMobileDeviceConfig()) {
		case "Pixel-Nougat":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5554");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "7.1.1");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "Nexus-Oreo":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5556");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "8.0.0");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "Nexus-P":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5558");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "P");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "NexusTab-Oreo":
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5560");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "8.0.0");
			caps.setCapability("newCommandTimeout", 300);

			AppiumServer = Appium_AndoirdEmulator;
			break;

		case "Experitest-Galaxy S8":
			caps.setCapability("testName", "Experitest Demo - Galaxy S8");
			caps.setCapability("accessKey", Experitest_AccessKey);
			caps.setCapability("deviceQuery", "@os='android' and @category='PHONE' and @model='SM-G950F'");
			caps.setCapability("newCommandTimeout", 300);

			DDTController.setMobileOSName(Mobile_OSName.Android);
			AppiumServer = Appium_ExperitestDemoCloud;
			lMaxWait = 150;
			break;

		case "Experitest-Galaxy S7":
			caps.setCapability("testName", "Experitest Demo - Galaxy S7");
			caps.setCapability("accessKey", Experitest_AccessKey);
			caps.setCapability("deviceQuery", "@os='android' and @category='PHONE' and @model='SM-G930F'");
			caps.setCapability("newCommandTimeout", 300);

			DDTController.setMobileOSName(Mobile_OSName.Android);
			AppiumServer = Appium_ExperitestDemoCloud;
			lMaxWait = 150;
			break;
			
		case "Experitest-iPad 4":
			caps.setCapability("testName", "Experitest Demo - iPad 4");
			caps.setCapability("accessKey", Experitest_AccessKey);
			caps.setCapability("deviceQuery", "@os='ios' and @category='TABLET'");
			caps.setCapability("newCommandTimeout", 300);

			DDTController.setMobileOSName(Mobile_OSName.iOS);
			AppiumServer = Appium_ExperitestDemoCloud;
			lMaxWait = 150;
			break;

		case "AWS-iPhone":
			caps.setCapability("testName", "AWS Demo - Samsung Galaxy");
			break;

		default:
			caps.setCapability("deviceName", "ADP Mobile");
			caps.setCapability("udid", "emulator-5556");
			caps.setCapability("platformName", DDTController.getMobileOSName().toString());
			caps.setCapability("platformVersion", "7.1.1");
			caps.setCapability("newCommandTimeout", 300);

			break;
		}

		switch (DDTController.getMobileAccessType()) {
		case ADPMobileApp:
			switch (DDTController.getMobileOSName()) {
			case Android:
				caps.setCapability("appPackage", "com.adpmobile.android");
				caps.setCapability("appActivity", "com.adpmobile.android.ui.AuthAppActivity");
				caps.setCapability("noReset", "true");
				break;
			case iOS:
				caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "com.adp.es.mobile.prod.enterprise");
				break;
			}
			break;
		case Browser:
			if (!isExperitest) {
				caps.setCapability("browserName", DDTController.getMobileBrowserType().toString());
			} else {
				switch (DDTController.getMobileDeviceConfig()) {
				case "Experitest-Galaxy S7":
				case "Experitest-Galaxy S8":
					caps.setBrowserName(MobileBrowserType.CHROME);
					break;

				case "Experitest-iPad 4":
					caps.setBrowserName(MobileBrowserType.SAFARI);
					break;
				}
			}

			break;
		}

		// Instantiate Appium Driver
		if (DDTController.getMobileOSName() == Mobile_OSName.Android) {
			if (isExperitest) {
				driver = new AndroidDriver<WebElement>(getProxyHTTPExecutor(new URL(AppiumServer), false), caps);
			} else {
				driver = new AndroidDriver<WebElement>(new URL(AppiumServer), caps);
			}
		} else if (DDTController.getMobileOSName() == Mobile_OSName.iOS) {
			if (isExperitest) {
				driver = new IOSDriver<WebElement>(getProxyHTTPExecutor(new URL(AppiumServer), false), caps);
			} else {
				driver = new IOSDriver<WebElement>(new URL(AppiumServer), caps);
			}
		}

		DDTController.setWebDriver(driver, lMaxWait);
		DDTController.setMobileDriver(driver, lMaxWait);

		return driver;
	}

	public static void closeApp() {

		if (DDTController.getMobileDriver() != null) {
			DDTController.getMobileDriver().closeApp();
			DDTController.getMobileDriver().quit();
			
			DDTController.setMobileDriver(null, 0);
		}
		
		if (DDTController.getWebDriver() != null) {
			DDTController.getWebDriver().quit();
			DDTController.setWebDriver(null, 0);
		}

		return;
	}
	
	public static HttpCommandExecutor getProxyHTTPExecutor(URL url, boolean useProxy) {

		okhttp3.OkHttpClient.Builder builder = new Builder();
		if(useProxy){
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxy_host, Integer.parseInt(proxy_port)));
	
			Authenticator proxyAuthenticator = new Authenticator() {
				@Override
				public Request authenticate(Route route, Response response) throws IOException {
					String credential = Credentials.basic(proxy_user, proxy_password);
					return response.request().newBuilder().header("Proxy-Authorization", credential).build();
				}
			};
	
			builder.proxy(proxy);
			builder.proxyAuthenticator(proxyAuthenticator);
		}
		builder.connectTimeout(300, TimeUnit.SECONDS);
		builder.readTimeout(300, TimeUnit.SECONDS);
		builder.hostnameVerifier(new HostnameVerifier() {
	        @Override
	        public boolean verify(String hostname, SSLSession session) {
	            return true;
	        }
	    });

		Factory factory = new Factory() {
			@Override
			public HttpClient createClient(URL url) {
				
				return new OkHttpClient(builder.build(), url);
			}

			@Override
			public void cleanupIdleClients() {
				// TODO Auto-generated method stub
			}
		};

		HttpCommandExecutor executor = new HttpCommandExecutor(MobileCommand.commandRepository, url, factory);
		return executor;
	}

	/*
	public static HttpCommandExecutor getProxyHTTPExecutor(URL url) {

		HttpClientBuilder builder = HttpClientBuilder.create();
		HttpHost proxy = new HttpHost(proxy_host, Integer.parseInt(proxy_port));
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(proxy_host, Integer.parseInt(proxy_port)),
				new UsernamePasswordCredentials(proxy_user, proxy_password));

		builder.setProxy(proxy);
		builder.setDefaultCredentialsProvider(credsProvider);

		Factory factory = new Factory() {
			@Override
			public HttpClient createClient(URL url) {
				return new ApacheHttpClient(builder.build(), url);
			}

			@Override
			public void cleanupIdleClients() {
				// TODO Auto-generated method stub

			}
		};

		HttpCommandExecutor executor = new HttpCommandExecutor(MobileCommand.commandRepository, url, factory);
		return executor;
	}
	*/
	
}
