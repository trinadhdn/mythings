package com.adp.wfnddt.objectmanager;

import static com.adp.wfnddt.commonmethods.General.sleep;
import static org.assertj.core.api.Assertions.fail;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.adp.wfnddt.aspects.Step;
import com.adp.wfnddt.commonmethods.General.ComparisonType;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.objectmanager.DefaultMethod.TypeOfMethod;
import com.adp.wfnddt.results.jaxb.StatusType;

public class WebComboMultiSelect extends BaseObject {

	private WebElement m_inputBox = null;
	private WebElement m_dropDownBtn = null;
	private WebElement m_clearAllBtn = null;
	//private String m_expectedValue = null;

	public WebComboMultiSelect(String p_selector) {
		setSelector(p_selector);
	}

	public WebComboMultiSelect(WebElement p_object) {
		setObject(p_object);
	}

	@Step(Params = { "Value", "Action" })
	@DefaultMethod(MethodType = TypeOfMethod.Action)
	public void select(String p_value, String p_action) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

		if (p_value.trim().contentEquals(""))
			return;
		if (p_value.trim().contains(";")) {
			String[] sMultiVal = p_value.split(";");
			for (int iMul = 0; iMul <= sMultiVal.length - 1; iMul++) {
				selectItem(sMultiVal[iMul], p_action);
			}
		} else {
			selectItem(p_value, p_action);
		}

	}

	private void selectItem(String p_value, String p_action) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		boolean bitemFound = false;
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		waitForClickable();

		List<WebElement> dropdownColl = new ArrayList<WebElement>();
		// dijit controls
		if (p_action.contentEquals("ADD")) {
			if (getObject().findElements(By.cssSelector("input.dijitReset.dijitInputInner.revolutionNoMsClearReveal")).size() != 0) {
				m_inputBox = getObject().findElement(By.cssSelector("input.dijitReset.dijitInputInner.revolutionNoMsClearReveal"));
				m_inputBox.click();
				WebElement dropdown = getVisibleDropdownMenu(By.xpath(".//div[contains(@id,'_ITEMNODE')][1]/parent::div/parent::div[not(contains (@style,'display: none'))]"));
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.xpath(".//child::span[contains(@id,'_ITEMLABELNODE')]"));
				} else {
					fail("The dropdown menu is not found !!");
				}
				for (WebElement select : dropdownColl) {
					if (select.getText().trim().contentEquals(p_value.trim())) {
						select.click();
						sleep(2);
						return;
					}
				}

			} else if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
				m_inputBox = getObject().findElement(By.xpath(".//SPAN[@class='Select-arrow']")); // Satya
																									// -
																									// added
																									// .
																									// in
																									// xpath
																									// to
																									// get
																									// the
																									// immediate
																									// child
				m_inputBox.click();
				WebElement dropdown = getVisibleDropdownMenu(By.xpath(".//div[@class='Select-menu-outer']")); // Satya
																												// -
																												// added
																												// .
																												// in
																												// xpath
																												// to
																												// get
																												// the
																												// immediate
																												// child
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.xpath(".//DIV[contains(@class,'VirtualizedSelectOption')]"));
				} else {
					fail("The dropdown menu is not found !!");
				}
				for (WebElement select : dropdownColl) {
					if (select.getText().trim().contentEquals(p_value.trim())) {
						select.click();
						sleep(2);
						return;
					}
				}
				// Handle new MDF Select Box
			} else if (getObject().findElements(By.xpath(".//div[contains(@class,'dropdown-indicator')]")).size() != 0) {
				m_inputBox = getObject().findElement(By.xpath(".//div[contains(@class,'dropdown-indicator')]"));
				m_inputBox.click();
				WebElement dropdown = getVisibleDropdownMenu(By.xpath("//div[contains(@class,'MDFSelectBox__menu-list')]"));
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__option')]"));
				} else {
					fail("The dropdown menu is not found !!");
				}
				for (WebElement select : dropdownColl) {
					if (p_value.contains("[PARTIAL]")) {
						if (select.getText().trim().contains(p_value.replace("[PARTIAL]", "").trim())) {
							select.click();
							sleep(2);
							return;
						}
					} else {
						if (select.getText().trim().contentEquals(p_value.trim())) {
							select.click();
							sleep(2);
							return;
						}
					}
				}

			} else if (getObject().findElements(By.xpath(".//DIV[@id='RecDashboardTabs_RecDashboardSelectedTabView_RecRequisitionFilter.LocationsList.root']")).size() != 0) {
				WebElement dropdown = getVisibleDropdownMenu(By.xpath(".//DIV[@id='RecDashboardTabs_RecDashboardSelectedTabView_RecRequisitionFilter.LocationsList.root']"));
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.xpath(".//DIV[contains(@id,'RecRequisitionFilter_Location')]"));
				} else {
					fail("The dropdown menu is not found !!");
				}
				for (WebElement select : dropdownColl) {
					if (select.getText().trim().contentEquals(p_value.trim())) {
						select.click();
						sleep(2);
						return;
					}
				}
				// MDF6 multi-select combobox
			} else if (getObject().findElements(By.xpath(".//li[contains(@class,'listboxitem-container')]")).size() != 0) {
				if (p_value.equalsIgnoreCase("SELECTALL")) {
					if (getObject().findElements(By.xpath(".//SPAN[text()='Select All']/..")).size() != 0) {
						getObject().findElement(By.xpath(".//SPAN[text()='Select All']/..")).click();
						return;
					}
				}
				dropdownColl = getObject().findElements(By.xpath(".//li[contains(@class,'listboxitem-container')]"));
				for (WebElement select : dropdownColl) {
					for (String item : p_value.split(";")) {
						if (select.findElement(By.xpath(".//span[@class='listboxitem-value']")).getText().trim().contentEquals(item.trim())) {
							bitemFound = true;
							if (select.findElements(By.xpath(".//i[@class='fa fa-plus-circle']")).size() > 0) {
								select.click();
								sleep(2);
							}

						}
					}

				}

				if (bitemFound)
					return;
				// older version of multi-select combobox
			} else if (getObject().findElements(By.xpath(".//*[contains(@class,'selectMultiSelections')]")).size() != 0) {
				for (String item : p_value.split(";")) {
					getObject().findElement(By.xpath(".//*[contains(@class,'fa-chevron-dow')]")).click();
					dropdownColl = getObject().findElements(By.xpath("//*[contains(@class,'selectOptionInner')]"));
					for (WebElement select : dropdownColl) {
						if (select.getText().trim().contentEquals(item)) {
							bitemFound = true;
							select.click();
							sleep(1);
							break;
						}
					}

				}
				if (bitemFound)
					return;
			}

			fail("The value [" + p_value + "] is not found in the combobox");
			return;
		} else if (p_action.contentEquals("REMOVE")) {
			if (getObject().findElements(By.xpath(".//div[contains(@id,'_BOXROOT')][1]/parent::div[not(contains (@style,'display: none'))]//child::span[@class='fa fa-times-circle']/ancestor::div[contains(@id,'_BOXROOT')]")).size() != 0) {
				WebElement dropdown = getVisibleDropdownMenu(By.xpath("//div[contains(@id,'_BOXROOT')][1]/ancestor::div[not(contains (@style,'display: none')) and contains(@id,'.root')][1]"));
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.xpath(".//div[contains(@id,'_BOXROOT')]/div/div"));
				} else {
					fail("The dropdown menu is not found !!");
				}
				for (WebElement select : dropdownColl) {
					if (select.getText().trim().contentEquals(p_value.trim())) {
						select.findElement(By.xpath(".//parent::div/span[@class='fa fa-times-circle']")).click();
						sleep(2);
						return;
					}
				}

			} else if (getObject().findElements(By.xpath(".//SPAN[@class='Select-value-label']")).size() != 0) {
				if (p_value.toUpperCase().contentEquals("CLEARALL")) {
					m_clearAllBtn = getObject().findElement(By.xpath(".//SPAN[@class='Select-clear']"));
					if (m_clearAllBtn != null) {
						m_clearAllBtn.click();
						return;
					}

				} else {
					dropdownColl = getObject().findElements(By.xpath(".//SPAN[@class='Select-value-label']"));

					for (WebElement select : dropdownColl) {
						if (select.getText().trim().contentEquals(p_value.trim())) {
							select.findElement(By.xpath(".//parent::div/span[@class='Select-value-icon']")).click();
							sleep(2);
							return;
						}
					}
				}
				// New MDF Select Box
			} else if (getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__multi-value__label')]")).size() != 0) {
				if (p_value.toUpperCase().contentEquals("CLEARALL")) {
					m_clearAllBtn = getObject().findElement(By.xpath(".//div[contains(@class,'MDFSelectBox__clear-indicator')]"));
					if (m_clearAllBtn != null) {
						m_clearAllBtn.click();
						return;
					}

				} else {
					dropdownColl = getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__multi-value__label')]"));

					for (WebElement select : dropdownColl) {
						if (select.getText().trim().contentEquals(p_value.trim())) {
							select.findElement(By.xpath(".//parent::div/div[contains(@class,'MDFSelectBox__multi-value__remove')]")).click();
							sleep(2);
							return;
						}
					}
				}

				// MDF6
			} else if (getObject().findElements(By.xpath(".//li[@class='listboxitem-container listboxitem-container-selected']")).size() != 0) {
				dropdownColl = getObject().findElements(By.xpath(".//li[@class='listboxitem-container listboxitem-container-selected']"));
				for (WebElement select : dropdownColl) {
					if (p_value.equalsIgnoreCase("REMOVEALL")) {
						select.click();
						sleep(1);
						bitemFound = true;
					} else {

						for (String item : p_value.split(";")) {
							if (select.findElement(By.xpath(".//span[@class='listboxitem-value']")).getText().trim().contentEquals(item.trim())) {
								select.click();
								sleep(2);
								bitemFound = true;
							}

						}
					}

				}

				if (bitemFound)
					return;
				// older UI
			} else if (getObject().findElements(By.xpath(".//*[contains(@class,'selectMultiSelections')]")).size() != 0) {
				for (String item : p_value.split(";")) {
					bitemFound = false;
					dropdownColl = getObject().findElements(By.xpath(".//*[contains(@class,'multiSelectChosenOuter')]"));
					for (WebElement select : dropdownColl) {
						if (select.getText().trim().contentEquals(item)) {
							bitemFound = true;
							select.findElement(By.xpath(".//span[@class='fa fa-times-circle']")).click();
							sleep(1);
							break;
						}
					}
					if (!bitemFound)
						fail("The value [" + p_value + "] is not found in the combobox");

				}
				if (bitemFound)
					return;
			} //LATEST 
			else if (getObject().findElements(By.xpath(".//div[contains(@class,'SelectBox__value-container')]")).size() != 0) {
					dropdownColl = getObject().findElements(By.xpath(".//div[contains(@class,'SelectBox__multi-value__label')]"));
					for (WebElement select : dropdownColl) {
						if (select.getText().trim().contentEquals(p_value.trim())) {
							select.findElement(By.xpath(".//parent::div/div[contains(@class,'SelectBox__multi-value__remove')]")).click();
							sleep(2);
							return;
						}
					}

			}

		}
		fail("The value [" + p_value + "] is not found in the combobox");
		return;
	}

	@DefaultMethod(MethodType = TypeOfMethod.Verification)
	public void verifyValue(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {

//		if (p_value.trim().contentEquals(""))
//			return;
//		if (p_value.trim().contains(";")) {
//			String[] sMultiVal = p_value.split(";");
//			for (int iMul = 0; iMul <= sMultiVal.length - 1; iMul++) {
//				verifyItem(sMultiVal[iMul], new ComparisonType[] { ComparisonType.Exact });
//			}
//		} else {
//			verifyItem(p_value, new ComparisonType[] { ComparisonType.Exact });
//		}
		verifyValue(p_value,new ComparisonType[]{ComparisonType.Exact}); //JE - removed redundancy
		return;
	}

	public void verifyValue(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;
//		if (p_value.trim().contains(";") && !p_comparisonTypes[0].equals(ComparisonType.Exact)) { //Only split if comparison is not Exact
//			String[] sMultiVal = p_value.split(";");
//			for (int iMul = 0; iMul <= sMultiVal.length - 1; iMul++) {
//				verifyItem(sMultiVal[iMul], p_comparisonTypes);
//			}
//		} else {
//			verifyItem(p_value, p_comparisonTypes);
//		} //commented to fix issue with Exact Comparison - Ashish
		verifyItem(p_value, p_comparisonTypes);
		return;
	}

	public void verifyItem(String p_value, ComparisonType[] p_comparisonTypes) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		StatusType status = StatusType.FAILED;
		String expectedValue = p_value.trim();
		//m_expectedValue = expectedValue;
		
		// Return if not displayed
		if (!getObject().isDisplayed()) {
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", StatusType.FAILED, expectedValue, "[OBJECT_NOT_VISIBLE]");
			return;
		}

		String actualValue = getActualValue();
		if (p_comparisonTypes[0].equals(ComparisonType.Exact)) {			
			if (actualValue.contentEquals(expectedValue)) {
				status = StatusType.PASSED;
			} else {
				status = StatusType.FAILED;
			}
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);
		} else {
			List<String> actContentsArr = Arrays.asList(actualValue.split(";"));
			List<String> expContentsArr = Arrays.asList(expectedValue.split(";"));
//			if (expContentsArr.size() == actContentsArr.size()) {
				for (String item : expContentsArr) {
					if (actContentsArr.contains(item)) {
						status = StatusType.PASSED;
					} else {
						status = StatusType.FAILED;
						break; // break out of for loop on first occurrence of a failure
					}
				}
//			}
			m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);
			
		}
		// Compare
//		StatusType status = performTextComparison(expectedValue, actualValue, p_comparisonTypes);
//		m_results.addEntryToVerificationLog("Verify value for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, expectedValue, actualValue);
		return;
	}
	
	public String getActualValue() throws IOException, DatatypeConfigurationException, DDTFrameworkException{
		List<WebElement> dropdownColl = new ArrayList<WebElement>();
		String actualValue = null;

		if (getObject().findElements(By.xpath(".//SPAN[@class='Select-value-label']")).size() != 0) {
			dropdownColl = getObject().findElements(By.xpath(".//SPAN[@class='Select-value-label']"));
			if (dropdownColl.size() > 0) {
				for (WebElement select : dropdownColl) {
//					if (m_expectedValue != null) {
//						if (select.getText().trim().contentEquals(m_expectedValue)) {
//							actualValue = actualValue + ";" + select.getText().trim();
//						}
//					} else {
//						actualValue = actualValue + ";" + select.getText().trim();
//					}
					actualValue = actualValue + ";" + select.getText().trim();
				}
				
				actualValue = actualValue.replace("null;", "");
			} else {
				actualValue = "[BLANK]";
			}
			// New MDF
		} else if (getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__multi-value__label')]")).size() != 0) {
			dropdownColl = getObject().findElements(By.xpath(".//div[contains(@class,'MDFSelectBox__multi-value__label')]"));
			if (dropdownColl.size() > 0) {
				for (WebElement select : dropdownColl) {
//					if (m_expectedValue != null) {
//						if (select.getText().trim().contentEquals(m_expectedValue)) {
//							actualValue = actualValue + ";" + select.getText().trim();
//						}
//					} else {
//						actualValue = actualValue + ";" + select.getText().trim();
//					}
					actualValue = actualValue + ";" + select.getText().trim();
				}
				actualValue = actualValue.replace("null;", "");
			} else {
				actualValue = "[BLANK]";
			}

			// MDF6
		} else if (getObject().findElements(By.xpath(".//li[@class='listboxitem-container listboxitem-container-selected']")).size() != 0) {
			dropdownColl = getObject().findElements(By.xpath(".//li[@class='listboxitem-container listboxitem-container-selected']"));
			for (WebElement select : dropdownColl) {
				actualValue = actualValue + ";" + select.findElement(By.xpath(".//span[@class='listboxitem-value']")).getText().trim();
			}
			actualValue = actualValue.replace("null;", "");
			// oder UI
		} else if (getObject().findElements(By.xpath(".//*[contains(@class,'selectMultiSelections')]")).size() != 0) {
			dropdownColl = getObject().findElements(By.xpath(".//*[contains(@class,'multiSelectChosenOuter')]"));
			if (dropdownColl.size() > 0) {
				for (WebElement select : dropdownColl) {
					actualValue = actualValue + ";" + select.getText().trim();
				}
				actualValue = actualValue.replace("null;", "");
			} else {
				actualValue = "[BLANK]";
			}
		} else {
			actualValue = "[BLANK]";
		}
		
		return actualValue;
	}

	public void verifyContents(String p_expectedContents, String p_contentType) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_expectedContents.trim().contentEquals(""))
			return;

		String actualContents = "";
		findObject();
		waitForClickable();

		List<WebElement> dropdownColl = null;
		if (getObject().findElements(By.xpath(".//SPAN[@class='Select-arrow']")).size() != 0) {
			m_dropDownBtn = getObject().findElement(By.xpath(".//SPAN[@class='Select-arrow']"));
			m_dropDownBtn.click();
			WebElement dropdown = getVisibleDropdownMenu(By.xpath(".//div[@class='Select-menu-outer']"));
			if (dropdown != null) {
				dropdownColl = dropdown.findElements(By.xpath(".//DIV[contains(@class,'VirtualizedSelectOption')]"));
			} else {
				fail("The dropdown menu is not found !!");
			}

			for (WebElement item : dropdownColl) {
				actualContents = actualContents.concat(";" + item.getAttribute("innerText").replace("empty ;", "[BLANK]").replace("\n", "").trim());
			}
			actualContents = actualContents.substring(1);

			StatusType status = StatusType.FAILED;
			switch (p_contentType.replaceAll("\\[|\\]", "")) { // Satya -
																// modified to
																// handle
																// parenthesis
			case "EXACT":
				if (actualContents.equals(p_expectedContents)) {
					status = StatusType.PASSED;
				} else {
					status = StatusType.FAILED;
				}
				m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);
				break;
			case "EXACT_ANY_ORDER":
				for (String item : p_expectedContents.split(";")) {
					if (actualContents.indexOf(item) != -1) {
						status = StatusType.PASSED;
					} else {
						status = StatusType.FAILED;
						break; // break out of for loop on first occurrence of a
								// failure
					}
				}
				if (p_expectedContents.split(";").length != dropdownColl.size()) {
					status = StatusType.FAILED;
				}
				m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);
				break;
			case "PARTIAL":
				for (String item : p_expectedContents.split(";")) {
					if (actualContents.indexOf(item) != -1) {
						status = StatusType.PASSED;
					} else {
						status = StatusType.FAILED;
						break; // break out of for loop on first occurrence of a
								// failure
					}
				}
				m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);
				break;
			case "DOES_NOT_EXIST":
				for (String item : p_expectedContents.split(";")) {
					if (actualContents.indexOf(item) == -1) {
						status = StatusType.PASSED;
					} else {
						status = StatusType.FAILED;
						break; // break out of for loop on first occurrence of a
								// failure
					}
				}
				m_results.addEntryToVerificationLog("Verify WebComboBox contents (" + p_contentType.toString() + ") for : " + getClass().getSimpleName() + "(\"" + m_objectName + "\")", status, p_expectedContents, actualContents);

				break;
			default:
				fail("Unknown Type in WebComboBox verifyContents");
				break;
			}
			m_dropDownBtn.click();
			sleep(2);
			return;
		}
	}

	private WebElement getVisibleDropdownMenu(By p_selector) throws DDTFrameworkException {
		WebElement dropdown = null;
		int iWaitTime = 0;
		do {
			List<WebElement> dropdownMenuColl = m_webdriver.findElements(p_selector);
			for (WebElement dropDownPopUp : dropdownMenuColl) {
				if (dropDownPopUp.isDisplayed()) {
					dropdown = dropDownPopUp;
					break;
				}
			}

			if (dropdown == null) {
				iWaitTime = iWaitTime + 2;
				sleep(2);
			} else {
				break;
			}
		} while (iWaitTime <= DDTController.getMaxWaitTime());

		// Return the visible dropdown
		return dropdown;
	}
	
	public void setAndSelect(String p_value, String p_setValue, String p_action) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;
		// setValue is partial text in case the field does not take spaces or other issues
		findObject();
		waitForClickable();

		if (p_action.equalsIgnoreCase("ADD")) {
			set(p_setValue);
			List<WebElement> dropdownColl = new ArrayList<WebElement>();
			if (getObject().findElements(By.xpath(".//div[contains(@class,'dropdown-indicator')]")).size() != 0) {
				
				sleep(3);
				WebElement dropdown = getVisibleDropdownMenu(
						By.xpath(".//div[contains(@class,'InterviewersSelectBox__menu')]"));
				if (dropdown != null) {
					dropdownColl = dropdown.findElements(By.xpath(".//div[contains(@class,'InterviewersSelectBox__option')]"));
				} else {
					fail("The dropdown menu is not found !!");
				}
				
				for (WebElement select : dropdownColl) {
					 
					if (select.getText().trim().contentEquals(p_value.trim())) {
						select.click();
						sleep(2);
						return;
					}
				}

				fail("The value [" + p_value + "] is not found in the combobox");
				return;
			}

		}
	}
	
	private void set(String p_value) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		if (p_value.trim().contentEquals(""))
			return;

		findObject();
		if (getObject().findElements(By.xpath(".//div[contains(@class,'dropdown-indicator')]")).size() != 0) {
			//getObject().click();
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().findElement(By.xpath(".//input")).sendKeys(p_value);
		} else {
			getObject().clear();
			if (!p_value.equalsIgnoreCase("[BLANK]"))
				getObject().sendKeys(p_value);
		}
		return;
	}
}

