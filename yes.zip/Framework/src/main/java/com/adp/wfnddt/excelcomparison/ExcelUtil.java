package com.adp.wfnddt.excelcomparison;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.adp.wfnddt.core.DDTLoggerManager;

public class ExcelUtil {

	private FileInputStream		fis;
	private Workbook			workbook;
	private Sheet				sheetObj;
	private static final int	HEADER_INDEX		= 0;

	private SimpleDateFormat	cellDateTimeFormat	= new SimpleDateFormat("MM/dd/yyyy HH:mm");
	private boolean				m_trimCellValues	= false;
	private static Logger		m_logger			= DDTLoggerManager.getLogger(ExcelUtil.class);

	public ExcelUtil(FileInputStream excelFileObj) {
		this.fis = excelFileObj;
		try {
			workbook = WorkbookFactory.create(this.fis);
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public ExcelUtil(String excelFilePath) {
		try {
			workbook = WorkbookFactory.create(new File(getClass().getResource(excelFilePath).getFile()));
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setSheet(int pSheetIndex) {
		sheetObj = workbook.getSheetAt(pSheetIndex);
	}

	public void setSheet(String pSheetName) {
		sheetObj = workbook.getSheet(pSheetName);
	}

	public Sheet getSheetObj() {
		return sheetObj;
	}

	public void setSheetObj(Sheet sheetObj) {
		this.sheetObj = sheetObj;
	}

	List<String> getRowData(int pRowNumber) {
		List<String> rowData = new ArrayList<String>();

		if (sheetObj == null)
			sheetObj = workbook.getSheetAt(0);

		Row row = sheetObj.getRow(pRowNumber);
		int iCells = row.getLastCellNum();
		for (int i = 0; i < iCells; i++) {
			String cellValue = getCellValueAsString(row.getCell(i));
			rowData.add(cellValue);
		}
		return rowData;
	}

	public HashMap<String, String> getRowDataWithHeaders(int iRowNumber) {
		List<String> headersList = getRowData(HEADER_INDEX);
		List<String> valuesList = getRowData(iRowNumber);
		HashMap<String, String> rowDataMap = new HashMap<String, String>();
		for (int i = 0; i < headersList.size(); i++) {
			String headerName = headersList.get(i);
			rowDataMap.put(headerName, valuesList.get(i));
		}
		return rowDataMap;

	}

	public String getCellValueAsString(Cell p_cell) {
		String cellValue = null;
		try {
			switch (p_cell.getCellType()) {
			case FORMULA:
				cellValue = p_cell.getCellFormula();
				break;
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(p_cell)) {
					Date date = p_cell.getDateCellValue();
					cellValue = cellDateTimeFormat.format(date);
					m_logger.debug("Cell " + p_cell.getAddress() + " Date Value:" + cellValue);
				} else
					cellValue = String.valueOf(p_cell.getNumericCellValue());
				break;
			case STRING:
				cellValue = p_cell.getStringCellValue();
				break;
			case BLANK:
				cellValue = ""; // null or "" ?
				break;
			case BOOLEAN:
				cellValue = String.valueOf(p_cell.getBooleanCellValue());
				break;
			case ERROR:
				cellValue = String.valueOf(p_cell.getErrorCellValue());
				break;
			
			default:
				cellValue = p_cell.getStringCellValue();
				break;
			}			
		}
		catch (NullPointerException ex) {
			return "";
		}
		

		if (m_trimCellValues)
			return cellValue.trim();
		else
			return cellValue;

	}

	public void close() {
		try {
			fis.close();
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
