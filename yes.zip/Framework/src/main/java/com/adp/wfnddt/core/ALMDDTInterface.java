package com.adp.wfnddt.core;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ALMDDTInterface {
	private static String m_errorMessage = "";
	private static byte m_errorCode = 0;
	private static String m_failedComponent = "";
	private static String m_runStatus = "Passed";
	private static boolean m_stopALMRun = false;
	
	private static Logger m_logger = DDTLoggerManager.getLogger(ALMDDTInterface.class);

	public static void setResultInfo(byte errorCode) {
		m_errorCode = errorCode;
	}

	public static void setResultInfo(byte errorCode, String errorMessage) {
		m_errorCode = errorCode;
		m_errorMessage = errorMessage;
	}

	public static void setFailedComponent(String failedComponent) {
		if (m_failedComponent.equalsIgnoreCase(""))
			m_failedComponent = failedComponent;
	}

	public static void formatDDTtoALMXML() throws SAXException, IOException, ParserConfigurationException, TransformerException, XPathExpressionException {
		
		if(DDTController.getRunID() <= 0) return;
		
		InputStream in = ALMDDTInterface.class.getResourceAsStream("/DDTToALM.xml");
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(in);
		Element root = doc.getDocumentElement();

		// Run ID
		root.getElementsByTagName("RunID").item(0).setTextContent(String.valueOf(DDTController.getRunID()));

		// Status
		if (m_errorCode == 0 || m_errorCode == 109) {
			m_runStatus = "Passed";
		} else {
			m_runStatus = "Failed";
		}
		root.getElementsByTagName("Status").item(0).setTextContent(m_runStatus);

		// Company Code
		setFieldValue(doc, "CompanyCode", DDTController.getResultsReporter().getRun().getCompanyCode());

		// Browser
		setFieldValue(doc, "BrowserInfo", DDTController.getResultsReporter().getRun().getBrowser());

		// Splunk Exceptions
		if(DDTController.getResultsReporter().getRun().getSplunkExceptions() != null){
			setFieldValue(doc, "SplunkExceptions", DDTController.getResultsReporter().getRun().getSplunkExceptions().toString());
		}

		// Error Message
		setFieldValue(doc, "ErrorMessage", m_errorMessage);

		// Analysis Category
		if (m_errorCode != 0) {
			String anaCategory = "";

			switch (m_errorCode) {
			case 101:
				anaCategory = "Verification Failure";
				break;
			case 102:
				anaCategory = "Component - Exception";
				break;
			case 103:
				anaCategory = "Component - Assertion";
				break;
			case 104:
				anaCategory = "Environment Issue";
				break;
			case 105:
				anaCategory = "Login Issue";
				break;
			case 106:
				anaCategory = "Client DB Issue";
				break;
			case 107:
				anaCategory = "Feature Not Found";
				break;
			case 108:
				anaCategory = "Component Not Found";
				break;
			case 109:
				anaCategory = "Parameter Mismatch";
				break;				
			default:
				anaCategory = "Component - Exception";
				break;
			}

			setFieldValue(doc, "AnalysisCategory", anaCategory);
		}

		// Failed Component
		if (m_failedComponent.length() > 255) {
			m_failedComponent.substring(0, 254);
		}
		setFieldValue(doc, "FailedComponent", m_failedComponent);

		StringWriter sw = new StringWriter();
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

		transformer.transform(new DOMSource(doc), new StreamResult(sw));

		File file = new File(System.getProperty("java.io.tmpdir") + "\\DDTToALM_" + DDTController.getRunID() + ".xml");
		FileWriter fw = new FileWriter(file);
		fw.write(sw.toString());
		fw.close();
		in.close();
	}

	public static boolean stopALMRun() {
		if(DDTController.getRunID() <= 0) return false;
		if(m_stopALMRun) return true;
		
		try {
			String filePath = System.getProperty("java.io.tmpdir") + "\\ALMToDDT_" + DDTController.getRunID() + ".xml";

			File file = new File(filePath);
			if (file.exists()) {

				InputStream in = Files.newInputStream(Paths.get(filePath), StandardOpenOption.READ);

				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document doc = builder.parse(in);
				Element root = doc.getDocumentElement();
				
				//Stop the run
				if(root.getElementsByTagName("StopRun").item(0).getTextContent().equalsIgnoreCase("TRUE")){
					m_logger.info("StopRun : true");
					m_stopALMRun = true;
					return true;
				}
			}
		} catch (SAXException | IOException | ParserConfigurationException e) {
			new DDTFrameworkException(ALMDDTInterface.class, e.getMessage());
		}
		
		return false;
	}

	private static void setFieldValue(Document doc, String fieldName, String fieldValue) throws XPathExpressionException {
		XPath xPath = XPathFactory.newInstance().newXPath();
		if (fieldValue != null && !fieldValue.trim().contentEquals("")) {
			NodeList nodes = (NodeList) xPath.evaluate("//Fields/Field/Name[text()='" + fieldName + "']/parent::Field/Value", doc, XPathConstants.NODESET);
			for (int i = 0; i < nodes.getLength(); i++) {
				nodes.item(i).setTextContent(fieldValue);
			}
		}
	}

}
