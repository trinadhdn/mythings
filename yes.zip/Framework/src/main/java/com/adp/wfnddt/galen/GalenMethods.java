package com.adp.wfnddt.galen;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.WebDriver;

import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.results.jaxb.StatusType;
import com.galenframework.reports.GalenTestAggregatedInfo;
import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.TestReport;
import com.galenframework.reports.json.JsonReportBuilder;
import com.galenframework.reports.json.ReportOverview;
import com.galenframework.support.GalenJavaTestBase;
import com.galenframework.support.LayoutValidationException;

public class GalenMethods extends GalenJavaTestBase {

	public GalenMethods() {
		initDriver(null);
		report.set(new TestReport());
	}

	@Override
	public WebDriver createDriver(Object[] args) {
		return DDTController.getWebDriver();
	}

	public void verifyLayout(String specPath, List<String> includedTags) throws IOException, DatatypeConfigurationException {
		//Check the layout
		StatusType status = StatusType.PASSED;
		try {
			checkLayout(specPath, includedTags);
		} catch (LayoutValidationException ex) {
			status = StatusType.FAILED;
		}

		// Create a test and add it to the collection
		GalenTestInfo test = GalenTestInfo.fromString(specPath.substring(specPath.lastIndexOf("\\") + 1));
		test.setReport(getReport());

		List<GalenTestInfo> tests = new LinkedList<GalenTestInfo>();
		tests.add(test);

		// Generate the report
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");
		Date date = new Date();
		String testReportName = "GALEN_TEST_" + InetAddress.getLocalHost().getHostName() + "_" + dateFormat.format(date).toString();
		String summaryReportName = "GALEN_SUMMARY_" + InetAddress.getLocalHost().getHostName() + "_" + dateFormat.format(date).toString();

		JsonReportBuilder jsonBuilder = new JsonReportBuilder();

		String overviewTemplate = IOUtils.toString(getClass().getResourceAsStream("/Galen/report.tpl.html"), "UTF-8");
		ReportOverview reportOverview = jsonBuilder.createReportOverview(tests);

		String testReportTemplate = IOUtils.toString(getClass().getResourceAsStream("/Galen/report-test.tpl.html"), "UTF-8");
		File testReportFile = new File(testReportName + ".html");
		
		String overviewJson = jsonBuilder.exportReportOverviewToJsonAsString(reportOverview);
		File summaryReportFile = new File(summaryReportName + ".html");
		
		String testReportPath = DDTController.getScreenshotPath() + "/" + testReportName + ".html";
		String summaryReportPath = DDTController.getScreenshotPath() + "/" + summaryReportName + ".html";
		
		String testReportURL = testReportPath;
		String summaryReportURL = summaryReportPath;
		
		if(DDTController.getScreenshotURL() != null){
			testReportURL = DDTController.getScreenshotURL() + "/" + testReportName + ".html";
			summaryReportURL = DDTController.getScreenshotURL() + "/" + summaryReportName + ".html";
		}

		for (GalenTestAggregatedInfo aggregatedInfo : reportOverview.getTests()) {
			String testReportJson = jsonBuilder.exportTestReportToJsonString(aggregatedInfo);
			FileUtils.writeStringToFile(testReportFile, testReportTemplate.replace("##REPORT-TEST-NAME##", testReportName).replace("##REPORT-DATA##", testReportJson).replace("##SUMMARY_REPORT_LINK##", summaryReportURL), "UTF-8");
		}
		
		FileUtils.writeStringToFile(summaryReportFile, overviewTemplate.replace("##REPORT-DATA##", overviewJson).replace("##TEST_REPORT_LINK##", testReportURL), "UTF-8");
				
		FileUtils.moveFile(testReportFile, new File(testReportPath));
		FileUtils.moveFile(summaryReportFile, new File(summaryReportPath));
		
		//Add the test step
		DDTController.getResultsReporter().addTestStep("Galen - Verify Layout", "<a target=\"_blank\" href=\"" + summaryReportURL + "\"> Click here for Galen Summary Report</a>");
		DDTController.getResultsReporter().endTestStep(status);
	}

}
