/**
 * 
 */
package com.adp.wfnddt.core;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

/**
 * @author Wiermanp
 *
 */
public class DDTResultReportProcessorClient {
	static private Logger m_logger = Logger.getLogger(DDTResultReportProcessorClient.class);

	public static void sendFile() throws DDTFrameworkException {
		m_logger.debug("Enter sendFile()");
		try {
			StringBuilder sbResultFile = new StringBuilder(DDTController.getResultReportStore());
			sbResultFile.append('/');
			sbResultFile.append(DDTController.getRunName());
			sbResultFile.append(".xml");
			File resultFile = new File(sbResultFile.toString());
			long lFileSize = resultFile.length();
			
			if(lFileSize > 0L) {			
				FileInputStream fis = new FileInputStream(resultFile);
				StringBuilder sbURL = new StringBuilder(256);
				sbURL.append("http://");
				sbURL.append(DDTController.getResultProcessorHostname());
				sbURL.append("/DDTReportProcessorWeb/");
				sbURL.append(resultFile.getName());
				sbURL.append("?ALMDomain=");
				sbURL.append(DDTController.getALMDomain());
				sbURL.append("&ALMProject=");
				sbURL.append(DDTController.getALMProject());
	
				URL url = new URL(sbURL.toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();

				// Setup request
				conn.setRequestMethod("PUT");
				conn.setRequestProperty("Content-Type", "application/xml");
				conn.setRequestProperty("Content-Length", Long.toString(lFileSize));
				conn.setRequestProperty("Content-Language", "en-US");
				conn.setRequestProperty("Accept", "application/json");
				conn.setUseCaches(false);
				conn.setDoOutput(true);			
				
				DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
				byte[] buffer = new byte[2048];
				int iBytesRead = 0;
				int numBytesRead = 0;
				
				while((iBytesRead = fis.read(buffer, 0, 2048)) > 0) {
					wr.write(buffer, 0, iBytesRead);
					numBytesRead += iBytesRead;
				}
				
				wr.close();
				fis.close();
				
				m_logger.debug("Bytes transmitted: " + Integer.toString(numBytesRead));
			
				// Send request and get response (throws IOException if server error)
				InputStream is = conn.getInputStream();
				
				// Process response.
				BufferedReader rd = new BufferedReader(new InputStreamReader(is));
				StringBuilder response = new StringBuilder();
				String line;
				
				while((line = rd.readLine()) != null) {
					response.append(line);
					response.append('\r');
				}
				
				rd.close();
				m_logger.debug(response.toString());
			}			
		} catch (MalformedURLException muEx) {
			throw new DDTFrameworkException(DDTResultReportProcessorClient.class, "Bad server URL provided: ", muEx);
		} catch (FileNotFoundException fnfEx) {
			throw new DDTFrameworkException(DDTResultReportProcessorClient.class, "Result Report file was not found: ", fnfEx);
		} catch (IOException ioEx) {
			throw new DDTFrameworkException(DDTResultReportProcessorClient.class, "I/O Error or server error: ", ioEx);
			// Server errors (500).
		}
		
		m_logger.debug("Exit sendFile()");
		return;
	}
}
